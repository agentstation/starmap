import json,sys,datetime
from pathlib import Path
root=Path('/Users/jack/src/github.com/agentstation/starmap-object-ci-repair');sp=Path('/Users/jack/src/github.com/agentstation/starport-native-catalog');out=Path(sys.argv[1]);sys.path.insert(0,str(root/'scripts'))
import catalog_product_verify as v
roster=v.read_json(root/'docs/plans/proof/starport-production-catalog/acceptance-map.json');registry=v.read_json(root/'scripts/catalog-product-checks.json');checks=v.validate_roster(roster);v.validate_registry(registry,roster,checks)
tasks=['CSP9','CSP9.1','CSP10','CSP10.1'];selected=list(dict.fromkeys(n for task in tasks for n in roster['task_checks'][task]));roots={'starmap':root,'starport':sp};go=v.GoEvidence([registry['checks'].get(n) for n in selected],roots);results={}
for n in selected:
 result=v.run_check(n,registry['checks'].get(n),roots,go);result['evidence_scope']='product';results[n]=result
 (out/'progress.json').write_text(json.dumps({'completed_subcases':len(results),'total':len(selected),'latest':n,'status':result['status'],'time':datetime.datetime.now(datetime.timezone.utc).isoformat()},indent=2)+'\n')
for task in tasks:
 names=roster['task_checks'][task];report=v.aggregate(roster,names,{n:results[n]for n in names},False);(out/(task+'.json')).write_text(json.dumps(report,indent=2)+'\n');print(task,report['gate_status'],len(names),flush=True)
raise SystemExit(0 if all(x['status']=='PASS'for x in results.values()) else 1)
