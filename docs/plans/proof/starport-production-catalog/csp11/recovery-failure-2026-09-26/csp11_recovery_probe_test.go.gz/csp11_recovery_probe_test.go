package runtime

import (
	"os"
	"testing"
	"time"

	"github.com/agentstation/starmap"
	"github.com/agentstation/starmap/pkg/catalogs/storage"
)

func TestFleetRecoveryRetainsInputsWithoutFormerLeaderDirectory(t *testing.T) {
	store, err := storage.NewFilesystem(privateRuntimeDirectory(t))
	if err != nil {
		t.Fatal(err)
	}
	leaderDirectory := privateRuntimeDirectory(t)
	source := newStubSource("fleet-recovery-baseline")
	source.replies = []SourceRead{testSourceRead(t, "fleet-recovery-baseline", testCatalogPayload(t, "baseline-provider", "baseline-model", "Baseline"), time.Now().UTC())}
	options := []Option{WithSource(source), WithClientOptions(starmap.WithCatalogStore(store))}
	leader := openTestRuntime(t, append(options, WithStateDirectory(leaderDirectory))...)
	if _, err := leader.RefreshSource(t.Context()); err != nil {
		t.Fatal(err)
	}
	at := time.Now().UTC()
	first := manualTestObservation(t, "first", at, false)
	if _, err := leader.PublishObservations(t.Context(), first); err != nil {
		t.Fatal(err)
	}
	before := leader.State()
	if err := leader.Close(); err != nil {
		t.Fatal(err)
	}
	// Only the test-owned private directory disappears. The catalog store remains.
	if err := os.RemoveAll(leaderDirectory); err != nil {
		t.Fatal(err)
	}
	follower, err := Open(t.Context(), append(options, WithStateDirectory(privateRuntimeDirectory(t)))...)
	if err != nil {
		t.Fatalf("follower could not recover accepted inputs: %v", err)
	}
	t.Cleanup(func() {
		if err := follower.Close(); err != nil {
			t.Error(err)
		}
	})
	if follower.State().GenerationID != before.GenerationID {
		t.Fatalf("follower changed retained generation: got %s, want %s", follower.State().GenerationID, before.GenerationID)
	}
	second := manualTestObservation(t, "second", at.Add(time.Minute), true)
	if _, err := follower.PublishObservations(t.Context(), second); err != nil {
		t.Fatalf("follower could not merge partial evidence: %v", err)
	}
	provider, err := follower.Catalog().Provider("manual-provider")
	if err != nil {
		t.Fatal(err)
	}
	for _, id := range []string{"first", "second"} {
		if provider.Models[id] == nil {
			t.Errorf("follower lost %s after its next partial update", id)
		}
	}
}
