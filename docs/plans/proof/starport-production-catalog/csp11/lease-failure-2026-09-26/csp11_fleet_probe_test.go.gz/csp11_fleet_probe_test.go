package catalog

import (
	"context"
	"os"
	"os/exec"
	"sync"
	"testing"
	"time"

	"github.com/agentstation/starport/internal/storage"
	"github.com/stretchr/testify/require"
)

// fleetProbeStore pauses the real head write after the caller checks its lease.
type fleetProbeStore struct {
	storage.KVStore
	once    sync.Once
	entered chan struct{}
	release chan struct{}
}

func (s *fleetProbeStore) CompareAndSwap(ctx context.Context, key string, old, next []byte) error {
	if key == catalogCurrentGenerationKey {
		s.once.Do(func() { close(s.entered) })
		select {
		case <-s.release:
		case <-ctx.Done():
			return ctx.Err()
		}
	}
	return s.KVStore.CompareAndSwap(ctx, key, old, next)
}

func fleetProbeValkey(t *testing.T) storage.KVStore {
	t.Helper()
	address := os.Getenv("CSP11_PROBE_VALKEY_URL")
	if address == "" {
		t.Fatal("CSP11_PROBE_VALKEY_URL must name a disposable test service")
	}
	store, err := storage.OpenValkey(storage.ValkeyConfig{URL: address})
	require.NoError(t, err)
	t.Cleanup(func() { require.NoError(t, store.Close()) })
	return store
}

func TestCatalogFleetTakeoverProbeProcess(t *testing.T) {
	if os.Getenv("CSP11_PROBE_CHILD") != "1" {
		t.Fatal("this helper must run as the takeover process")
	}
	store := fleetProbeValkey(t)
	leases, err := NewLeaseStore(store)
	require.NoError(t, err)
	held, err := leases.AcquireLease(t.Context(), "replacement-process", time.Minute)
	require.NoError(t, err)
	require.Equal(t, uint64(2), held.Epoch)
	t.Logf("replacement process %d holds epoch %d", os.Getpid(), held.Epoch)
}

func TestCatalogFleetCommitRejectsLeaseChangedBeforeHeadCAS(t *testing.T) {
	for _, mode := range []string{"expired", "released", "taken-by-another-process"} {
		t.Run(mode, func(t *testing.T) {
			store := fleetProbeValkey(t)
			for _, key := range []string{leaseKey, catalogCurrentGenerationKey, candidateCurrentGenerationKey} {
				require.NoError(t, store.Delete(t.Context(), key))
			}
			leases, err := NewLeaseStore(store)
			require.NoError(t, err)
			generation := runtimeTestGeneration(t, "fleet-probe-"+mode, testEmptyCatalog(t, "probe"), time.Now().UTC())
			candidates, err := newCandidateGenerationStore(store)
			require.NoError(t, err)
			require.NoError(t, candidates.Commit(t.Context(), generation, ""))
			paused := &fleetProbeStore{KVStore: store, entered: make(chan struct{}), release: make(chan struct{})}
			var releaseOnce sync.Once
			release := func() { releaseOnce.Do(func() { close(paused.release) }) }
			defer release()
			accepted, err := NewGenerationStore(paused)
			require.NoError(t, err)
			active := &Runtime{candidates: candidates, accepted: accepted, leases: leases}
			held, err := leases.AcquireLease(t.Context(), "original-process", 500*time.Millisecond)
			require.NoError(t, err)
			result := make(chan error, 1)
			ctx, cancel := context.WithTimeout(t.Context(), 10*time.Second)
			defer cancel()
			state := runtimeTestState(t, generation)
			go func() {
				result <- active.Accept(ctx, Candidate{State: state, Epoch: held.Epoch})
			}()
			select {
			case <-paused.entered:
			case <-ctx.Done():
				t.Fatal("acceptance did not reach the shared head write")
			}
			if mode == "released" {
				require.NoError(t, leases.Release(ctx, held))
			} else {
				select {
				case <-time.After(time.Until(held.ExpiresAt) + 20*time.Millisecond):
				case <-ctx.Done():
					t.Fatal("lease expiry exceeded the test deadline")
				}
				if mode == "taken-by-another-process" {
					child := exec.CommandContext(ctx, os.Args[0], "-test.run=^TestCatalogFleetTakeoverProbeProcess$", "-test.v")
					child.Env = append(os.Environ(), "CSP11_PROBE_CHILD=1")
					output, childErr := child.CombinedOutput()
					require.NoError(t, childErr, "%s", output)
					t.Logf("original process %d; child evidence: %s", os.Getpid(), output)
				}
			}
			release()
			select {
			case commitErr := <-result:
				current, readErr := accepted.Current(ctx)
				t.Logf("accept error=%v; head=%s; read error=%v", commitErr, current.Manifest.GenerationID, readErr)
				require.Error(t, commitErr, "a changed or expired lease must refuse the shared head commit")
				require.Error(t, readErr, "the refused candidate must not become the accepted head")
			case <-ctx.Done():
				t.Fatal("acceptance did not finish")
			}
		})
	}
}
