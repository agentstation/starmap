from pathlib import Path
import datetime, hashlib, json, os, subprocess, time, uuid

root=Path('/Users/jack/src/github.com/agentstation/starport-native-catalog')
out=Path('/tmp/csp11-fleet-probe')
out.mkdir(exist_ok=False)
env=dict(os.environ,GOTOOLCHAIN='go1.27.1',GOWORK='off')
report={'status':'running','started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'consumer':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'overlay_sha256':hashlib.sha256(Path('/tmp/csp11_fleet_probe_test.go').read_bytes()).hexdigest()}
cid=None
try:
 build=['go','test','-race','-c','-overlay','/tmp/csp11-fleet-probe-overlay.json','-o','/tmp/csp11-fleet-probe.test','./internal/catalog']
 report['build_command']=build
 with (out/'build.log').open('w') as log:
  result=subprocess.run(build,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=180)
 report['build_exit_code']=result.returncode
 if result.returncode:raise RuntimeError('probe build failed')
 image='valkey/valkey@sha256:9acdf6f0ae1771ea63c401e127054b2d1779227b9230dcfae37fa684610eaa4f'
 cid=subprocess.check_output(['docker','run','-d','--name','csp11-probe-'+uuid.uuid4().hex[:10],'-p','127.0.0.1::6379',image],text=True).strip()
 address=subprocess.check_output(['docker','port',cid,'6379/tcp'],text=True).strip()
 report['service']={'id':cid,'image':image,'address':address}
 for attempt in range(90):
  if subprocess.run(['docker','exec',cid,'valkey-cli','ping'],stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode==0:break
  time.sleep(.5)
 else:raise RuntimeError('Valkey startup failed')
 env['CSP11_PROBE_VALKEY_URL']='redis://'+address
 command=['/tmp/csp11-fleet-probe.test','-test.run=^TestCatalogFleetCommitRejectsLeaseChangedBeforeHeadCAS$','-test.v','-test.timeout=30s']
 report['command']=command
 start=time.monotonic()
 with (out/'test.log').open('w') as log:
  result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=45)
 report.update(status='PASS' if result.returncode==0 else 'FAIL',exit_code=result.returncode,seconds=time.monotonic()-start)
finally:
 if cid:report['cleanup_exit_code']=subprocess.run(['docker','rm','-f',cid],stdout=subprocess.DEVNULL).returncode
 report['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat()
 (out/'runner.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps(report))
