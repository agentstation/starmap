

## File publication retirement: September 27, 2026

Consumer `4a0de8d5` uses immutable blob publication for uploaded files and batch outputs.
File schema 4 selects the `retained-v1` namespace. CSP13 owns migration.
Cleanup confirms durable retirement before releasing the byte claim and file record.
A lost acknowledgment retains both. Exact output retries verify existing content.

Filesystem publication uses a flushed staged file and a hard link without replacement.
Retirement replaces the identity with a flushed marker and flushes its directory ancestors.
Shared publication requires conditional creation for single-part writes and multipart completion.
Retirement writes a real object because S3 delete markers permit conditional creation.

The [local proof](../../plans/proof/starport-production-catalog/csp12.2/retirement-2026-09-27/verification.json) passes the original delayed-writer assertion on all three metadata backends.
It also tests separate processes, versioned MinIO, and delayed multipart completion.
Each cleanup pass handles at most 256 records and preserves its page continuation.
The 30-second deadline remains unchanged.

Current retirement markers require indefinite retention in backups and object lifecycle policy.
Payload quotas exclude markers, staging, multipart parts, and noncurrent versions.
CSP13 must prove that old writers cannot resume before reclaiming markers.
Native platforms, restore behavior, storage readiness, video retirement, and full batch recovery remain required.



## File retirement repair: September 27, 2026

Consumer `4a0de8d5` repairs the delayed-publication failure recorded at `d93432d0`.
The [proof](../../plans/proof/starport-production-catalog/csp12.2/retirement-2026-09-27/verification.json) records 59 final blob race results and 85 final file race results, with no skips.
Batch integration passes 16 results, pure-Go checks pass eight, and application composition passes two.
The original failing probe remains historical evidence.

Durable cleanup exposed a Valkey pagination timeout. Each pass now handles at most 256 records.
The final test removes all 1,030 expired records, preserves the live record, and rejects every retired identity.
An earlier run's two failed results remain in the proof.

The video owner still calls mutable blob writes and deletion. Its expiry race needs a separate audit.
Construction still performs no bucket probe. Conditional-write readiness remains unqualified.
This local commit does not complete CSP12.2 or authorize a claim of production readiness.



## Immutable file bytes and retirement: September 27, 2026

Consumer `4a0de8d5` uses file schema 4 and a separate `retained-v1` byte namespace.
The [proof](../../plans/proof/starport-production-catalog/csp12.2/retirement-2026-09-27/verification.json) qualifies local filesystem and versioned MinIO retirement.
An interrupted cleanup retains its byte claim until retirement succeeds.
A delayed writer cannot replace the retained marker.

Backups and lifecycle rules must preserve current retirement markers.
Logical payload quotas exclude marker overhead, filesystem staging, multipart parts, and noncurrent versions.
Monitor these storage costs separately. CSP13 owns safe migration and marker reclamation.
Staging cleanup, restore tests, other S3 services, native platform checks, and shared readiness remain open.



The [file-retirement proof](../../plans/proof/starport-production-catalog/csp12.2/retirement-2026-09-27/verification.json) repairs delayed file publication at consumer `4a0de8d5`.
Confirmed retirement precedes quota release. Failed acknowledgments preserve recoverable metadata and charges.
A separate-process test and a real versioned MinIO test reject delayed publication.
Video retirement, aggregate reconstruction, interrupted-run behavior, audited correction, and full A47 remain required.
