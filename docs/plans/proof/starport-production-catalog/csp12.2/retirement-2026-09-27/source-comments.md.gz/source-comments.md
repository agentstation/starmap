
PublicationStore owns immutable bytes and permanent retirement at each key.
Its namespace is separate from mutable Put/Get objects. An error can mean
that a write succeeded but its acknowledgment was lost.

Retirement markers must survive restart and backup restoration. A caller
must not remove them while an earlier writer can resume. Payload quota does
not include these markers. Operators must budget for their retained storage.

Publish creates a complete object only under an unused identity.
Publish never replaces existing live bytes or retirement markers.

ReadPublished opens live bytes. Missing and retired identities return ErrNotFound.

StatPublished reports the payload length, excluding the private envelope.

Retire durably prevents every later publication, including an earlier
writer that resumes. Only success permits the owner to release quota.

Publish stages durable bytes, then links them without replacing an identity.
A retirement marker occupies that same identity and rejects a delayed link.

Retire replaces either live bytes or an absent identity with a durable marker.

Flush the entry and its ancestors through the configured root.
Construction already flushed any newly created root ancestors.

ReadPublished consumes the private envelope before exposing payload bytes.

StatPublished uses one open handle so retirement cannot mix two versions.

Publish requires conditional creation for both single-part and multipart
completion. The configured S3 service must enforce If-None-Match: *.

Retire writes a real object, never a delete marker. S3 permits conditional
creation over a delete marker, which would let an old upload reappear.

ReadPublished checks the same envelope as the filesystem backend.

StatPublished checks publication metadata from the atomic object write.
