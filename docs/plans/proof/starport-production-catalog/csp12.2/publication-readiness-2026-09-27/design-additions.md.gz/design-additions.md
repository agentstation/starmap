
## Storage capability before paid work

New file allocation and video dispatch require byte-publication capability. Batch lines must establish that capability before provider execution. Storage failure must not disable unrelated text requests or general gateway diagnostics.

Return a retryable storage error before affected work creates provider charges. Keep successful capability evidence in memory for the configured client. A capability probe does not guarantee future availability or physical erasure.


## Conditional publication readiness

The blob owner exposes `EnsurePublicationReady`. File allocation and the video dispatch recorder call this contract before creating durable work ownership. Batch result preparation checks it before provider execution. The constructor does not probe the bucket.

An object-store client coalesces the first probe and caches success in process memory. Waiters honor cancellation. Failed checks permit another probe after one second. Each probe has a 30-second deadline, with separate five-second multipart abort deadlines.

Require successful single-part and multipart creation. Verify that both reject replacements of live bytes and retirement markers. Read retained bytes before accepting capability. A fresh configured client repeats qualification. Keep warm checks local and allocation-free.

Probe attempts retain up to four identities. Preserve retirement markers and configure incomplete-upload cleanup. Do not interpret probe success as proof of physical erasure, restore safety, backend-wide consistency, or future availability. File and video HTTP failures return 503 with a recovery message. Detailed causes remain in logs.


## Conditional publication readiness: September 27, 2026

The blob contract now gates new file allocation and video dispatch. Batch result preparation checks the same contract before provider execution. The object-store constructor remains passive. General gateway readiness remains independent.

The runtime probe checks successful creation, retained content, and refused replacement for single-part and multipart writes. Successful checks stay in memory for one configured client. A failed check permits another attempt after one second.

Each attempt retains up to four small identities. Retirement markers must survive lifecycle rules and restoration. Interrupted probes can leave incomplete multipart uploads. Configure their cleanup separately. Backend-wide consistency, physical erasure, native platforms, and coordinated migration remain unqualified.
