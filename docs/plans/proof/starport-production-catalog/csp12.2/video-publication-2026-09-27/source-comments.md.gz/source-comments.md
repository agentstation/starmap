
ErrAssetRetirementRequired preserves ownership until byte retirement succeeds.

storeProviderAsset binds one identity and content digest before byte publication.
Lost acknowledgments retain a discoverable candidate for refresh or startup recovery.

recoverProviderAsset uses retained bytes without another provider fetch.

The declared size comes from bounded, measured input before preparation.

Read again after an ambiguous acknowledgment. Never create another identity.

recoverPublishedNativeAsset verifies retained bytes before any new download.
The pinned digest and original deadline remain authoritative across restarts.
