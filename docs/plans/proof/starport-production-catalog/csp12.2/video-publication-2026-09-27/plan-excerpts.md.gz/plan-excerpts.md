

## Video result retention: September 27, 2026

Video recovery must preserve the first accepted receipt, its measured usage, and its original retention clock.
A conflicting callback must not replace that evidence. Recovery must not repeat inference.
Provider-polled jobs must retain a discoverable asset identity before writing bytes.
A failed acknowledgment must not create an unreferenced duplicate.

The [local implementation proof](../../plans/proof/starport-production-catalog/csp12.2/video-publication-2026-09-27/verification.json) covers these rules at consumer `e0aae1c7`.
API expiry prevents new content reads. It does not specify physical deletion times for backups or object versions.
Production storage readiness and the remaining CSP12.2 criteria still require qualification.



## Video publication ownership: September 27, 2026

Consumer `e0aae1c7` moves all video receipts and assets to immutable blob publication.
Job schema 5 requires coordinated migration. CSP13 owns that work.
An exact native callback retry retains the first receipt timestamp. A conflicting callback returns a reconciliation conflict.
Recovery verifies retained asset bytes before another download.

Provider-polled jobs persist an asset key, digest, measured size, expiry, and pending state before byte publication.
Refresh and startup recovery verify existing bytes and complete that same identity.
Replacement configuration cannot alter a prepared size bound or deadline.
Expiry confirms backend retirement before clearing pending state. Repository deletion refuses an asset awaiting retirement.

The [proof](../../plans/proof/starport-production-catalog/csp12.2/video-publication-2026-09-27/verification.json) covers actual process death after receipt and asset publication.
It also covers versioned MinIO with memory, Badger, and Valkey metadata.
Conditional-write readiness must precede affected paid dispatch without blocking independent gateway operations.
Native platforms, restore, staging cleanup, noncurrent versions, batch aggregates, and full A47 remain open.



## Video publication repair: September 27, 2026

Consumer `e0aae1c7` repairs two native defects and one provider-asset ownership defect.
Delayed writes could recreate expired content. Repeated callbacks could replace the first billing receipt.
A provider asset could lose its only reference after a successful write lost its acknowledgment.
The [proof](../../plans/proof/starport-production-catalog/csp12.2/video-publication-2026-09-27/verification.json) preserves five failed native results and the provider-asset failure.

Final checks pass 578 broad race results with one optional skip, 29 HTTP results, and 23 production results.
Pure-Go checks pass 23 results. Actual process-loss checks pass four results, and the prepared-bound check passes one.
Earlier schema, fixture, and compile failures remain evidence.

All job blobs now use immutable publication. Pending provider assets retain durable ownership.
Conditional-write readiness, restore, physical cleanup, and the full task acceptance criteria remain unqualified.



## Retained video identities: September 27, 2026

Consumer `e0aae1c7` binds job schema 5 to `retained-v1` blob storage.
Native receipts and all video assets now use permanent retirement.
Provider assets retain their identity and content digest before writing bytes.
A lost reply leaves a recoverable preparation. Startup recovery uses the stored bytes without a provider runner.

The [proof](../../plans/proof/starport-production-catalog/csp12.2/video-publication-2026-09-27/verification.json) includes real process loss and versioned MinIO with all three metadata backends.
Preserve current retirement markers in backups and lifecycle rules.
API expiry does not establish a physical deletion deadline for noncurrent versions or backups.
Storage readiness, physical cleanup, native platforms, and coordinated migration remain required.



The [video-publication proof](../../plans/proof/starport-production-catalog/csp12.2/video-publication-2026-09-27/verification.json) repairs receipt replacement, expired-content resurrection, and unreferenced provider assets at consumer `e0aae1c7`.
The production budget tests preserve measured charges and disputed late evidence.
Recovery after actual worker death uses retained bytes without another inference request.
Conditional-write readiness, stable batch aggregates, interrupted-run policy, audited correction, and full A47 remain required.
