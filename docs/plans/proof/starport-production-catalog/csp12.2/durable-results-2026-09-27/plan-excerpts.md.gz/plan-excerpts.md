

### Durable line output and retirement boundary

Consumer `d93432d0` retains each line's output identity before execution.
It records result intent before the blob write and confirms stored bytes before releasing the worker slot.
Conflicting results fail. Missing bytes cannot become a confirmed empty result.
The [output proof](../../plans/proof/starport-production-catalog/csp12.2/durable-results-2026-09-27/verification.json) passes the original Badger process-loss assertion.

File schema 3 retains output identity, digest, and storage bound. Line schema 2 retains file identity, expiry, result intent, and completion evidence.
Internal checkpoints stay out of public file listings. File scans reach later pages.
Storage failure stops new dispatch and retains the outstanding batch claim. CSP13 owns migration.

The same proof fails delayed-publication retirement on all three metadata backends.
A blob can reappear after cleanup deletes the file and releases its charge.
The [retirement contract](../../plans/proof/starport-production-catalog/csp12.2/durable-results-2026-09-27/RETIREMENT_CONTRACT.md) requires a backend fence before quota release.
Aggregate reconstruction, stable aggregate publication, and interrupted-run recovery remain incomplete.



## CSP12.2 retained batch results and retirement race: September 27, 2026

Consumer `d93432d0` retains completed line bytes before the worker admits another line.
The original process-loss assertion now passes with Badger and filesystem storage.
The [output proof](../../plans/proof/starport-production-catalog/csp12.2/durable-results-2026-09-27/verification.json) records 623 broad race results with one optional skip.
File checks pass 72 results, production checks pass 16, and pure-Go checks pass seven.
Final recovery checks pass nine results. Pagination and identity checks pass five.

A separate probe pauses publication while another service expires the file.
The paused writer later creates a blob after the file record and its quota charge are gone.
Four results fail across memory, Badger, and Valkey. The probe remains required evidence.
The [backend retirement repair](../../plans/proof/starport-production-catalog/csp12.2/durable-results-2026-09-27/RETIREMENT_CONTRACT.md) remains within CSP12.2.
The commit is local and does not qualify full batch recovery or shared-object storage.



## Prepared batch outputs: September 27, 2026

Consumer `d93432d0` assigns stable output identities and preserves their original expiry.
File schema 3 and line schema 2 retain immutable result evidence. CSP13 owns migration.
The file owner verifies content before marking output ready.

Checkpoints and aggregates both count against storage while retained.
Internal checkpoints stay out of ordinary listings. Native scan pages reach later records during listing and cleanup.

The [qualification proof](../../plans/proof/starport-production-catalog/csp12.2/durable-results-2026-09-27/verification.json) retains a failed cleanup race.
A delayed blob write can recreate bytes after metadata deletion and quota release.
The [retirement contract](../../plans/proof/starport-production-catalog/csp12.2/durable-results-2026-09-27/RETIREMENT_CONTRACT.md) requires backing-store ordering before release.
Backend retirement and shared-object qualification remain open.



The [durable-result proof](../../plans/proof/starport-production-catalog/csp12.2/durable-results-2026-09-27/verification.json) repairs the original completed-output process-loss failure at consumer `d93432d0`.
It also proves that lost result acknowledgments stop further dispatch and retain the batch claim.
A new delayed-publication retirement probe fails on all three metadata backends.
The [retirement contract](../../plans/proof/starport-production-catalog/csp12.2/durable-results-2026-09-27/RETIREMENT_CONTRACT.md), aggregate reconstruction, and interrupted-run recovery remain required before full batch qualification.
