A backend stages bytes and publishes a complete object. A lost reply
can leave the new object present despite an error. The caller must
inspect retained identity and content before deciding how to recover.
A rejected input stream does not publish a partial object.


part lands. A lost acknowledgment or a failed size lookup can return an
error after publication. The owner must verify the retained object.







ResultFile binds a retained file to its original retention deadline.



PrepareOutput retains one output identity before its producer starts.
Repeated preparation preserves the original expiry and byte claim.

An exact retry can recover a successful metadata write whose reply was lost.

CommitOutput pins the expected bytes before writing them. A retry can only
write that same content. Failed writes retain metadata for recovery.

RecoverOutput verifies retained bytes before completing interrupted publication.
Missing bytes remain incomplete. It never asks a provider to generate them.

Preserve an accepted publication after a lost acknowledgment.


RecordPage carries one native scan step. An empty continuation ends the pass.
Scanned distinguishes a failed scan from a valid page with no readable records.


BindLineOutput records a stable file identity before the provider can run.

RecordLineResult pins the first observed result before its byte write.
A retained digest does not establish that the output bytes are available.

ConfirmLineResult marks output durable after the file owner accepts its bytes.

