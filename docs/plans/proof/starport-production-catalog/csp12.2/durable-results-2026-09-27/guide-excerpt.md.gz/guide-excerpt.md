Each claimed line receives a stable output file before dispatch. Starport records the result digest and writes its bytes before starting another line in that worker slot.
A process restart preserves completed line files. If result storage fails, Starport stops further dispatch and retains the outstanding batch claim.
The record reports `batch_result_storage_unavailable`. It does not repeat the provider call.

Prepared line files retain their original expiry. Internal checkpoints do not appear in ordinary file listings.
The storage bound counts checkpoints and aggregate files while both exist. File scans continue beyond the first page.
Automatic interrupted-run recovery, aggregate reconstruction, and early checkpoint cleanup remain incomplete in this candidate.

Prepared-output retirement also needs a backend fence against delayed publication. Full recovery qualification remains open.

File schema 3 and byte-accounting schema 2 require coordinated migration. CSP13 owns that qualification.
