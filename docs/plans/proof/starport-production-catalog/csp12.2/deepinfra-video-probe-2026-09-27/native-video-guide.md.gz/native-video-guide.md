> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deepinfra.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Text to Video

> Generate video clips from text prompts.

DeepInfra hosts text-to-video models that generate short video clips from a text description. Browse [all text-to-video models](https://deepinfra.com/models/text-to-video).

## Endpoint

```
POST https://api.deepinfra.com/v1/inference/{model_name}
```

## Example

<CodeGroup>
  ```python Python theme={null}
  import os

  import requests

  DEEPINFRA_API_KEY = os.environ["DEEPINFRA_API_KEY"]
  MODEL = "Wan-AI/Wan2.2-T2V-A14B"

  response = requests.post(
      f"https://api.deepinfra.com/v1/inference/{MODEL}",
      headers={
          "Authorization": f"Bearer {DEEPINFRA_API_KEY}",
          "Content-Type": "application/json",
      },
      json={
          "prompt": "A serene mountain lake at sunrise, with mist rising from the water and pine trees reflected on the surface.",
      },
  )

  result = response.json()

  # video_url is a `data:video/mp4;base64,...` URI, not an HTTP link.
  # Decode it to save the clip:
  import base64
  header, _, payload = result["video_url"].partition(",")
  with open("video.mp4", "wb") as f:
      f.write(base64.b64decode(payload))
  ```

  ```bash cURL theme={null}
  curl -X POST \
    -H "Authorization: Bearer $DEEPINFRA_API_KEY" \
    -H "Content-Type: application/json" \
    -d '{"prompt": "A serene mountain lake at sunrise, with mist rising from the water and pine trees reflected on the surface."}' \
    'https://api.deepinfra.com/v1/inference/Wan-AI/Wan2.2-T2V-A14B'
  ```
</CodeGroup>

## Response

```json theme={null}
{
  "request_id": "RwKufnhcUDyHEYbVN2W1GWgr",
  "inference_status": {
    "runtime_ms": 267363,
    "cost": 0.375,
    "output_length": 5
  },
  "video_url": "data:video/mp4;base64,AAAAIGZ0eXBpc29tAAACAGlzb21pc28y...",
  "seed": null
}
```

`video_url` carries the whole clip inline as a `data:` URI — it is not an HTTP link, so decode the base64 payload to write the file. `output_length` is the clip duration in seconds, which is what these models are billed on.

## Tips for good prompts

* Be descriptive about the scene, lighting, and motion
* Specify the camera movement if relevant (e.g. "slow pan", "aerial shot", "close-up")
* Keep prompts focused — overly complex prompts can produce inconsistent results
* Use the [negative prompt](https://deepinfra.com/models/text-to-video) parameter (if supported) to exclude unwanted elements

## Async inference

Video generation is compute-intensive and may take longer than text inference. Consider using [webhooks](/account/webhooks) to receive the result asynchronously rather than polling.

## Available models

Browse [all text-to-video models](https://deepinfra.com/models/text-to-video).
