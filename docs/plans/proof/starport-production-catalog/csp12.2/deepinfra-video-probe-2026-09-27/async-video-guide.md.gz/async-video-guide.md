> ## Documentation Index
> Fetch the complete documentation index at: https://docs.deepinfra.com/llms.txt
> Use this file to discover all available pages before exploring further.

# Get Video Generation



## OpenAPI

````yaml https://api.deepinfra.com/openapi.json get /v1/videos/{video_id}
openapi: 3.1.0
info:
  title: DeepInfra API
  description: >-
    The DeepInfra API provides serverless AI inference, custom model
    deployments, and GPU rentals.
  version: 1.0.0
servers:
  - url: https://api.deepinfra.com
security: []
tags:
  - name: Chat Completions
    description: OpenAI and Anthropic-compatible chat completion endpoints for LLMs.
  - name: Text Completions
    description: OpenAI-compatible text completion endpoints.
  - name: Embeddings
    description: Generate text embeddings for search and RAG.
  - name: Image Generation
    description: Generate, edit, and create variations of images.
  - name: Audio
    description: OpenAI-compatible speech synthesis, transcription, and translation.
  - name: Text to Speech
    description: ElevenLabs-compatible TTS endpoints and voice management.
  - name: Inference
    description: Native DeepInfra inference API for models and deployments.
  - name: Dedicated Models
    description: Deploy and manage private model instances with autoscaling.
  - name: GPU Rentals
    description: Rent dedicated GPU containers.
  - name: Models
    description: Browse, search, and manage AI models.
  - name: Files & Batches
    description: File uploads and batch processing.
  - name: LoRA Adapters
    description: Create, manage, and query LoRA adapter models.
  - name: Agents
    description: Manage agent-framework instances (OpenClaw and friends).
  - name: Sandboxes
    description: Create and manage isolated sandbox environments.
  - name: Account
    description: User profile, team management, rate limits, and GPU pool limits.
  - name: Authentication
    description: API tokens, SSH keys, scoped JWTs, and login flows.
  - name: Billing
    description: Payment methods, usage tracking, and billing.
  - name: Logs & Metrics
    description: Query inference logs, deployment logs, and usage metrics.
  - name: Utilities
    description: Feedback submission and CLI version.
paths:
  /v1/videos/{video_id}:
    get:
      tags:
        - Videos
      summary: Get Video Generation
      operationId: get_video_generation_v1_videos__video_id__get
      parameters:
        - name: video_id
          in: path
          required: true
          schema:
            type: string
            title: Video Id
        - name: xi-api-key
          in: header
          required: false
          schema:
            anyOf:
              - type: string
              - type: 'null'
            title: Xi-Api-Key
        - name: x-api-key
          in: header
          required: false
          schema:
            anyOf:
              - type: string
              - type: 'null'
            title: X-Api-Key
      responses:
        '200':
          description: Successful Response
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/VideoGenerationOut'
        '422':
          description: Validation Error
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/HTTPValidationError'
      security:
        - HTTPBearer: []
components:
  schemas:
    VideoGenerationOut:
      properties:
        id:
          type: string
          title: Id
        object:
          type: string
          title: Object
          default: video.generation.job
        created_at:
          type: integer
          title: Created At
        status:
          type: string
          title: Status
        model:
          type: string
          title: Model
        data:
          anyOf:
            - items:
                additionalProperties: true
                type: object
              type: array
            - type: 'null'
          title: Data
        error:
          anyOf:
            - type: string
            - type: 'null'
          title: Error
      type: object
      required:
        - id
        - created_at
        - status
        - model
      title: VideoGenerationOut
    HTTPValidationError:
      properties:
        detail:
          items:
            $ref: '#/components/schemas/ValidationError'
          type: array
          title: Detail
      type: object
      title: HTTPValidationError
    ValidationError:
      properties:
        loc:
          items:
            anyOf:
              - type: string
              - type: integer
          type: array
          title: Location
        msg:
          type: string
          title: Message
        type:
          type: string
          title: Error Type
      type: object
      required:
        - loc
        - msg
        - type
      title: ValidationError
  securitySchemes:
    HTTPBearer:
      type: http
      scheme: bearer

````