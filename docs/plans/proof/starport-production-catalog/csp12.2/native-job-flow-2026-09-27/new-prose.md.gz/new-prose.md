Starport polls providers that return asynchronous job handles.
For native video inference, Starport retains one provider connection in a bounded worker.
The submission returns after Starport stores dispatch ownership.
The caller reads the gateway job while the worker waits for the result.
Native request identifiers do not permit provider polling or cancellation.
Starport returns HTTP 409 for native cancellation requests.

A native response receipt retains the result, measured duration, and asset bytes.
Recovery reads this receipt without another inference request.
A lost response leaves `submission_status` as `unconfirmed` and retains required budget capacity.
Starport never automatically repeats uncertain inference.
External asset URL downloads remain unimplemented. Inline video assets support durable recovery.
| `queued` | dispatch ownership exists, or the provider accepted work that has not started |
STARPORT_JOBS_MAX_WORKERS=2
STARPORT_JOBS_EXECUTION_TIMEOUT=10m
Each replica permits two simultaneous video submission workers by default.
A full worker set returns HTTP 503 before provider dispatch.
Native inference uses the configured execution deadline, including response transfer.
A timeout retains uncertain work and does not prove provider cancellation.
Shutdown cancels workers before the provider registry and storage close.

Optional usage reports use submission prices and measured duration.
Provider cost estimates and terminal states cannot establish a charge.
An explicit measured zero differs from absent usage.
The job record preserves unknown usage for required settlement.

The retention window defaults to 24 hours.
Native jobs measure it from the stored response receipt.
Other jobs measure it from asset storage.
Native recovery retains the submission asset bound and retention window.

A generated video is an answer a caller collects.
Provider retention does not change the gateway retention window.
For asynchronous provider jobs, a single-job GET can check the provider during the first hour after submission.
