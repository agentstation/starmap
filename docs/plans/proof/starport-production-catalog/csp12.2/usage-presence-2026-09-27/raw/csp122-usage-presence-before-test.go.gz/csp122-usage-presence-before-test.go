package app

import (
	"encoding/json/v2"
	"io"
	"net/http"
	"testing"

	"github.com/agentstation/starport/internal/limits"
	"github.com/agentstation/starport/internal/limits/reservation"
	"github.com/stretchr/testify/require"
)

func TestProductionSpendMissingTokenCountRetainsCapacity(t *testing.T) {
	for _, counts := range []string{
		`"completion_tokens":3,"total_tokens":3`,
		`"prompt_tokens":null,"completion_tokens":3,"total_tokens":3`,
		`"prompt_tokens":8,"total_tokens":8`,
	} {
		t.Run(counts, func(t *testing.T) {
			fixture := newPerformanceFixtureWithAdmission(t, 0, nil, true,
				&limits.Limits{Spend: &limits.Budget{Limit: 100_000_000, Interval: limits.IntervalDay}},
				http.HandlerFunc(func(w http.ResponseWriter, _ *http.Request) {
					w.Header().Set("Content-Type", "application/json")
					_, _ = io.WriteString(w, `{"id":"usage-presence","model":"gpt-4o-mini","choices":[{"index":0,"message":{"role":"assistant","content":"hello"},"finish_reason":"stop"}],"usage":{`+counts+`,"prompt_tokens_details":{"cached_tokens":0}}}`)
				}))
			require.Equal(t, http.StatusOK, budgetDispatch(t, fixture))
			keys, err := fixture.application.store.ScanWithPrefix(t.Context(), "budget:v1:attempt:", 10)
			require.NoError(t, err)
			require.Len(t, keys, 1)
			data, err := fixture.application.store.Get(t.Context(), keys[0])
			require.NoError(t, err)
			var record reservation.Record
			require.NoError(t, json.Unmarshal(data, &record))
			require.Equal(t, reservation.Uncertain, record.State)
			require.Nil(t, record.Evidence)
			require.Greater(t, *record.NanoUSD, int64(1_000_000))
		})
	}
}
