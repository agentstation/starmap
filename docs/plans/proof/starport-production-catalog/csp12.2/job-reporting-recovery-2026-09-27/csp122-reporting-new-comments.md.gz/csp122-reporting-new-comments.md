Accountant records optional usage for a terminal job.
RecordJob must accept exact retries without duplicate charges or counters.
A delivery can succeed before the service stores its acknowledgement.
Errors retain pending reporting and do not change the provider result.

Notifier receives a best-effort terminal notification independently of billing.
The service claims one attempt before calling JobEnded. A crash between the
claim and the call can lose the event. This is not a durable delivery contract.

settleAccounting confirms required settlement before it retries reporting.
Notifications and slot release do not depend on settlement or reporting.

notifyTerminal claims one optional notification across concurrent replicas.

AccountedAt records acknowledged optional reporting after required settlement.
It does not own slot release or terminal notification.

NotificationAttemptedAt claims one best-effort terminal notification.
It does not prove delivery to a webhook recipient.

MarkAccounted records acknowledged reporting for a terminal job.
Delivery precedes this marker and must be idempotent across retries.

StorageSchemaVersion separates reporting acknowledgement from notification attempts.
