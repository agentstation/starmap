Before each batch line runs, Starport atomically records its input digest and request identity against the current batch state.
Cancellation through another replica prevents later line claims. Lines claimed before cancellation can finish.
A failed or ambiguous claim acknowledgment permits no dispatch. Reading a retained claim does not permit another execution.
Interrupted-run and result recovery remain incomplete in this candidate.

