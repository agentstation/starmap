StoredBytesSchemaVersion identifies durable byte claims and their aggregate.

StoredBytesPrefix is the durable byte accounting namespace.

StorageMeter owns durable file claims and their atomic account total.

InitializeEmpty requires the file owner to prove that the account has no files.
Existing legacy or claim evidence prevents an implicit reset to zero.

Reserve records one file claim before bytes or file metadata can publish.

Resize sets the measured claim size once. Exact retries preserve its total.

Attachment joins a reserved byte claim to the file metadata write.

Release closes a claim after its bytes disappear. Retried cleanup releases nothing twice.

Abort fences an unattached preparation without releasing a published file.

A concurrent release can change the claim after the first read.

Total refuses missing accounting history instead of reporting a free account.


StoredBytesPendingGrace bounds unattached preparation. Recovery competes with
attachment on the same claim, so a delayed writer cannot attach a closed claim.

RecoverPending closes abandoned preparations. Attached files remain under
the file owner's cleanup protocol. Each pass reads native pages for at most
thirty seconds. The next sweep resumes at the retained cursor.


ErrCounterRequired reports a meter built without durable storage.

ErrInvalidHolder reports an empty holder identity.


WithMeter counts and bounds account storage. Production supplies a meter
even when an account has no configured bound.

prepare attaches one durable byte claim to the pending file.

A lost successful acknowledgment can leave attached metadata. Abort
fences only an unattached claim. Recovery retains the published file.

settle records the measured size once before the file becomes readable.

discard keeps failed cleanup discoverable by the recovery sweep.

Settlement can change the byte count before metadata publication.


CreateClaimed publishes metadata and its byte claim in one transaction.


