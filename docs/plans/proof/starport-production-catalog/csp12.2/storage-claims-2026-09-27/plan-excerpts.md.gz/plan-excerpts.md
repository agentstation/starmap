

### Durable file byte accounting

Consumer `e2e85607` implements the byte-accounting part of the output contract.
Each file has a durable claim. Reservation and aggregate changes use atomic conditional writes.
Pending metadata and claim attachment publish together.

Settlement records one measured size.
Deletion removes bytes, closes the claim once, then deletes metadata. A failed acknowledgment leaves recoverable state.

Unattached preparation recovery uses native scan pages and a thirty-second work limit.
It closes claims older than ten minutes through the same conditional write that fences attachment.
Attached files retain their normal lifecycle. Missing or invalid accounting refuses new storage.
CSP13 owns file schema 2 and byte-accounting schema 2 migration.

The [storage proof](../../plans/proof/starport-production-catalog/csp12.2/storage-claims-2026-09-27/verification.json) passes the concurrent-retirement regression and lost-acknowledgment cases on memory, Badger, and Valkey.
It does not qualify durable batch output, process loss, shared-object storage, or complete A47.



## CSP12.2 durable file quota repair: September 27, 2026

Consumer `e2e85607` replaces anonymous increments and decrements with durable file claims.
The original concurrent-retirement assertion now passes on memory, Badger, and Valkey.
Lost acknowledgments during attachment, settlement, and release preserve unrelated capacity.
A stale ready write cannot revive deleting metadata. Prepared-claim recovery reaches later pages and fences delayed attachment.

The [storage proof](../../plans/proof/starport-production-catalog/csp12.2/storage-claims-2026-09-27/verification.json) records 633 broad race results with one optional skip.
Final storage race and pure-Go checks each pass 101 results. Application checks pass three results.
Vet, goago, three repository gates, and scoped prose checks pass.
The broader race run predates final accounting validation. Final targeted checks cover that change.

File schema 2 and byte-accounting schema 2 require CSP13 migration qualification.
Durable batch output and ordinary file-sweep pagination remain open. The commit remains local and does not complete CSP12.2.



## File quota recovery update: September 27, 2026

Consumer `e2e85607` stores one byte claim per file in the metadata KV store.
Badger and Valkey use the same atomic claim and aggregate contract.
The file owner deletes blob bytes before closing the claim and removing metadata.
Duplicate cleanup cannot release unrelated storage. Lost acknowledgments retain recovery evidence.

Unattached preparations have a ten-minute recovery grace. Recovery uses native scan pages with a thirty-second work limit.
Attached records retain file lifecycle ownership. Missing or invalid accounting does not authorize a zero reset.

File schema 2 and byte-accounting schema 2 need CSP13 migration qualification.
The [storage proof](../../plans/proof/starport-production-catalog/csp12.2/storage-claims-2026-09-27/verification.json) covers filesystem blobs with memory, Badger, and Valkey metadata.
Shared-object recovery and durable batch results remain unqualified.



The [storage-claim repair](../../plans/proof/starport-production-catalog/csp12.2/storage-claims-2026-09-27/verification.json) qualifies concurrent file retirement and ambiguous accounting acknowledgments at consumer `e2e85607`.
The original byte-accounting probe now passes. The completed-output process-loss probe remains unresolved.
Prepared result identities, retained output, aggregate reconstruction, and shared-object recovery remain required before batch qualification.
