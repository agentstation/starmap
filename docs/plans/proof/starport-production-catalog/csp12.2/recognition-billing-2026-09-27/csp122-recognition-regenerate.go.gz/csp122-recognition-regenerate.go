package main
import (
 "compress/gzip"
 "encoding/json/v2"
 "fmt"
 "io"
 "os"
 "path/filepath"
 "strings"
 "time"
 "github.com/agentstation/starmap/pkg/catalogs"
 "github.com/agentstation/starmap/pkg/catalogs/evidence"
)
func main(){ if err:=run();err!=nil{fmt.Fprintln(os.Stderr,err);os.Exit(1)} }
func run() error {
 root:=os.Args[1]
 raw,err:=os.ReadFile(filepath.Join(root,catalogs.BootstrapGenerationManifestFilename));if err!=nil{return err}
 manifest,err:=catalogs.ParseGenerationManifestJSON(raw);if err!=nil{return err}
 f,err:=os.Open(filepath.Join(root,"generation-payload.json.gz"));if err!=nil{return err};defer f.Close()
 z,err:=gzip.NewReader(f);if err!=nil{return err};defer z.Close()
 oldPayload,err:=io.ReadAll(z);if err!=nil{return err}
 if _,err=catalogs.DecodeCatalogGeneration(catalogs.Generation{Manifest:manifest,Payload:oldPayload});err!=nil{return fmt.Errorf("prior generation: %w",err)}
 builder,err:=catalogs.NewFromPath(root);if err!=nil{return err}
 if err=builder.LoadReport().Err();err!=nil{return err}
 catalog,err:=builder.Build();if err!=nil{return err}
 payload,err:=catalogs.EncodeCatalogPayload(catalog);if err!=nil{return err}
 now:=time.Now().UTC();descriptor:=catalogs.DescribeCatalogPayload(payload)
 manifest.GenerationID="recognition-charges-"+strings.TrimPrefix(descriptor.Checksum,"sha256:")
 manifest.SyncRunID=manifest.GenerationID
 manifest.SchemaVersion=catalogs.CurrentCatalogSchemaVersion
 manifest.GeneratedAt=now;manifest.Payload=descriptor
 manifest.ConsumerCompatibility=catalogs.ConsumerCompatibility{MinSchemaVersion:manifest.SchemaVersion,MaxSchemaVersion:manifest.SchemaVersion}
 manifest.Validation=catalogs.GenerationValidationReport{ValidatorVersion:"starmap-recognition-charges-v1",ValidatedAt:now,Status:catalogs.GenerationValidationPassed,Checks:[]catalogs.GenerationValidationCheck{{Name:"catalog_decode_and_membership",Status:catalogs.GenerationValidationCheckPassed}}}
 manifest.SourceObservations=append(manifest.SourceObservations,catalogs.SourceObservationLink{Source:"custom_update",ObservationID:manifest.GenerationID,ObservedAt:now,Revision:evidence.ObservationRevision{Kind:evidence.ObservationRevisionKindContentDigest,Value:descriptor.Checksum},Completeness:evidence.ObservationCompletenessComplete,Status:evidence.ObservationStatusSucceeded,EvidenceChecksum:descriptor.Checksum})
 if _,err=catalogs.DecodeCatalogGeneration(catalogs.Generation{Manifest:manifest,Payload:payload});err!=nil{return err}
 encoded,err:=json.Marshal(manifest);if err!=nil{return err}
 if err=os.WriteFile(filepath.Join(root,catalogs.BootstrapGenerationManifestFilename),append(encoded,'\n'),0600);err!=nil{return err}
 fmt.Println(manifest.GenerationID)
 return nil
}
