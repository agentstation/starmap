
Incomplete failed runs retain their claims.

After restart, the background sweep resumes only lines that durable records prove never started.
It validates current caller permission before claiming another line. Each resumed line also requires normal authorization and budget admission.
Completed results remain available. Uncertain claims never permit automatic replay.

Batch records retain a gateway API key hash or an account-scoped, batch-scoped console receipt.
They do not retain bearer secrets or reusable console cookies.
Expired receipts, signing-key changes, and withdrawn permission prevent new claims.
Affected untouched lines remain pending until recovery can validate permission.

File schema 5, batch schema 5, and byte-accounting schema 2 require

New corrections must commit within 90 days after the original settlement.
A correction never extends this deadline. Exact accepted retries remain idempotent after the deadline.
Unresolved reservations and accepted audit evidence never expire through retention cleanup.

Required reservations use their storage authority's original settlement time.
Jobs without required reservations use the original administrator decision time.
After expiry, inspection reports `correction_horizon_expired`, and a new correction returns HTTP 409.

