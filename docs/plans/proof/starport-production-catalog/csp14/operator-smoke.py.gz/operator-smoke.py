import contextlib
import json
import os
from pathlib import Path
import signal
import socket
import subprocess
import tempfile
import time
import urllib.error
import urllib.request

binary = Path(__file__).resolve().parent / "starmap"
checks = []
process = None

def passed(name, condition=True):
    if not condition:
        raise AssertionError(name)
    checks.append(name)

def cli(*args, token=None):
    child_env = dict(environment)
    if token is not None:
        child_env["STARMAP_ADMIN_TOKEN"] = token
    result = subprocess.run([str(binary), *args], env=child_env, cwd=scratch,
                            capture_output=True, text=True, timeout=30)
    if result.returncode:
        raise RuntimeError("CLI failed: " + " ".join(args) + ": " + result.stderr[-2000:])
    return json.loads(result.stdout)

def request(method, path, token=None, body=None):
    headers = {}
    if token is not None:
        headers["Authorization"] = "Bearer " + token
    if body is not None:
        headers["Content-Type"] = "application/json"
    req = urllib.request.Request(base + path, method=method, headers=headers,
                                 data=None if body is None else json.dumps(body).encode())
    try:
        reply = urllib.request.urlopen(req, timeout=5)
    except urllib.error.HTTPError as error:
        reply = error
    with reply:
        data = reply.read()
        try:
            parsed = json.loads(data)
        except ValueError:
            parsed = None
        return reply.status, parsed, dict(reply.headers)

def start():
    global process
    process = subprocess.Popen([str(binary), "serve", "--rate-limit", "0"],
                               env=environment, cwd=scratch, stdout=service_log, stderr=service_log)
    deadline = time.monotonic() + 90
    while time.monotonic() < deadline:
        if process.poll() is not None:
            raise RuntimeError("server exited before readiness")
        try:
            if request("GET", "/health")[0] == 200:
                return
        except (urllib.error.URLError, TimeoutError):
            pass
        time.sleep(0.05)
    raise RuntimeError("server readiness deadline")

def stop():
    global process
    if process is None:
        return
    process.send_signal(signal.SIGINT)
    try:
        process.wait(timeout=10)
    except subprocess.TimeoutExpired:
        process.kill()
        process.wait(timeout=5)
        raise RuntimeError("server did not stop within ten seconds")
    finally:
        process = None

with tempfile.TemporaryDirectory(prefix="starmap-admin-smoke-") as scratch:
    root = Path(scratch)
    (root / "home").mkdir(mode=0o700)
    with socket.socket() as selector:
        selector.bind(("127.0.0.1", 0))
        port = selector.getsockname()[1]
    base = "http://127.0.0.1:" + str(port)
    environment = {
        "PATH": os.environ["PATH"], "HOME": str(root / "home"),
        "TMPDIR": str(root), "STARMAP_HOME": str(root / "product"),
        "STARMAP_CATALOG_SOURCE": "embedded",
        "STARMAP_CATALOG_ACQUISITION_ENABLED": "false",
        "STARMAP_CATALOG_WORKSPACE_PATH": "",
        "STARMAP_SERVER_HOST": "127.0.0.1", "STARMAP_SERVER_PORT": str(port),
    }
    with (root / "service.log").open("wb") as service_log:
        try:
            admin = cli("admin", "init", "--id", "operator")["credential"]
            subscriber = cli("admin", "create", "--id", "gateway", "--role", "subscriber", token=admin)["credential"]
            passed("CLI administrator bootstrap and subscriber creation")
            schema = cli("config", "schema", "--format", "json")
            effective = cli("config", "effective", "--format", "json")
            start()
            passed("anonymous catalog request refused", request("GET", "/api/v1/providers")[0] == 401)
            passed("subscriber catalog request accepted", request("GET", "/api/v1/providers", subscriber)[0] == 200)
            passed("subscriber acquisition refused", request("POST", "/api/v1/update", subscriber)[0] == 403)
            passed("subscriber diagnostics refused", request("GET", "/admin/status", subscriber)[0] == 403)
            passed("inference credential refused", request("GET", "/admin/status", "synthetic-starport-inference")[0] == 401)
            code, api_schema, _ = request("GET", "/admin/config/schema", admin)
            passed("CLI and API schema match", code == 200 and api_schema == schema)
            code, api_effective, headers = request("GET", "/admin/config/effective", admin)
            passed("CLI and API effective configuration match", code == 200 and api_effective == effective)
            passed("configuration report forbids caching", headers.get("Cache-Control") == "private, no-store")
            code, created, headers = request("POST", "/admin/identities", admin, {"id":"live-reader", "role":"subscriber"})
            passed("online subscriber creation", code == 201 and headers.get("Cache-Control") == "private, no-store")
            live_reader = created["credential"]
            passed("online subscriber can read", request("GET", "/api/v1/providers", live_reader)[0] == 200)
            code, rotated, _ = request("POST", "/admin/identities/gateway/rotate", admin, {"overlap":"2s"})
            passed("online subscriber rotation", code == 200)
            replacement = rotated["credential"]
            passed("rotation overlap accepts both credentials", request("GET", "/api/v1/providers", subscriber)[0] == 200 and request("GET", "/api/v1/providers", replacement)[0] == 200)
            time.sleep(2.1)
            passed("expired credential refused", request("GET", "/api/v1/providers", subscriber)[0] == 401)
            passed("replacement remains accepted", request("GET", "/api/v1/providers", replacement)[0] == 200)
            passed("online revocation succeeds", request("DELETE", "/admin/identities/live-reader", admin)[0] == 204)
            passed("revoked credential refused", request("GET", "/api/v1/providers", live_reader)[0] == 401)
            passed("last administrator revocation refused", request("DELETE", "/admin/identities/operator", admin)[0] == 409)
            stop()
            recovered = cli("admin", "recover", "--id", "operator")["credential"]
            passed("offline administrator recovery replaces credential", recovered != admin)
            start()
            passed("lost administrator credential refused after restart", request("GET", "/admin/status", admin)[0] == 401)
            passed("recovered administrator accepted after restart", request("GET", "/admin/status", recovered)[0] == 200)
            passed("rotated subscriber survives restart", request("GET", "/api/v1/providers", replacement)[0] == 200)
            passed("revocation survives restart", request("GET", "/api/v1/providers", live_reader)[0] == 401)
            print(json.dumps({"status":"PASS", "passed":len(checks), "checks":checks, "source":"embedded", "acquisition_enabled":False}, indent=2))
        except Exception:
            print(json.dumps({"status":"FAIL", "passed":len(checks), "checks":checks}))
            raise
        finally:
            stop()
