Scheduled catalog runs retain source evidence and promote the exact embedded input through a checked pull request before updating public channels.

The publisher stores an immutable catalog, run receipt, and replay checkpoint. It resumes interrupted publication from retained bytes and verifies uploaded assets. It checks the merged embedded input before advancing either channel. GitHub readers default to v2 and retain explicit v1 compatibility.

The models.dev adapter trims surrounding display-name whitespace and preserves model IDs. Publication quarantines rejected records and retains their previous facts. Receipts retain source degradation, rejected identifiers, and reason codes. Actions artifacts and job summaries retain bounded correction reports.

The public profile continues provider updates during prolonged models.dev outages. It preserves accepted metadata and its original observation time. Receipts and workflow reports identify stale sources and report their age. First publication still requires accepted models.dev data.

Validation:

- The integration includes merged credential changes from #161 and catalog storage from #162.
- The integrated generation gate passes, including nineteen publisher tests and the full-profile capacity case without race detection.
- All 68 distribution checks pass. The workflow package passes 28 race test events.
- Previous qualification includes 420 integrated race events and eight capacity cycles under race detection. Lint, policy, prose, and generated documentation checks pass.
- All fifteen CI checks passed at `31ab7ea85`. Commit `7ae5f9fa3` requires fresh native CI.

Both required reviewers completed four integration review sections with zero findings at the configured P0 threshold. The App installation selects this repository only. Its private-key secret and three controlled hosted acceptance cases remain open. The workflow refuses missing App configuration before acquisition or public writes. Full CSP6 acceptance requires those cases and merge.
