Scheduled catalog runs now preserve source evidence between runs and promote the exact embedded catalog input through a checked pull request before updating public channels.

The publisher prepares an immutable catalog, run receipt, and replay checkpoint. It resumes interrupted publication from retained bytes, verifies uploaded assets, and checks the merged embedded input before advancing either channel. GitHub readers default to v2 and retain explicit v1 compatibility.

The models.dev adapter trims surrounding display-name whitespace. An explicit source policy permits isolated invalid records while preserving their previous catalog values. Receipts record degraded source status and rejected identifiers. Recovery clears current quarantine and preserves historical receipts.

Validation:

- Generation qualification passes, including eight full-profile runs. Thirteen publisher and transport tests pass, including recovery with real Git repositories.
- All 68 distribution checks pass.
- Full runtime qualification passes 1,192 race test events. Final publication and artifact checks pass 264, models.dev passes 80, and minimum Go passes 28 focused events.
- Policy and prose checks pass. Native publication qualification uses the repository's 30-minute test limit. Windows jobs allow 120 minutes after the prior job exceeded 60 minutes following a successful runtime test step.
- Draft-release recovery uses the GitHub CLI draft lookup strategy, then verifies the release identity. A corrected fixture reproduces the original failure.

GitHub App installation and controlled hosted publication remain unverified. The workflow refuses missing App configuration before acquisition or public writes. This draft does not qualify CSP6 as complete. Releases and live publisher activation require their separate deployment prerequisites.
