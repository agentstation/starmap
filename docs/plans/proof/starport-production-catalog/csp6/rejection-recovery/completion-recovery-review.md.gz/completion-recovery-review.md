autoreview clean: no accepted/actionable findings reported
overall: patch is correct (0.7)
The diff adds a manual `retry_receipt` replay path to the catalog publication inspector, relaxes/retightens the hosted release qualification check, adds a retry test module, and reuses catalog fixtures in two Go tests. I found no P0-level defect.

Retry logic (`scripts/catalog_publication.py`): the guard requires a well-formed receipt (`digest_hex`), a manual `workflow_dispatch` event, a non-nil pending record, an exact `receipt_checksum` match, and both channels completed, otherwise it raises `PublicationError`; otherwise `active` additionally becomes true for a same-`run_id` rerun or an explicit receipt, which suppresses fresh acquisition as documented. `event` was hoisted above its first new use and its later use in `acquire` is unchanged. The env var is only consumed as a comparison value, so the new workflow input is not an injection vector — it is passed via `env:` rather than interpolated into `run:`, and the `inputs` context evaluates to empty for schedule/workflow_run triggers, which the truthiness check handles.

Hosted qualification (`scripts/catalog_publication_hosted.py`): allowing prereleases while requiring `immutable is True` is a deliberate tightening; GitHub's release objects do expose a boolean `immutable` field, and the updated fixture plus new tests cover both the accepted and rejected shapes. The strictness would hard-fail for releases created before repository immutability was enabled, but nothing in the bundle proves that condition holds, so it is not an actionable P0 here.

Go test changes are isolation/perf adjustments: `sync.OnceValues` memoizes the embedded and files builders for read-only subtests (documented by the added comment), and dropping `t.Parallel()` in `TestDirectoryMigrationCompletionRecoversProcessExit` only serializes crash-point subtests. Neither alters production behavior.

Lower-priority observations (e.g., an explicit retry against a rejected record falling through to ordinary acquisition rather than erroring) are below the requested P0 threshold and are omitted.
