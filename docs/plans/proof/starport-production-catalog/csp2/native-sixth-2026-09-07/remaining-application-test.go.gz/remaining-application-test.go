package app

import (
 "os"
 "path/filepath"
 "testing"
 catalogconfig "github.com/agentstation/starmap/pkg/catalogs/config"
)

func TestCSP2SeparateApplicationInstancesRetainDistinctSeeds(t *testing.T) {
 clearCatalogEnvironment(t)
 home:=t.TempDir()
 paths:=map[string]string{"STARMAP_HOME":home,"STARMAP_INSTANCE_ID":"one"}
 values:=map[string]string{catalogconfig.Source:"embedded",catalogconfig.SourcePollInterval:"0s",catalogconfig.AcquisitionEnabled:"false"}
 first,err:=New("test","test","test","test",WithConfig(&Config{PathValues:paths,CatalogValues:values}));if err!=nil{t.Fatal(err)}
 defer first.closeRuntime()
 firstRuntime,err:=first.Runtime(t.Context());if err!=nil{t.Fatal(err)}
 firstPaths,err:=first.ResolvedPaths();if err!=nil{t.Fatal(err)}
 seedPath:=filepath.Join(firstPaths.Runtime.Path,"instance-seed")
 original,err:=os.ReadFile(seedPath);if err!=nil{t.Fatal(err)}
 second,err:=New("test","test","test","test",WithConfig(&Config{PathValues:map[string]string{"STARMAP_HOME":home,"STARMAP_INSTANCE_ID":"two"},CatalogValues:values}));if err!=nil{t.Fatal(err)}
 defer second.closeRuntime()
 secondRuntime,err:=second.Runtime(t.Context());if err!=nil{t.Fatal(err)}
 secondPaths,err:=second.ResolvedPaths();if err!=nil{t.Fatal(err)}
 if firstPaths.Runtime.Path==secondPaths.Runtime.Path||firstRuntime.Status().InstanceIdentity==secondRuntime.Status().InstanceIdentity {t.Fatal("separate instances reused runtime ownership")}
 duplicate,err:=New("test","test","test","test",WithConfig(&Config{PathValues:paths,CatalogValues:values}));if err!=nil{t.Fatal(err)}
 defer duplicate.closeRuntime()
 if _,err:=duplicate.Runtime(t.Context());err==nil{t.Fatal("duplicate local owner started")}
 after,err:=os.ReadFile(seedPath);if err!=nil||string(after)!=string(original){t.Fatal("duplicate owner changed the live seed")}
 t.Log("Two applications retain distinct runtime directories and identities; a duplicate cannot start or alter the seed.")
}

func TestCSP2ApplicationRefusesEmptyRequiredPathsBeforeWrites(t *testing.T) {
 for _,field:=range []string{"STARMAP_HOME","STARMAP_CATALOG_STORE_PATH",catalogconfig.StateDirectory} {
  t.Run(field,func(t *testing.T){
   clearCatalogEnvironment(t)
   home:=t.TempDir();paths:=map[string]string{"STARMAP_HOME":home};values:=map[string]string{catalogconfig.Source:"embedded",catalogconfig.AcquisitionEnabled:"false"}
   if field==catalogconfig.StateDirectory{values[field]=""}else{paths[field]=""}
   application,err:=New("test","test","test","test",WithConfig(&Config{PathValues:paths,CatalogValues:values}))
   if err==nil{defer application.closeRuntime();_,err=application.Runtime(t.Context())}
   if err==nil{t.Fatal("empty required path started persistent runtime")}
   entries,err:=os.ReadDir(home);if err!=nil||len(entries)!=0{t.Fatal("invalid path startup wrote state")}
  })
 }
}
