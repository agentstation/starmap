import gzip,hashlib,json,subprocess,time,uuid
from pathlib import Path
root=Path(__file__).resolve().parent
suffix=uuid.uuid4().hex
image='starmap-cold-prototype:'+suffix
volume='starmap-cold-prototype-'+suffix
containers=[]
report={'qualification':'Prototype only; no acceptance credit','commands':[],'observations':[]}
def run(args,timeout=120,required=True):
 p=subprocess.run(args,capture_output=True,text=True,timeout=timeout)
 result={'command':args,'exit_code':p.returncode,'stdout':p.stdout,'stderr':p.stderr}
 report['commands'].append(result)
 if required and p.returncode: raise RuntimeError('command failed: '+repr(args))
 return result
try:
 server=json.loads(run(['docker','version','--format','{{json .Server}}'])['stdout'])
 assert server['Os']=='linux' and server['Arch']=='arm64'
 report['server']=server
 for name in ['starmap','observe','observe.go','Dockerfile']:
  report[name+'_sha256']=hashlib.sha256((root/name).read_bytes()).hexdigest()
 report['build_info']=run(['go','version','-m',str(root/'starmap')])['stdout']
 run(['docker','build','--platform','linux/arm64','--network','none','--tag',image,str(root)],timeout=300)
 run(['docker','volume','create',volume])
 for phase in ['cold','restart']:
  name='starmap-cold-prototype-'+phase+'-'+suffix;containers.append(name)
  run(['docker','create','--name',name,'--platform','linux/arm64','--network','none','--read-only','--cap-drop','ALL','--security-opt','no-new-privileges=true','--user','65532:65532','--memory','512m','--cpus','2','--pids-limit','64','--mount','type=volume,src='+volume+',dst=/work','--env','HOME=/work','--env','STARMAP_HOME=/work/product',image])
  run(['docker','start',name])
  observation={'phase':phase}
  end=time.monotonic()+45
  while True:
   probe=run(['docker','exec',name,'/observe','http','http://127.0.0.1:8080/api/v1/ready'],required=False)
   if probe['exit_code']==0:
    ready=json.loads(probe['stdout'])
    if ready['status_code']==200: break
   state=json.loads(run(['docker','inspect',name])['stdout'])[0]['State']
   if not state['Running'] or time.monotonic()>end: raise RuntimeError('server did not become ready')
   time.sleep(.25)
  observation['ready']=ready
  def observe(mode,target): return json.loads(run(['docker','exec',name,'/observe',mode,target])['stdout'])
  observation['network']=observe('network','192.0.2.1:9')
  manifest=observe('http','http://127.0.0.1:8080/api/v1/catalog/manifest');observation['manifest']=manifest
  assert manifest['status_code']==200
  generation=manifest['generation_header'];assert generation
  observation['payload']=observe('http','http://127.0.0.1:8080/api/v1/catalog/generations/'+generation+'/payload')
  identity=hashlib.sha256(generation.encode()).hexdigest()
  baseline='/work/product/data/catalog/baseline/'+identity+'/'
  observation['baseline_manifest']=observe('file',baseline+'manifest.json')
  observation['baseline_payload']=observe('file',baseline+'catalog.json')
  assert observation['baseline_payload']['checksum']==observation['payload']['checksum']
  assert observation['baseline_payload']['mode']=='0600'
  assert observation['baseline_manifest']['mode']=='0600'
  inspection=json.loads(run(['docker','inspect',name])['stdout'])[0]
  assert inspection['HostConfig']['NetworkMode']=='none'
  assert inspection['Config']['User']=='65532:65532'
  observation['environment']=inspection['Config']['Env']
  assert not any('KEY=' in e or 'TOKEN=' in e for e in observation['environment'])
  run(['docker','stop','--time','15',name],timeout=30)
  observation['exit_state']=json.loads(run(['docker','inspect',name])['stdout'])[0]['State']
  assert observation['exit_state']['ExitCode']==0
  observation['logs']=run(['docker','logs',name])
  report['observations'].append(observation)
 assert report['observations'][0]['manifest']['body']==report['observations'][1]['manifest']['body']
 assert report['observations'][0]['payload']['checksum']==report['observations'][1]['payload']['checksum']
 report['status']='PASS'
except Exception as error:
 report['status']='FAIL';report['error']=str(error)
finally:
 for name in containers:
  report.setdefault('final_logs',[]).append(run(['docker','logs',name],required=False))
  run(['docker','rm','--force',name],required=False)
 run(['docker','volume','rm',volume],required=False)
 run(['docker','image','rm',image],required=False)
 data=json.dumps(report,indent=2).encode();(root/'report.json').write_bytes(data)
 print(json.dumps({'status':report['status'],'error':report.get('error'),'observations':len(report['observations'])}))
