Application startup persists the embedded catalog and reports canonical configuration and file paths on Linux, macOS, and Windows. Shared catalog settings separate private runtime state from the optional editable workspace.

The change adds checked file access, durable runtime ownership, migration journals, and scoped observation contracts. Library construction remains passive. Explicitly selected storage can read local or remote data. Automatic acquisition remains a separate action.

Windows migration retains the existing catalog commit lock through an external hard link. Access copying preserves complete descriptors, including automatic inheritance and protection flags. Workspace assembly temporarily grants the process user directory write access inside private staging. The grant does not inherit to children. Assembly restores the original descriptor before final verification and publication.

Pattern scan parents have no managed-file access policy. Matching files and managed tree roots retain their checks. Baseline publication closes staged writers and records final timestamps before promotion.

The follow-up adds connected acquisition, baseline-preserving resets, indexed offering lookup, and explicitly selected service-managed primary configuration. Scoped deletion enforcement and final production qualification remain open.

All 39 repository verification stages pass across two segments with Go 1.26.6. The initial run passed 32 stages before a prose failure. Ordinary and race tests each passed 79 package suites. After the comment correction, the seven remaining stages passed. Workspace race tests, Windows-targeted lint, Ago analysis, and both Windows architecture builds with Go 1.25.12 pass.

The required Sol and Opus cross-lab review passed all eight portions with no findings on the complete substantive diff.

The published predecessor passed all four Linux and macOS runtime jobs. Both Windows architectures recorded 1,055 passing test events and one workspace assembly failure. Complete descriptor preservation passed. This staging write-access repair requires native execution. This draft is not production-qualified.
