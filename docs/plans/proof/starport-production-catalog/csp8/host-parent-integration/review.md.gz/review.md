autoreview clean: no accepted/actionable findings reported
overall: patch is correct (0.7)
This change is primarily an extraction/re-export refactor: bootstrap.Export is re-exported as starmap.ExportEmbeddedBaseline, the inline config-read logic in internal/cli/app/config.go moves to pkg/productpaths.ReadConfiguration, workspace file-inventory construction moves from internal/cli/app/file_manifest.go to pkg/productpaths.WorkspaceFiles, and a new public pkg/productfiles wrapper exposes internal/privatefiles operations.

Behavior-bearing pieces checked:

- internal/privatefiles/directory.go: the new (create, exclusive) parameterization preserves prior Child() semantics exactly (create=true, exclusive=false reduces to the original `os.IsNotExist(err) && create` plus `!os.IsExist(err)` tolerance), and CreateChild always attempts creation and surfaces ErrExist unchanged.
- pkg/productpaths/input.go: readInput reproduces the removed ValidateAncestors -> EvalSymlinks -> ValidateAncestors -> OpenRoot(dir) -> bounded-read sequence, still joins root.Close(), and adds nil-context/NUL/max-bytes validation. The only delta is returning nil data alongside an error instead of partial data, which callers already treat as failure.
- internal/cli/app/config.go: hardcoding Explicit: true preserves pre-patch behavior at that call site (previously there was no explicitness gate at all), so the new policy.Configuration gate is additive rather than a regression.
- pkg/productpaths/workspace.go: entry IDs, ordering, file/pattern kinds, and the glob-escaping Replacer are copied verbatim; the 8-entry count and disabled-path early return match prior behavior, and selectors are cloned per entry so callers cannot alias shared state.
- pkg/productfiles/directory.go: every method gates on check()/checkContext(), so nil and zero-value receivers return validation errors rather than panicking.
- The Windows ancestors test correctly moves to the external privatefiles_test package, which is required now that productpaths imports internal/privatefiles (an in-package test importing productpaths would be an import cycle).

Remaining uncertainties (possible unused imports in the trimmed config.go / ancestors_windows_test.go import blocks, and the exact semantics of policy.Require/policy.Configuration/policy.ForRole) depend on unchanged context absent from the bundle, so per scope rules I did not raise them. I found no P0-level defect.
