Source acquisition uses Starport's cache root, including the session cache during development.
The models.dev HTTP cache uses `models.dev/`. Its managed Git checkout uses `sources/models.dev-git/`.
`STARPORT_CATALOG_ACQUISITION_SOURCES` selects permitted provider and metadata sources. An explicit empty value disables them all.
`STARPORT_CATALOG_ACQUISITION_ENABLED=false` stops automatic observations. Explicit refresh can still collect permitted sources.
Offline mode and internal authority continue to restrict explicit acquisition.


openRuntime composes the connected runtime with host-supplied provider and metadata collectors.
SourceCacheDirectory selects the host-owned parent for source caches and checkouts.
AcquisitionEnabled controls automatic observations. Explicit refresh still checks network and authority policy.
AcquisitionEnabled controls automatic observations. Explicit refresh still checks network and authority policy.
