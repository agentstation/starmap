import datetime,hashlib,json,os,subprocess,time,uuid
from pathlib import Path
root=Path('/Users/jack/src/github.com/agentstation/starmap-object-ci-repair')
consumer=Path('/Users/jack/src/github.com/agentstation/starport-native-catalog')
out=Path('/tmp/csp8-final-native-qualification');out.mkdir(exist_ok=False)
report={'started_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':'running','services':[]}
def command(args):return subprocess.check_output(args,text=True).strip()
def save(): (out/'runner.json').write_text(json.dumps(report,indent=2)+'\n')
env=dict(os.environ,GOTOOLCHAIN='go1.27.1',GOWORK='off')
env.update(CATALOG_DRIVEN_STARMAP_ROOT=str(root), STARMAP_OWNERSHIP_STARMAP_ROOT=str(root), CSP_STARPORT_WORKTREE=str(consumer), CATALOG_DISTRIBUTION_STARPORT_ROOT=str(consumer))
created=[]
try:
 report['producer']=command(['git','-C',str(root),'rev-parse','HEAD'])
 report['consumer']=command(['git','-C',str(consumer),'rev-parse','HEAD'])
 report['source_diff_sha256']=hashlib.sha256(subprocess.check_output(['git','diff','HEAD','--'],cwd=consumer)).hexdigest()
 report['module_files']={name:hashlib.sha256((consumer/name).read_bytes()).hexdigest() for name in ['go.mod','go.sum']}
 report['consumer_module']=subprocess.check_output(['go','list','-m','github.com/agentstation/starmap'],cwd=consumer,env=env,text=True).strip()
 for role,image,port,args in [('durable','valkey/valkey@sha256:9acdf6f0ae1771ea63c401e127054b2d1779227b9230dcfae37fa684610eaa4f',6379,[]),('cache','valkey/valkey@sha256:9acdf6f0ae1771ea63c401e127054b2d1779227b9230dcfae37fa684610eaa4f',6379,[]),('sql','postgres@sha256:f1c3376c26f2609ab9f29f71f824103fe2fcd8ee0346485cb6122a4f93df6f94',5432,['-e','POSTGRES_HOST_AUTH_METHOD=trust','-e','POSTGRES_DB=starport'])]:
  name='csp8-task-'+role+'-'+uuid.uuid4().hex[:10]
  cid=command(['docker','run','-d','--name',name,'-p','127.0.0.1::'+str(port),*args,image]);created.append(cid)
  address=command(['docker','port',cid,str(port)+'/tcp'])
  report['services'].append({'role':role,'id':cid,'image':image,'address':address})
  if role=='durable':env['TEST_VALKEY_URL']='redis://'+address
  elif role=='cache':env['TEST_SHARED_CACHE_URL']='redis://'+address
  else:env['TEST_POSTGRES_URL']='postgres://postgres@'+address+'/starport?sslmode=disable'
  ready=['docker','exec',cid]+(['valkey-cli','ping'] if role!='sql' else ['pg_isready','-U','postgres','-d','starport'])
  deadline=time.monotonic()+45
  while subprocess.run(ready,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL).returncode:
   if time.monotonic()>deadline:raise RuntimeError('Test service startup failed')
   time.sleep(.5)
 report['command']=['bash','scripts/verify-catalog-product.sh','--starport-root',str(consumer),'--task','CSP8','--json'];save()
 start=time.monotonic()
 with (out/'acceptance.json').open('w') as stdout,(out/'acceptance.stderr').open('w') as stderr:
  result=subprocess.run(report['command'],cwd=root,env=env,stdout=stdout,stderr=stderr,timeout=3600)
 report.update(exit_code=result.returncode,seconds=time.monotonic()-start,status='PASS' if result.returncode==0 else 'NOT_PASS')
except Exception as error:report.update(status='ERROR',error=str(error));raise
finally:
 report['cleanup']=[{'id':cid,'exit_code':subprocess.run(['docker','rm','-f',cid],stdout=subprocess.DEVNULL).returncode} for cid in created]
 report['finished_at']=datetime.datetime.now(datetime.timezone.utc).isoformat();save()
 print(json.dumps(report))

raise SystemExit(report.get('exit_code', 1) if report['status'] != 'PASS' else 0)
