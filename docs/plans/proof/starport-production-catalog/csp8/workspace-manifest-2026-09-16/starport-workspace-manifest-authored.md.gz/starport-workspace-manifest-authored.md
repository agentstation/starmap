Workspace entries include adjacent projection receipts, replacement journals, writer locks, candidates, and backups.
Starmap supplies these file names and access policies to both products. Each entry retains the selected workspace origin.
Disabled workspaces have no sibling entries. Inventory and inspection do not authorize removal of recovery files.

