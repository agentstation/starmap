set -euo pipefail
# Catalog recovery starts cold child processes. Give that package
# the runner before the remaining packages share its CPU and memory.
go list ./... > /tmp/starport-native-schedule-evidence/packages.txt
remaining=()
while IFS= read -r package; do
  if [[ "$package" != "github.com/agentstation/starport/internal/catalog" ]]; then
    remaining+=("$package")
  fi
done < /tmp/starport-native-schedule-evidence/packages.txt
coverage=()
if [[ "ubuntu-24.04" == "ubuntu-24.04" ]]; then
  coverage=(-coverprofile=/tmp/starport-native-schedule-evidence/catalog.coverage.txt -covermode=atomic)
fi
go test -json -count=1 -timeout 5m -race "${coverage[@]}" ./internal/catalog | tee /tmp/starport-native-schedule-evidence/tests.jsonl
coverage=()
if [[ "ubuntu-24.04" == "ubuntu-24.04" ]]; then
  coverage=(-coverprofile=/tmp/starport-native-schedule-evidence/remaining.coverage.txt -covermode=atomic)
fi
go test -json -count=1 -timeout 5m -race "${coverage[@]}" "${remaining[@]}" | tee -a /tmp/starport-native-schedule-evidence/tests.jsonl
if [[ "ubuntu-24.04" == "ubuntu-24.04" ]]; then
  cat /tmp/starport-native-schedule-evidence/catalog.coverage.txt > /tmp/starport-native-schedule-evidence/combined.coverage.txt
  tail -n +2 /tmp/starport-native-schedule-evidence/remaining.coverage.txt >> /tmp/starport-native-schedule-evidence/combined.coverage.txt
fi

