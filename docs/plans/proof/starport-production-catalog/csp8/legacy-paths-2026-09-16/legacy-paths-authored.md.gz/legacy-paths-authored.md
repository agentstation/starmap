Before an upgrade, run `starport config paths --legacy --json` to inspect previous default locations.
The report lists existing paths that the new defaults would abandon. It reads metadata without opening databases or reading their contents.
Startup and local initialization refuse these conflicts before creating replacement stores. They preserve the old files, including conflicting or incomplete state.

Older versions keep local data under `<previous-config>/data/` and catalog runtime state under the XDG state root.
On macOS, the default primary configuration moves from `starport/config.env` to `starport/config/config.env` under Application Support.
The report names the exact old path, selected path, and configuration selector.

Set explicit paths to retain the previous locations while preparing a verified migration. Changing a selector does not copy files or prove migration completion.
Runtime ownership checks still apply. A retained runtime from another owner requires ownership migration before use.

Explicit roots and leaf paths keep their selected locations. Development storage and unselected database backends do not inspect legacy data.
Use `--legacy` separately from `--files` and `--inspect`. This command does not migrate or remove old state.

