from pathlib import Path
import subprocess,uuid,time,os,json,datetime
out=Path('/tmp/csp12-budget-native');out.mkdir(exist_ok=True)
image='valkey/valkey@sha256:9acdf6f0ae1771ea63c401e127054b2d1779227b9230dcfae37fa684610eaa4f'
report={'started':datetime.datetime.now(datetime.timezone.utc).isoformat(),'image':image};cid=None
try:
 cid=subprocess.check_output(['docker','run','-d','--name','csp12-budget-'+uuid.uuid4().hex[:8],'-p','127.0.0.1::6379',image],text=True).strip()
 for _ in range(100):
  if subprocess.run(['docker','exec',cid,'valkey-cli','ping'],capture_output=True).returncode==0:break
  time.sleep(.2)
 else:raise RuntimeError('Valkey not ready')
 address=subprocess.check_output(['docker','port',cid,'6379/tcp'],text=True).strip()
 env=dict(os.environ,GOWORK='off',GOTOOLCHAIN='go1.27.1',TEST_VALKEY_URL='redis://'+address)
 pattern='^(TestBudgetStorageErrorRefuses|TestTeamBudgetReadErrorRefuses|TestBudgetMiddlewarePassesKeysWithoutBudgets|TestBatchBudgetUnknownRequiredStateRefuses|TestBatchBudgetConfirmedAbsenceNeedsNoUsageReader|TestCachedTeamBudgetUsesAdmittedPolicy|TestAuthorizationUnknownAccountRefusesAdmission)$'
 cmd=['go','test','-json','-race','-count=1','-timeout=3m','./internal/server','-run',pattern];report['command']=cmd
 with (out/'tests.jsonl').open('w') as stdout,(out/'stderr.log').open('w') as stderr:
  report['exit_code']=subprocess.run(cmd,cwd='/tmp/starport-fleet-review-20260926',env=env,stdout=stdout,stderr=stderr,timeout=240).returncode
finally:
 report['cleanup']=subprocess.run(['docker','rm','-f',cid],capture_output=True).returncode if cid else None
 report['finished']=datetime.datetime.now(datetime.timezone.utc).isoformat();(out/'runner.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
