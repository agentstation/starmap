autoreview clean: no accepted/actionable findings reported
overall: patch is correct (0.7)
Reviewed against the requested P0-only threshold; no catastrophic or pervasive defect found.

Checked in depth:

1. Lifecycle/shutdown. `fillQueue.close()` sets `closed` under the mutex, cancels the worker context, joins workers, then drains the channel with no concurrent receiver. `Manager.Close` and `BufferedLocalCache.Close` are once-guarded and close stores only after joining workers. `admit` uses `TryLock` plus a non-blocking channel send, so there is no lock-ordering deadlock with `run()`. The double-close path in `app.openCache` (manager close plus `responseStore.Close()`) is safe because `SharedStore.Close` is `sync.Once`-guarded.

2. Nil safety of the new admin readers. `Manager.FillStatus()` and `BufferedLocalCache.FillStatus()` both nil-check their receivers, so `deployment()` reading `b.application.cacheManager.FillStatus()` / `extractionCache.FillStatus()` cannot panic when either cache is disabled.

3. Strategy validation. `NewCacheManager` rejects store-without-`distributed` and `distributed`-without-store before allocating the models cache, so no store leaks on those error paths.

4. Stream rework. `streamChoice` keeps the `arguments` builders index-aligned with `Message.ToolCalls` (both are appended only in the unmatched branch), `appendText` preserves the original "find the existing text part" semantics, and `complete()` writes back before `Clone()`. `cachingStreamWrapper` guards `buffer` with `cacheMu` in both `Read` and `Close`, and discards on any terminal error.

5. Typed discovery decode. `cacheListResponse` presets `CacheStatus: CacheStatusHit` before unmarshal; the new warm-hit `JSONEq` assertion in `TestDiscoveryCacheTracksAdapterRevision` against the uncached response implies `CacheStatus` is not serialized, so the preset is not clobbered by decoding.

6. Endpoint/trust validation. `connection.Parse`, `LoadRoots`, and `CacheConfig.Validate` reject query/fragment smuggling, non-numeric database paths, remote plaintext without explicit opt-in, durable/cache service collocation, and oversize or non-regular CA files, with errors that omit URI and credential values.

Lower-priority observations exist but fall below the P0 threshold: `proxy.WithDocumentCache(extractions)` is now called unconditionally and may receive a typed-nil `*document.Cache` when extraction caching is disabled (only reachable on a non-default config, and the workaround is to leave caching enabled); the 2 ms shared-cache read deadline is very tight for a networked service, though it degrades to a miss rather than an error surface; and `storage.LifetimeReader` has no consumer in this bundle.
