package settings_test

import (
	"fmt"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"sync"
	"testing"
	"time"

	"github.com/agentstation/starmap"
	"github.com/agentstation/starmap/internal/catalog/settings"
	"github.com/agentstation/starmap/pkg/catalogs"
	protocol "github.com/agentstation/starmap/pkg/catalogs/remote"
	"github.com/agentstation/starmap/pkg/catalogs/storage"
	"github.com/agentstation/starmap/runtime"
)

func TestCompositionClosesBuiltCascade(t *testing.T) {
	generation, err := starmap.EmbeddedGeneration()
	if err != nil {
		t.Fatal(err)
	}
	manifest, err := protocol.MarshalManifest(generation.Manifest)
	if err != nil {
		t.Fatal(err)
	}
	streamStarted := make(chan struct{})
	streamStopped := make(chan struct{})
	release := make(chan struct{})
	var started, stopped sync.Once
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/api/v1" + protocol.ManifestPath:
			w.Header().Set("Content-Type", protocol.ManifestMediaType)
			_, _ = w.Write(manifest)
		case "/api/v1" + protocol.PayloadPath(generation.Manifest.GenerationID):
			w.Header().Set("Content-Type", catalogs.CatalogPayloadMediaType)
			_, _ = w.Write(generation.Payload)
		case "/api/v1" + protocol.EventStreamPath:
			w.Header().Set("Content-Type", protocol.EventStreamMediaType)
			_, _ = fmt.Fprint(w, ": connected\n\n")
			w.(http.Flusher).Flush()
			started.Do(func() { close(streamStarted) })
			select {
			case <-r.Context().Done():
				stopped.Do(func() { close(streamStopped) })
			case <-release:
			}
		default:
			http.NotFound(w, r)
		}
	}))
	t.Cleanup(server.Close)
	t.Cleanup(func() { close(release) })
	values := map[string]string{
		settings.Source: "starmap", settings.SourceURL: server.URL + "/api/v1",
		settings.SourcePollInterval: "0s", settings.AcquisitionEnabled: "false",
		settings.StateDirectory: filepath.Join(t.TempDir(), "runtime"),
	}
	config, err := settings.Load(func(name string) (string, bool) {
		value, present := values[name]
		return value, present
	})
	if err != nil {
		t.Fatal(err)
	}
	connected, err := (settings.Composition{Config: config,
		Base: []runtime.Option{runtime.WithClientOptions(starmap.WithCatalogStore(storage.NewMemory()))},
	}).Open(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = connected.Close() })
	if _, err := connected.RefreshSource(t.Context()); err != nil {
		t.Fatal(err)
	}
	select {
	case <-streamStarted:
	case <-time.After(5 * time.Second):
		t.Fatal("cascade did not open its event stream")
	}
	if err := connected.Close(); err != nil {
		t.Fatal(err)
	}
	select {
	case <-streamStopped:
	case <-time.After(time.Second):
		t.Fatal("runtime shutdown left its constructed cascade stream active")
	}
}
