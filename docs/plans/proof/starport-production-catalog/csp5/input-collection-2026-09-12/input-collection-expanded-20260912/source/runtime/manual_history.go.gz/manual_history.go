package runtime

import (
	"context"
	"encoding/json"
	"slices"

	"github.com/agentstation/starmap/internal/privatefiles"
	"github.com/agentstation/starmap/pkg/errors"
	"github.com/agentstation/starmap/pkg/sources"
)

const (
	manualHistoryName            = "manual.json"
	manualHistoryVersion         = 4
	manualHistoryResetVersion    = 3
	manualHistoryProviderVersion = 2
	manualHistoryLegacyVersion   = 1
	// maxManualHistoryBatches bounds linked records between checkpoints.
	maxManualHistoryBatches = 4096
)

var manualHistoryCapacity = invalidInputPublication("manual history requires compaction before another batch")

// manualBatch is an immutable accepted-input node. Parents precede their children.
type manualBatch struct {
	reference       string
	parent          *manualBatch
	observations    []manualObservation
	resets          []ObservationReset
	checkpoint      *manualCheckpoint
	checkpointBytes int
	packed          []*manualBatch
}

type manualBatchRecord struct {
	Version      int                `json:"version"`
	Checkpoint   *manualCheckpoint  `json:"checkpoint,omitempty"`
	Parent       string             `json:"parent,omitempty"`
	Observations []string           `json:"observations"`
	Resets       []ObservationReset `json:"resets,omitempty"`
}

type manualHistoryHead struct {
	Version int    `json:"version"`
	Batch   string `json:"batch"`
}

func (s *layerStore) stageManualBatch(ctx context.Context, batch *manualBatch) (string, error) {
	if err := ctx.Err(); err != nil {
		return "", err
	}
	if batch.checkpoint != nil {
		return s.stageInput(ctx, manualBatchRecord{Version: manualHistoryVersion, Checkpoint: batch.checkpoint})
	}
	record := manualBatchRecord{Version: manualHistoryVersion, Resets: batch.resets}
	if batch.parent != nil {
		if batch.parent.reference == "" {
			reference, err := s.stageManualBatch(ctx, batch.parent)
			if err != nil {
				return "", err
			}
			batch.parent.reference = reference
		}
		record.Parent = batch.parent.reference
	}
	for _, observation := range batch.observations {
		name, err := s.stageInput(ctx, observation)
		if err != nil {
			return "", err
		}
		record.Observations = append(record.Observations, name)
	}
	return s.stageInput(ctx, record)
}

func (s *layerStore) saveManualHead(ctx context.Context, reference string) error {
	if !s.durable() {
		return ctx.Err()
	}
	return s.writeContext(ctx, s.directory, manualHistoryName, manualHistoryHead{Version: manualHistoryVersion, Batch: reference})
}

func (s *layerStore) loadManualHistory(ctx context.Context) (*manualBatch, error) {
	if !s.durable() {
		return nil, nil
	}
	raw, err := readLayerFile(s.directory, manualHistoryName)
	if err != nil || raw == nil {
		return nil, err
	}
	var head manualHistoryHead
	if err := decodeInputRecord(raw, &head); err != nil {
		return nil, err
	}
	if !supportedManualHistoryVersion(head.Version) || head.Batch == "" {
		return nil, invalidInputPublication("invalid manual history head")
	}
	return s.readManualHistory(ctx, head.Batch)
}

func (s *layerStore) readManualHistory(ctx context.Context, reference string) (*manualBatch, error) {
	directory, err := s.directory.ExistingChild(inputPublicationDirectory)
	if err != nil {
		return nil, err
	}
	var newest, child *manualBatch
	seen := make(map[string]bool)
	bytesRead := 0
	for reference != "" {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		if seen[reference] {
			return nil, invalidInputPublication("manual history contains a repeated batch")
		}
		seen[reference] = true
		if len(seen) > maxManualHistoryBatches {
			return nil, invalidInputPublication("manual history exceeds the batch bound")
		}
		batch, parent, err := s.readManualBatch(ctx, directory, reference, &bytesRead)
		if err != nil {
			return nil, err
		}
		if child == nil {
			newest = batch
		} else {
			child.parent = batch
		}
		child, reference = batch, parent
	}
	return newest, nil
}

func selectManualObservations(ctx context.Context, history *manualBatch, input []manualObservation, resets []ObservationReset) ([]manualObservation, error) {
	if len(input) == 0 {
		return nil, nil
	}
	incomingBytes, err := observationResetBytes(resets)
	if err != nil {
		return nil, err
	}
	seen := make(map[string]bool)
	bytesRetained, batches := incomingBytes, 0
	for batch := history; batch != nil; batch = batch.parent {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		batches++
		if batch.checkpoint != nil {
			bytesRetained += batch.checkpointBytes
			for _, observation := range batch.checkpoint.Observations {
				seen[observation.Receipt.Link.ObservationID] = true
			}
			continue
		}
		size, err := observationResetBytes(batch.resets)
		if err != nil {
			return nil, err
		}
		bytesRetained += size
		for _, observation := range batch.observations {
			if err := ctx.Err(); err != nil {
				return nil, err
			}
			seen[observation.Receipt.Link.ObservationID] = true
			encoded, err := json.Marshal(observation)
			if err != nil {
				return nil, err
			}
			bytesRetained += len(encoded)
		}
	}
	selected := make([]manualObservation, 0, len(input))
	incomingSeen := make(map[string]bool)
	for _, observation := range input {
		if err := ctx.Err(); err != nil {
			return nil, err
		}
		if incomingSeen[observation.Receipt.Link.ObservationID] || (len(resets) == 0 && seen[observation.Receipt.Link.ObservationID]) {
			continue
		}
		incomingSeen[observation.Receipt.Link.ObservationID] = true
		encoded, err := json.Marshal(observation)
		if err != nil {
			return nil, err
		}
		bytesRetained += len(encoded)
		selected = append(selected, observation)
	}
	if len(selected) != 0 && (batches >= maxManualHistoryBatches || bytesRetained > maxLayerBytes) {
		return selected, manualHistoryCapacity
	}
	return selected, nil
}

func (s *layerStore) readManualBatch(ctx context.Context, directory *privatefiles.Directory, reference string, bytesRead *int) (*manualBatch, string, error) {
	var record manualBatchRecord
	if err := s.readInput(directory, reference, &record); err != nil {
		return nil, "", err
	}
	if err := validateManualBatchShape(record); err != nil {
		return nil, "", err
	}
	if record.Checkpoint != nil {
		batch, err := restoreManualCheckpoint(ctx, record.Checkpoint)
		if err != nil {
			return nil, "", err
		}
		*bytesRead += batch.checkpointBytes
		if *bytesRead > maxLayerBytes {
			return nil, "", invalidInputPublication("manual history exceeds the retained checkpoint byte bound")
		}
		batch.reference = reference
		return batch, "", nil
	}
	resets, err := prepareObservationResets(record.Resets)
	if err != nil {
		return nil, "", err
	}
	size, err := observationResetBytes(resets)
	if err != nil {
		return nil, "", err
	}
	*bytesRead += size
	if *bytesRead > maxLayerBytes {
		return nil, "", invalidInputPublication("manual history exceeds the retained byte bound")
	}
	batch := &manualBatch{reference: reference, resets: resets}
	seen := make(map[string]bool, len(record.Observations))
	for _, reference := range record.Observations {
		if err := ctx.Err(); err != nil {
			return nil, "", err
		}
		if seen[reference] {
			return nil, "", invalidInputPublication("manual batch contains duplicate observations")
		}
		seen[reference] = true
		var observation manualObservation
		if err := s.readInput(directory, reference, &observation); err != nil {
			return nil, "", err
		}
		encoded, err := json.Marshal(observation)
		if err != nil {
			return nil, "", err
		}
		*bytesRead += len(encoded)
		if *bytesRead > maxLayerBytes {
			return nil, "", invalidInputPublication("manual history exceeds the observation byte bound")
		}
		if _, err := observation.restore(); err != nil {
			return nil, "", err
		}
		batch.observations = append(batch.observations, observation)
	}
	if err := validateObservationReplacement(ctx, batch.resets, batch.observations); err != nil {
		return nil, "", err
	}
	return batch, record.Parent, nil
}

// validateManualBatchShape validates a record without requiring its referenced files.
// Unreachable batches can remain after collection removes some of their inputs.
func validateManualBatchShape(record manualBatchRecord) error {
	if record.Checkpoint != nil {
		if record.Version != manualHistoryVersion || record.Parent != "" || len(record.Observations) != 0 || len(record.Resets) != 0 {
			return invalidInputPublication("checkpoint requires an exclusive version 4 record")
		}
		return nil
	}
	if !supportedManualHistoryVersion(record.Version) || len(record.Observations) == 0 || (record.Version == manualHistoryLegacyVersion && len(record.Resets) > 0) {
		return invalidInputPublication("invalid manual observation batch")
	}
	if record.Parent != "" && !validInputReference(record.Parent) {
		return invalidInputPublication("invalid input reference")
	}
	if record.Version == manualHistoryProviderVersion {
		for _, reset := range record.Resets {
			if reset.SourceID != "" {
				return invalidInputPublication("metadata resets require manual history version 3")
			}
		}
	}
	seen := make(map[string]bool, len(record.Observations))
	for _, reference := range record.Observations {
		if !validInputReference(reference) || seen[reference] {
			return invalidInputPublication("invalid or duplicate observation reference")
		}
		seen[reference] = true
	}
	return nil
}

func manualBatches(history *manualBatch) []*manualBatch {
	var batches []*manualBatch
	for batch := history; batch != nil; batch = batch.parent {
		batches = append(batches, batch)
	}
	slices.Reverse(batches)
	var ordered []*manualBatch
	for _, batch := range batches {
		if batch.checkpoint != nil {
			ordered = append(ordered, batch.packed...)
		} else {
			ordered = append(ordered, batch)
		}
	}
	return ordered
}

func validateManualHistory(history *manualBatch, policy *providerBindingPolicy) error {
	for _, batch := range manualBatches(history) {
		if err := policy.validateManual(batch.observations, false); err != nil {
			return errors.WrapResource("validate", "manual history", batch.reference, err)
		}
	}
	return nil
}

// manualInputs retains observations for manual, partial, and omitted-record publication.
func (l *layerSet) manualInputs(ctx context.Context, input []manualObservation, providers []ProviderLayer) ([]manualObservation, error) {
	partial := slices.ContainsFunc(providers, func(layer ProviderLayer) bool {
		return layer.Receipt.Link.Completeness != sources.ObservationCompletenessComplete || layer.Receipt.Link.Status != sources.ObservationStatusSucceeded
	})
	retain := len(input) != 0 || partial
	if !retain && l.manual == nil {
		var err error
		retain, err = l.providerInventoryOmitsRecords(ctx, providers)
		if err != nil {
			return nil, err
		}
	}
	if retain && l.manual == nil {
		input = append(l.manualProviderAnchors(), input...)
	}
	if l.manual != nil || retain {
		for _, layer := range providers {
			input = append(input, manualObservation{Payload: layer.Payload, Receipt: layer.Receipt})
		}
	}
	return input, nil
}

func (l *layerSet) manualProviderAnchors() []manualObservation {
	anchors := make([]manualObservation, 0, len(l.providers))
	for _, key := range l.activeProviderOrder() {
		layer := l.providers[key]
		anchors = append(anchors, manualObservation{Payload: layer.Payload, Receipt: layer.Receipt})
	}
	return anchors
}

// prepareManualInputs anchors prior provider files before the first reset batch.
func (l *layerSet) prepareManualInputs(ctx context.Context, input []manualObservation, providers []ProviderLayer, resets []ObservationReset) ([]manualObservation, error) {
	if len(resets) > 0 && l.manual == nil {
		anchors := l.manualProviderAnchors()
		if len(anchors) > 0 {
			l.manual = &manualBatch{observations: anchors}
		}
	}
	input, err := l.manualInputs(ctx, input, providers)
	if err != nil {
		return nil, err
	}
	selected, err := selectManualObservations(ctx, l.manual, input, resets)
	if err != nil && err != manualHistoryCapacity {
		return nil, err
	}
	history := l.manual
	if err == manualHistoryCapacity && len(resets) == 0 {
		history, err = compactRepeatedProviderHistory(ctx, history)
		if err != nil {
			return nil, err
		}
		selected, err = selectManualObservations(ctx, history, input, resets)
		if err != nil && err != manualHistoryCapacity {
			return nil, err
		}
	}
	if len(selected) == 0 {
		return selected, err
	}
	candidate := &manualBatch{parent: history, observations: selected, resets: resets}
	if err == manualHistoryCapacity {
		candidate, err = checkpointManualHistory(ctx, candidate)
		if err != nil {
			return nil, err
		}
	}
	l.manual = candidate
	return selected, nil
}

func supportedManualHistoryVersion(version int) bool {
	return version == manualHistoryLegacyVersion || version == manualHistoryProviderVersion || version == manualHistoryResetVersion || version == manualHistoryVersion
}
