package runtime

import (
	"context"
	"slices"
	"testing"
	"time"

	"github.com/agentstation/starmap/pkg/sources"
)

type retainedInputCollector interface {
	CollectRetainedInputs(context.Context, InputCollectionRequest) (InputCollectionReport, error)
}

func TestRuntimeInputCollectionPreservesAcceptedHistory(t *testing.T) {
	r := openTestRuntime(t, WithStateDirectory(privateRuntimeDirectory(t)), WithCatalogSource("embedded"))
	collector, ok := any(r).(retainedInputCollector)
	if !ok {
		t.Fatal("runtime has no collection operation that preserves accepted input references")
	}
	at := time.Date(2026, 9, 12, 0, 0, 0, 0, time.UTC)
	observation := providerResetObservation(t, sources.ModelsDevHTTPID, manualProviderObservation(t, 200, at).Catalog, at, nil)
	prepared, err := prepareManualObservations(t.Context(), []sources.Observation{observation})
	if err != nil {
		t.Fatal(err)
	}
	history := &manualBatch{observations: prepared}
	reference, err := r.store.stageManualBatch(t.Context(), history)
	if err != nil {
		t.Fatal(err)
	}
	history.reference = reference
	if err := r.store.saveManualHead(t.Context(), reference); err != nil {
		t.Fatal(err)
	}
	r.layers.manual = history
	orphanObservation := providerResetObservation(t, sources.ModelsDevHTTPID, observation.Catalog, at.Add(time.Minute), nil)
	orphans, err := prepareManualObservations(t.Context(), []sources.Observation{orphanObservation})
	if err != nil {
		t.Fatal(err)
	}
	orphan, err := r.store.stageInput(t.Context(), orphans[0])
	if err != nil {
		t.Fatal(err)
	}
	before := r.State()
	report, err := collector.CollectRetainedInputs(t.Context(), InputCollectionRequest{MaxEntries: 64, MaxBytes: maxLayerBytes})
	if err != nil || len(report.Removed) != 1 || report.Removed[0] != orphan || !slices.Contains(report.Protected, reference) {
		t.Fatalf("collection lost reference boundaries: %+v, %v", report, err)
	}
	reloaded, err := r.store.loadManualHistory(t.Context())
	if err != nil || reloaded == nil || reloaded.reference != reference || len(reloaded.observations) != 1 {
		t.Fatalf("accepted history did not survive collection: %+v, %v", reloaded, err)
	}
	if after := r.State(); after.GenerationID != before.GenerationID || after.PayloadChecksum != before.PayloadChecksum {
		t.Fatal("input collection changed the serving catalog")
	}
}
