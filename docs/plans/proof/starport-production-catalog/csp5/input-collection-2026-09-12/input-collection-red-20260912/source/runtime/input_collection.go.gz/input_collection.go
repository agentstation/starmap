package runtime

// InputCollectionRequest bounds one explicit inspection of retained input files.
// MaxEntries includes unknown directory entries. MaxBytes bounds raw snapshot bytes.
// DryRun validates references and reports candidates without deleting files.
type InputCollectionRequest struct {
	MaxEntries int
	MaxBytes   int64
	DryRun     bool
}

// InputCollectionReport separates protected references from unrecognized files and removable inputs.
// SnapshotBytes counts captured raw records, excluding decoder and filesystem verification work.
// Removed includes visible deletions when later directory synchronization fails.
type InputCollectionReport struct {
	Scanned       int
	SnapshotBytes int64
	Protected     []string
	Preserved     []string
	Candidates    []string
	Removed       []string
}
