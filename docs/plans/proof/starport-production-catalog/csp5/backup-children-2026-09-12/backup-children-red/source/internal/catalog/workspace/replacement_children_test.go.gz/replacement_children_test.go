package workspace

import (
	"encoding/json"
	"os"
	"path/filepath"
	"reflect"
	"testing"
)

func TestJournalRecoveryPreservesIdenticalBackupChildren(t *testing.T) {
	for _, directory := range []bool{false, true} {
		t.Run(map[bool]string{false: "file", true: "directory"}[directory], func(t *testing.T) {
			f := interruptedReplacement(t, replacementMarkerSaved)
			var name string
			for _, entry := range f.record.Old.Entries {
				if entry.Path != "." && entry.Directory == directory {
					name = entry.Path
					break
				}
			}
			if name == "" {
				t.Fatal("fixture has no matching backup child")
			}
			child := filepath.Join(filepath.Dir(f.path), f.record.Backup, filepath.FromSlash(name))
			replaceBackupChild(t, child, directory)
			saved, err := os.Stat(child)
			if err != nil {
				t.Fatal(err)
			}
			_, recoveryErr := Repair(t.Context(), f.path, f.catalog, f.identity)
			after, err := os.Stat(child)
			if err != nil || !os.SameFile(saved, after) {
				t.Fatalf("recovery removed identical replacement child: recovery=%v, file=%v", recoveryErr, err)
			}
			assertReadConflict(t, recoveryErr)
			assertWorkspaceModel(t, f.path, "new", "New Model")
		})
	}
}

func replaceBackupChild(t *testing.T, child string, directory bool) {
	t.Helper()
	saved := filepath.Join(t.TempDir(), "original")
	if err := os.Rename(child, saved); err != nil {
		t.Fatal(err)
	}
	if directory {
		if err := os.CopyFS(child, os.DirFS(saved)); err != nil {
			t.Fatal(err)
		}
		return
	}
	data, err := os.ReadFile(saved)
	if err != nil {
		t.Fatal(err)
	}
	info, err := os.Stat(saved)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(child, data, info.Mode().Perm()); err != nil {
		t.Fatal(err)
	}
}

func TestJournalRecoveryPreservesLegacyIdentityJournals(t *testing.T) {
	for _, version := range []int{1, 2} {
		t.Run(map[int]string{1: "version-1", 2: "version-2"}[version], func(t *testing.T) {
			f := interruptedReplacement(t, replacementJournalSaved)
			encoded, err := json.Marshal(f.record)
			if err != nil {
				t.Fatal(err)
			}
			var legacy map[string]any
			if err := json.Unmarshal(encoded, &legacy); err != nil {
				t.Fatal(err)
			}
			legacy["version"] = version
			delete(legacy, "old_identities")
			delete(legacy, "new_identities")
			encoded, err = json.Marshal(legacy)
			if err != nil {
				t.Fatal(err)
			}
			if err := os.WriteFile(replacementJournalPath(f.path), encoded, fileMode); err != nil {
				t.Fatal(err)
			}
			before := migrationTree(t, filepath.Dir(f.path))
			if _, err := Repair(t.Context(), f.path, f.catalog, f.identity); err == nil {
				t.Fatal("recovery accepted a journal without persistent child identities")
			}
			if !reflect.DeepEqual(before, migrationTree(t, filepath.Dir(f.path))) {
				t.Fatal("legacy recovery changed workspace state")
			}
		})
	}
}
