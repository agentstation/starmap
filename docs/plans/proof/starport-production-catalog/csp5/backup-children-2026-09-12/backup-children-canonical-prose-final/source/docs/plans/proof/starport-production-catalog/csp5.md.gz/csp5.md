# CSP5 update controls and retained state

CSP5 remains in progress. The local implementation starts from Starmap `f9951ee6` on branch `codex/catalog-update-controls`.
Its worktree is `/Users/jack/src/github.com/agentstation/starmap-catalog-update-controls`.

Checkpoint `eeeba376` holds the local controls. Checkpoint `48a9a6e5` adds cascade lifecycle handling.
Checkpoint `52c84e28` corrects source-close timeout ownership. Checkpoint `b3cf9b68` rechecks queued publication guards.

Checkpoint `32951a7b` adds configured pins and consistent unpin startup. Checkpoint `39922ecf` adds durable pin acceptance and origin rollback issuance.
Checkpoint `de8b5abe` adds explicit durability outcomes and pending-pin confirmation.

Commit `ceef5480` corrects the retained record inventory. Commit `55c8bc19` adds baseline stage recovery.
Commit `9e875a35` adds migration initialization, partial ownership, scan limits, and the reopen correction.
Commit `536791a0` checks candidate cleanup and reuses validated repair candidates.

Commit `a05ca541` records private preparation writes and bounds assembly reads.
Commit `fcfda255` checks legacy rollback ownership and rejects replacement assembly files.
Commit `9d8b4b8b` bounds filesystem records and legacy preflight.
Commit `64f905db` preserves workspace record ownership and bounds marker reads.

Commit `e2cbbc6b` binds journal completion to accepted file state.
Commit `e7bfdf67` persists replacement child identities and preserves legacy journals.
No checkpoint has a PR or merge. Starport remains on its merged CSP4 source.

## Current controls

The [control proof](csp5/update-controls-2026-09-11/verification.json) preserves commands, source snapshots, failures, and partial results.
Each check records its own source hashes. The base commit alone does not identify the tested implementation.

The runtime now accepts `STARMAP_CATALOG_SOURCE_REFRESH_MODE=automatic|manual` and `STARMAP_CATALOG_NETWORK_MODE=configured|offline`.
Manual source mode suppresses startup reads, polling, and watcher subscriptions. Explicit cascade reads use a bounded `ReadOnce` path.
Close and caller cancellation stop manifest, payload, and source-chain requests. Concurrent subscriber starts and manual reads return conflicts.

Offline mode rejects network source reads, scheduled acquisition, explicit acquisition, and network preparation callbacks.
The manual acquisition adapter declares its source selection before preparation. Offline provider acquisition returns before credential resolution.
Concrete verified imports remain available. Declared local preparation validates the sources of its returned observations.

Internal authority rejects local acquisition before preparation. Independent permission reads remain enabled in manual mode and stop in offline mode.

The descriptor schema, generated reference, environment example, and Compose example include both settings.
Starport adoption still needs a module upgrade and consumer qualification under the plan.

## Evidence

The initial configuration tests fail on the base: three explicit offline operations send one, one, and two HTTP requests.
Manual source mode also subscribes to one watcher channel. The later callback tests expose three more offline HTTP requests.
The provider test resolves two credentials during offline manual acquisition and preview.

The cascade fixture first failed because its source policy was incomplete. Its next attempt omitted the required payload media type.
Those fixture failures remain separate from product evidence.
After fixture correction, the base refresh implementation opens one event stream during manual refresh.
The Go overlay changes only `runtime/refresh.go` to the base version. The proof retains the overlay and exact replacement bytes.

| Check | Result |
| --- | --- |
| Offline configuration, manual watcher, and finite cascade reads | 13 race test events pass, no failures or skips |
| Offline callbacks and lazy provider credentials | 8 race test events pass, no failures or skips |
| Verified local import and restart | 1 race test event passes, no failures or skips |
| Runtime observation, startup, and cancellation regressions | 12 race test events pass, no failures or skips |
| Corrected canonical settings package | 22 race test events pass, no failures or skips |
| ago | Exit 0, no findings, stale ignores, or incomplete errors |
| Technical writing | Corrected checks pass. The first failure and source snapshots remain in the proof. |

The broader package run completed with exit 1 because the settings package found three reference gaps.
The corrected settings package passes all 22 events. The original run passes 53 remote, 108 public configuration, and 104 acquisition events.
No passing package skips a test. Both original and corrected results retain their exact source snapshots. All checks in the earlier control proof are terminal.

## Cascade lifecycle checkpoint

The [lifecycle proof](csp5/cascade-lifecycle-2026-09-11/verification.json) binds the local checkpoint to its commands and source snapshots.
The original regression confirms that runtime shutdown left its constructed cascade stream active.
Separate fixture and compile failures remain in the proof. The corrected focused run passes 27 race events without failures or skips.

`WithOwnedSource` transfers the selected source to runtime shutdown. `WithSource` keeps ownership with the caller.
The Starmap composition transfers the cascade source it constructs. Failed startup uses the same cleanup as runtime shutdown.

A canceled initial read now stops without attaching the continuing stream to one request context.
Tests cover manifest, payload, stream-header, and catch-up cancellation, retry, repeated close, failed startup, and manual offline replacement.
Failed startup preserves source-close errors and releases the directory for a later runtime.

ago and vet pass. The prose check passes before a test-only option-name correction that changes no prose.
The full remote package passes 62 race events. The full settings package passes 24 race events. Neither package skips a test.

The earlier lifecycle run completed against `48a9a6e5` with 989 passes and two explicit skips.
Runtime passes 903 events, remote passes 62, and settings passes 24.
The two public-catalog tests skipped because their immutable fixture was absent. The latest proof retains their exact reasons.
Its command was `go test -race -count=1 -timeout 30m -json ./runtime ./remote ./internal/catalog/settings`.
These focused and package results overlap. They do not complete any mapped CSP5 subcase.

## Source-close timeout correction

The [shutdown proof](csp5/source-shutdown-2026-09-11/verification.json) binds checkpoint `52c84e28` to exact commands, snapshots, and results.
The regression stalls a real subscriber reconnect through an injected transport that delays cancellation.
The runtime previously returned a close timeout and released its directory while that source worker remained active.

`OwnedSource` now requires `Shutdown(context.Context)`. Runtime cleanup supplies a live context and retains directory ownership until the source joins.
The caller still receives a typed timeout after five seconds. `Source.Close` keeps its bounded standalone behavior.
Failed startup uses the same bounded cleanup. It preserves the original startup error and retains the directory through delayed shutdown.

The corrected focused run passes 36 race events without failures or skips.
It covers the stalled worker, context deadline, failed startup, lease release, late publication, and clock cleanup.
Complete remote and settings packages pass 63 and 24 race events without failures or skips. These results overlap the focused run.
ago and vet pass. The prose check precedes a nil-receiver guard and two test additions that change no source comments.

The earlier broad run in session `13494` covers checkpoint `48a9a6e5` only.
Its result cannot qualify the timeout correction. The latest pin proof records its completion and separate source identity.
Starport still owns its cascade separately. CSP8 must adopt coordinated source shutdown before consumer qualification.

## Configured generation pins

The [pin proof](csp5/generation-pins-2026-09-11/verification.json) binds checkpoints `b3cf9b68` and `32951a7b` to their exact checks.
The queued-mutation regression shows update, activation, reload, and rollback bypassing a guard changed while they waited.
The corrected guard runs again after entry to the mutation transaction. All 24 selected guard, reload, and rollback events pass.

`STARMAP_CATALOG_GENERATION_PIN` and `WithGenerationPin` select one retained artifact before startup can rebuild from retained inputs.
The host persists this value in its selected configuration authority. An explicit empty value clears the pin during runtime replacement.
The descriptor has deployment scope and the `runtime-replacement` change class. No separate pin configuration file exists.
The generated reference, descriptor schema, environment example, and Compose example include the setting.

Pins block source reads, scheduled acquisition, watcher subscriptions, imports, removals, and direct client mutations.
Independent permission observation continues. Permission enforcement uses the selected artifact's exact manifest and payload identity.
A permission withdrawal blocks new attempts while retaining pinned metadata. An incompatible authority cannot accept the pin.
Invalid identity, payload, schema, or missing artifacts fail startup and leave accepted storage unchanged.

The first pin configuration test shows ignored selection, network requests, candidate work, and direct rollback across two starts.
The first runtime test had two fixture errors: it removed a persistent alias and passed an empty import.
After fixture correction, unpin exposed a runtime/client mismatch. Startup now restores the same verified retained generation in both views.
The filesystem test reopens the store twice before clearing the pin and restoring the latest retained inputs.

Corrected focused checks pass 86 race events without failures or skips.
All 111 public configuration events pass. The initial internal settings run missed one sample value. Its corrected run passes all 24 events.

ago and vet pass. The prose check passes before that test-only sample correction, which changes no comments.

Full runtime/storage session `36556` starts from clean `32951a7b`.
Its command is `env STARMAP_PUBLIC_FIXTURE_REQUIRED=1 go test -race -count=1 -timeout 30m -json ./runtime ./pkg/catalogs/storage`.
The preparation command downloaded and verified the immutable public fixture before this run.
The original proof preserves a running snapshot. The latest acceptance proof records the terminal timeout after 969 passing events.
That command does not pass and does not cover the later acceptance changes.

Checkpoint `32951a7b` has no durable acceptance record and cannot roll an origin back to older content.
The acceptance work below replaces those limits. Complete pin recovery, generation retention, and full task acceptance remain open.

## Durable pin acceptance

The [acceptance proof](csp5/pin-receipts-2026-09-11/verification.json) binds checkpoint `39922ecf` to its commands, snapshots, and terminal results.
The original regressions show a missing acceptance file and refusal to restore an older origin generation.

The runtime stores its latest operation in `catalog-runtime/generation-pin.json` beneath the selected runtime state directory.
The private file has a 32 KiB limit. It records prepared, accepted, or released state and the source or authority binding.
Its receipt identifies the selected generation, accepted generation, predecessor, payload checksum, authority head, operation ID, and local times.
The selected configuration authority still owns the pin setting. This file owns recovery evidence only.

The runtime writes preparation before catalog publication and acceptance before readiness.
A rejected commit, lost reply, or failed acceptance write can resume the same operation after restart.
An accepted restart preserves the operation and file bytes. A changed source binding, malformed record, or unrelated catalog head prevents readiness.
A pending operation requires its original configured selection before configuration can change. Complete operator recovery guidance remains with CSP18.

Clearing an accepted pin records release after startup restores its retained inputs. A later pin creates a new operation.

An origin restores the selected payload under a new authority sequence. It preserves the current sequence on an identical retry.
The test covers restart and a fresh runtime directory against the same memory catalog store.
Clearing the origin pin restores retained inputs under the next sequence. This test does not qualify a production fleet.

`Runtime.PinAcceptance` reads the accepted receipt from memory and reports whether it has durable storage.
This file keeps the latest operation. Deployment audit history and the operator UI remain separate plan work.

The final Go 1.26.6 command passes 47 race events without failures or skips.
It covers ordinary and origin pins, failure recovery, authority binding, receipt schema, permission withdrawal, unpin, and directory ownership.
Separate isolation passes 52 events from the unfinished source, migration, status, and recovery tests.
The ago check reports no findings, stale ignores, or incomplete errors. Vet passes. The prose check passes 1,529 files with no diagnostics.

The earlier full runtime/storage command at `32951a7b` failed at its 30-minute limit.
It recorded 969 passing events and no individual test failure before the timeout. Storage completed, but runtime did not.
The timeout stack identifies Go 1.27.0. Final focused commands explicitly select Go 1.26.6 and `GOWORK=off`.
Passing isolated checks do not replace the required full command. All recorded checks are terminal.

## Filesystem durability and pin recovery

The [durability proof](csp5/filesystem-durability-2026-09-11/verification.json) binds checkpoint `de8b5abe` to its commands, snapshots, and results.
`TestFilesystemCommitAmbiguousFlushOutcome` originally found three defects during first publication and replacement.
The pointer became visible with an ordinary I/O error. An identical retry skipped the failed flush and reported success without confirmation.

Private-file publication now returns `*errors.PublicationError` after publication if synchronization fails.
The filesystem store identifies the current generation in that error. The wrapped cause remains available through `errors.Is`.
Failure before publication preserves the prior pointer and does not claim a published outcome.
An identical retry verifies retained content and synchronizes the generation directory, its parent, and the current directory.
The retry preserves pointer identity and rejects different content under the same generation ID.

The pending-pin regression exposed readiness after restart while the store still reported unconfirmed durability.
Startup now retries the recorded commit before acceptance. It preserves the selected generation and operation ID.
An accepted restart reasserts the same receipt to confirm its persistence. The operation ID and acceptance time remain unchanged.
Additional tests refuse clearing or replacing a pending pin and refuse an unrelated head after preparation or acceptance.

The complete storage, private-file, and error packages pass 236 race events: 92, 60, and 84 respectively.
The final pin check passes 37 events. Activation, rollback, and authority-publication consumers pass 31 events.
None of these checks fail or skip. The ago and vet checks pass.

The first prose check found two complex-tense comments. Its corrected run passes 1,533 files with no diagnostics.
Generated Go documentation now includes the pin, acceptance, and publication-error APIs.

All commands select Go 1.26.6 and `GOWORK=off`. Each result retains its tested source snapshot.
Later changes to tested storage logic are comments and generated documentation only.

The filesystem tests inject a synchronization failure after real link or rename publication.
They verify visible bytes, reopen, continued refusal, successful retry, and retained prior content.
Physical power-loss and native platform qualification remain separate. All recorded checks are terminal.

## Retained record inventory

The [inventory proof](csp5/file-inventory-2026-09-11/verification.json) binds commit `ceef5480` to its exact commands and source snapshots.
The original regression found two runtime files absent from the manifest and inspection output: `removals.json` and `generation-pin.json`.
Both the canonical runtime directory and an explicit override reproduced the omission.

The runtime evidence inventory now names both files and applies its existing owner-only policy.
The engineering path table also identifies the 32 KiB pin receipt and its recovery role.
Configuration authority still owns the pin setting. The receipt does not replace configuration.

The regression creates the files through real application startup, operator removal, catalog publication, and pinned restart.
Inspection reports their paths and private-file policy without changing their bytes or exposing the receipt contents.
The inspection application stays passive. Unrecognized runtime files remain outside the managed inventory.

Corrected checks pass 8 application and 86 product-path race events without failures or skips.
The ago check reports no findings, stale ignores, or incomplete errors. The prose check passes 1,534 files with no diagnostics.
All commands select Go 1.26.6 and `GOWORK=off`. All recorded checks are terminal.

Both regression runs record optional YAML workspace repair timeouts after durable catalog activation.
The inventory correction does not change or qualify workspace projection. Full CSP5 verification remains required.
Baseline export still has process-local cleanup only. Recovery must verify persistent ownership before it removes stages from exited writers.

## Baseline stage recovery

The [recovery proof](csp5/baseline-recovery-2026-09-11/verification.json) binds commit `55c8bc19` to sixteen command records and their source snapshots.
The original process-interruption regression fails before journal recovery. A second regression fails when recovery deletes a stage after an actor replaces the retained writer lock.
Both corrected regressions pass.

Baseline export now retains `.starmap-baseline/.owner.lock` and private versioned operation journals beside its published generations.
Each journal binds the lock identity, stage identity, expected file identities, metadata, and content digests.
One writer lock excludes active exporters during recovery. Recovery preserves the stage if another actor replaces the lock.

Recovery resumes a verified partial cleanup after process interruption. It never deletes a published baseline.
Unknown journals, changed entries, unrecorded stages, and oversized content remain in place and appear in `ExportResult.Recovery.PreservedPaths`.
The scan limit is 4,096 combined baseline and metadata entries. The content limit is 64 MiB of declared snapshot bytes per pass.

Repeated stability checks can reread content. The snapshot limit does not impose a catalog size limit or a strict physical I/O budget.

Final local race checks pass 46 baseline events, 30 path events, and 7 later policy events without failures or skips.
These runs overlap and do not establish 83 distinct cases. Consumer dependency checks and the ago check pass.
The corrected prose check passes 1,541 files with no diagnostics. The original paragraph-length failure remains in the proof.

Linux AMD64 and Windows AMD64 compilation pass. Native runtime, ACL, filesystem durability, and power-loss qualification remain separate.

The baseline and path checks precede one separately tested POSIX policy case and a documentation paragraph split.
Final ago, prose, and Linux compilation checks cover all sixteen committed files. All recorded checks are terminal.
Other staging roles, published generation retention, history compaction, and full CSP5 qualification remain open.

## Migration stage recovery

The [migration proof](csp5/migration-recovery-2026-09-12/verification.json) binds commit `9e875a35` to twenty-eight command records and their source snapshots.
The original partial-copy regression deletes changed bytes, replacement files, and unrecorded files during restart.
The original initializer deletes unknown operator content on error. Four process-exit cases leave earlier initialization stages behind.
The source scan also accepts 40,001 empty directories despite its separate file limit.

Initialization now retains a private `stage-initialization.json` record in the operation journal.
It binds the manifest, parent and stage identities, and journal lock. Restart resumes that same stage.
Unknown entries, changed intent, replaced directories, and replaced locks cause refusal without recursive deletion.
Publication preserves any later use of the old staging name.

Each `.partial` file has an immutable sibling `.partial.json` ownership record, limited to 16 KiB.
The record binds native stage, work-directory, lock, and file identities, plus mode and the source entry.
Recovery checks the mutable partial bytes against the exact source prefix before removal.
A crash after partial removal retains enough evidence to finish record cleanup. Missing or unsupported records cause preservation and refusal.

Source inventory permits 40,000 entries, including empty directories and metadata.
The stage scan derives its entry limit from the allowed manifest layout. Both scanners use batches of at most 128 entries.
Aggregate path names cannot exceed 4 MiB. Initialization permits only two metadata files and an empty work directory.

Final migration checks pass 150 race events without failures or skips. Baseline and publication checks pass 32 race events.
The native identity code moves into `internal/filepublish` with unchanged identity encodings. Workspace encodings remain separate.
Consumer dependency checks and the final ago check pass. The final source prose check passes 1,544 files with zero diagnostics.

Two earlier prose runs report paragraph errors. The proof preserves both failures and their source snapshots.

Final Linux AMD64 and Windows AMD64 compilation includes the directory flush and reopen correction.
Only a test assertion correction follows those builds. The final migration and ago commands cover that correction.
Native platform behavior and physical power-loss recovery remain unqualified for this change. All recorded checks are terminal.

The moved-stage regression also exposed deferred cleanup through a nil handle after a failed directory reopen.
The initializer now keeps the original and reopened handles separate. A moved stage causes a filesystem error and remains preserved.
The first broad rerun returned that expected error but failed an assertion that did not inspect joined errors.
The corrected assertion uses `errors.Is`. Its focused check and the full migration group pass.

Unrecorded stages and interrupted atomic owner-record scratch remain preserved for explicit recovery.
Workspace preparation and exchange cleanup, retained evidence, discovery staging, generation retention, history compaction, and full CSP5 qualification remain open.
At that checkpoint, private workspace preparation and verification still use recursive cleanup. The preparation section below records the later correction.

## Workspace candidate cleanup and repair reuse

The [workspace proof](csp5/workspace-cleanup-2026-09-12/verification.json) binds commit `536791a0` to its command records and source snapshots.
Eight original cases delete operator content before promotion or after native exchange.
They cover unknown files, changed files, same-content replacement files, and replacement roots.
Both original repair cases also build two candidates for one repair.

Candidate cleanup now checks bounded inventories, native identities, content digests, and access metadata before deletion.
It preserves conflicts and returns the cleanup error with the original operation error.
Cancellation starts a separate 30-second cleanup limit. Native exchange permits cleanup of the recorded old tree at the candidate path.
The visible publication receipt survives cleanup failure.

Repair now publishes its validated candidate without a second render and validation pass.
All 149 workspace race events pass without failures or skips.
Final ago, prose, and Linux/Windows compilation checks pass. Compilation does not qualify native runtime behavior.

The canonical-runtime application test passes before and after candidate reuse.
Its elapsed time falls from 117.50 to 74.64 seconds. Sampled cumulative allocation space falls from 18,970.27 to 11,169.65 MB as reported by pprof.
Each version has one local run with race instrumentation and profiling. The earlier optional-workspace timeout does not recur in either run.

Allocation totals are not peak resident memory. These observations do not qualify production startup, inference latency, or the released product pair.

The proof preserves one intermediate compile failure and both prose failures.
The first prose failure identifies an eight-sentence paragraph. The second scans a generated native sample with a text suffix.
That unchanged machine output now uses a log suffix. The corrected document restores migration paragraph ownership before the new workspace section.

The identity map remains in memory and does not change the existing replacement-journal encoding.
At `536791a0`, private preparation and verification cleanup still use recursive deletion. Assembly still has an unbounded directory read.
Persistent stage recovery, retained evidence, discovery staging, generation retention, history compaction, and full CSP5 qualification remain open.

## Workspace preparation ownership

The [preparation proof](csp5/workspace-preparation-2026-09-12/verification.json) binds commit `a05ca541` to fourteen command records and their exact sources.
Four original cases delete operator files from preparation directories. They cover unknown children, changed render files, replacement files, and replacement enclosures.
A separate boundary case creates an unrecorded file before rejecting the path-name limit. Both failures now have passing regression tests.
The proof also retains one intermediate build failure from an unused import.

`Builder.WriteYAML` emits the existing catalog records and logo sidecars through a callback without filesystem access.
Workspace preparation owns file creation and records native identity, access metadata, and actual written bytes.
Partial writes remain identifiable after a write error or cancellation. Unknown or changed entries remain preserved during cleanup.
Verification uses the same writer and checked cleanup. Operator files copy after generated records, without deleting copied model directories.

The writer checks resource limits before creating another entry. Assembly uses bounded directory reads and indexes expected child counts once.
Temporary render and verification files do not require a flush per file. The publishable candidate still flushes its files and directories.
`SaveTo` retains its existing authoring behavior.

All 160 workspace and 1,264 catalog race events pass without failures or skips.
The canonical-runtime application integration test passes, with two test events including its parent.
Final ago, prose, consumer-dependency, and Linux/Windows compilation checks pass.
The serializer test also reloads emitted bytes and verifies that the callback serializer creates no filesystem entries.
Compilation does not qualify native Windows or Linux runtime behavior. The application result does not establish a production latency claim.

Ownership records remain in process memory. Persistent preparation and replacement recovery, including active-writer exclusion, remain open.
Source inspection also found a separate gap in `rollbackLegacyMove`: its semantic checksum excludes operator notes before recursive deletion.
At `a05ca541`, this finding had no failure-test result. The legacy rollback section below records the correction.

## Legacy rollback and assembly ownership

The [rollback proof](csp5/legacy-rollback-2026-09-12/verification.json) binds commit `fcfda255` to its exact sources and command results.
Seven original rollback scenarios fail, producing nine test failure events including their parents.
They cover unknown projected files, changed YAML comments, replacement files, replacement roots, operator sidecars, and a replaced relocated store.
A separate assembly test also fails because assembly accepts a replacement file with identical bytes.

Rollback now receives the candidate inventory captured before publication. It verifies native file identities, content, access, and remaining entries before removal.
It preserves unknown or changed content and reports a conflict with the original failure.
The store has a native directory identity captured before relocation. Both relocation and restoration use open parent directories and refuse an existing destination.

Rollback leaves projection-marker paths and the stable writer-lock file in place.
Two previous tests expected rollback to delete those unowned entries.
The tests now verify that rollback preserves those entries and restores the exact store.
Additional tests cover cancellation, lock identity and exclusion, and occupied move destinations.
Assembly compares its finished tree with identities and bytes recorded during creation. Identical bytes do not establish ownership of a replacement file.

All 175 workspace and two CLI command race events pass without failures or skips.
The CLI cases use the existing adapter fixture. Workspace tests exercise real filesystem stores.
Final ago, prose, and Linux/Windows compilation checks pass. The proof retains an initial eight-sentence paragraph failure and its corrected document.
Native runtime and physical power-loss qualification remain open.

Store identities and candidate inventories remain in memory. They do not establish recovery after process exit.
At `fcfda255`, legacy preflight still used unbounded directory and manifest reads. The next section records their correction.

At `9d8b4b8b`, projection-marker temporary cleanup still lacked a recorded ownership check. The workspace record section below records its correction.
CSP5 owns those paths, persistent recovery, active-writer exclusion, retention, compaction, and full qualification.

## Bounded legacy preflight and filesystem records

The [preflight proof](csp5/legacy-preflight-2026-09-12/verification.json) binds commit `9d8b4b8b` to its exact sources and command results.
The original filesystem tests fail in six reader and writer scenarios, producing eight failure events including parents.
Oversized records previously entered memory or became stored generations. The corrected reader refuses their size before reading the file.

Filesystem payloads have a 32 MiB limit. Manifests have a 64 MiB limit, and current pointers and authority records have a 16 KiB limit.
The pointer limit includes its newline. Commit rejects oversized payloads, manifests, and pointers before creating generation state or changing current.
These limits do not configure other adapters.

The first migration test used the wrong expected error field. Its corrected test still shows that an oversized retained manifest reaches JSON parsing.
The passing correction rejects its size before parsing and preserves current, the retained record, and the absent destination parent.
The proof retains both failed attempts and their original source.

Fixed-layout reads inspect at most four entries. Retained generation scans use 128-entry batches and check cancellation before each batch and generation.
They validate every retained generation and preserve the complete count. Tests scan 259 entries and stop at cancellation or a failed generation.
A full migration preserves all 129 generations across a batch boundary and reads every unchanged generation afterward.

All 187 workspace, 101 storage, 60 private-file, and two CLI command race events pass without skips.
The CLI cases use their existing adapter fixture. Workspace and storage tests use real filesystem state.
Final ago, prose, and Linux/Windows compilation checks pass. The initial prose failure and its correction remain in the proof.
Native runtime and physical power-loss qualification remain open.

These changes do not provide persistent workspace or legacy relocation recovery.
The next section records marker cleanup. Active-writer exclusion for persistent stages, retention, compaction, and complete CSP5 qualification remain open.

## Workspace marker and journal ownership

The [record proof](csp5/workspace-records-2026-09-12/verification.json) binds commit `64f905db` to the original failures and final checks.
Twelve cleanup cases fail before the fix, producing thirteen failed events including their parent.
They cover ordinary markers, replacement journals, and journaled markers. The injected hooks expose the existing write and publication boundaries.

The original writers delete changed files, identical-byte replacements, recreated paths, and replacements made after partial writes.
A separate Go overlay restores only the original marker reader. That reader accepts a valid marker larger than 4 MiB.
The proof preserves both overlay inputs and the exact command sources.

The shared record writer captures native identity, access, and the actual written bytes. It keeps the file open through cleanup.
Before publication, it rechecks the candidate, destination snapshot, and cancellation. Journals cannot replace an existing destination.
Cleanup preserves changed files and reports its errors with the original failure. Cancellation retains a separate 30-second cleanup context.

All 213 workspace and two CLI command race events pass without skips. Tests also cover access changes and unchanged partial cleanup.
Exact-size publication, oversized refusal, short writes, cancellation, destination conflicts, and journal collisions pass.
Final ago, prose, and Linux/Windows compilation checks pass. Native runtime and physical power-loss qualification remain open.

The records remain in memory. Persistent workspace and legacy relocation recovery remain incomplete.
At `64f905db`, `finishReplacementRecord` still compared parsed content before removing the completion file.
The next section records its identity binding and regression results.

The [current PR queue](pr-audit-2026-09-08/current-queue/queue-status-2026-09-12.json) has no open PRs.
CSP5 remains unpublished until its full contract and required review pass. Both implementation worktrees are clean.

## Accepted journal completion identity

The [journal identity proof](csp5/journal-identity-2026-09-12/verification.json) binds commit `e2cbbc6b` to six original failures and their corrections.
The cases cover initial replacement and recovery under identical file replacement, equivalent JSON edits, and changed access metadata.
Seven failed events include the parent test. The original cleanup deleted each changed journal.

Publication now returns the original staged file state. Recovery captures journal bytes, native identity, and access metadata from one bounded read.
Completion compares that accepted state before removal. Cancellation retains the journal, and a later recovery attempt validates it again.
Tests also require a receipt and preserve the original publication identity after a publication error.

All 224 workspace and two migration CLI race test events pass without failures or skips.
The focused boundary run passes 27 events, including process exits at six replacement phases.
Final ago, prose, and Linux/Windows compilation checks pass. Native execution remains unverified.

At `e2cbbc6b`, receipts remained in memory. That checkpoint used version 2 journals.

A separate preserved Go overlay proves another defect: recovery deletes an identical replacement backup child.
Version 2 persists root identity and child content and access metadata. It omits native child identities.
The next section records persisted child ownership and legacy-journal compatibility. The original failing probe remains preserved.

## Persisted replacement child identities

The [child identity proof](csp5/backup-children-2026-09-12/verification.json) binds commit `e7bfdf67` to original failures and final checks.
In the red run, recovery deletes identical replacement files and directories. It also accepts a version 2 journal without child identities.
Five failed events include two parent tests. The existing version 1 refusal passes in that same run.

Version 3 persists native identities for every old and new inventory entry. Both maps must cover exactly their inventory paths and match the root identity.
Each identity remains bounded to 128 bytes. Both maps remain within the existing 4 MiB journal limit.
Recovery checks identities, content, and access before moving live or candidate trees.

Backup cleanup checks persisted child identities before cleanup and before each removal. It also verifies the backup root's path binding.
Tests preserve a file replaced during cleanup and reject incomplete, extra, empty, oversized, and root-mismatched identity records.
Version 1 and 2 journals remain unchanged with a `workspace_replacement.version` error. Their workspace, candidate, and backup remain preserved for explicit recovery.

All 243 workspace and two migration CLI race test events pass without skips. The final boundary run passes 19 events.
The earlier 20-event run also passes process-exit recovery at all six replacement phases.
Final ago, prose, and Linux/Windows compilation checks pass. Native runtime qualification remains open.

Journal acceptance receipts remain in memory. Child ownership now persists in version 3 journals.
Preparation and legacy relocation recovery remain incomplete, with evidence and discovery staging, retention, compaction, and full task qualification.

## Remaining work

The [task contract](../../starport-production-catalog-plan.html#task-CSP5) owns all acceptance requirements.
The [registry baseline](csp5/baseline-2026-09-11/verification.json) reports twelve unverified subcases because it contains no checks for them.
The focused results above do not complete those full subcases.

Add persistent preparation and candidate recovery with active-writer exclusion. Complete legacy relocation, retained-evidence, and discovery recovery, then generation retention.
Preserve rollback pins and every other required generation.
Use Go 1.26.6 explicitly for the remaining checks.
Full current-source runtime/storage verification must pass before task completion.

Keep pin and rollback behavior subject to permission withdrawal during remaining changes.
Complete owned-stage recovery and bounded history compaction.
Preserve original receipts, omitted offerings, active writers, unknown files, and required generations.
Full task checks, repository verification, review, native CI, and merges remain open.
