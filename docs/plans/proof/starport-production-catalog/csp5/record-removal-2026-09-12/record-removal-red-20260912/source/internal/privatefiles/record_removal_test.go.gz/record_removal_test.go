package privatefiles

import (
	"context"
	"os"
	"path/filepath"
	"testing"
)

type conditionalRecordRemover interface {
	CompareAndRemoveFileContext(context.Context, string, []byte) (bool, error)
}

func TestPrivateRecordRemovalPreservesChangedContent(t *testing.T) {
	directory, err := NewDirectory(filepath.Join(t.TempDir(), "records"))
	if err != nil {
		t.Fatal(err)
	}
	remover, ok := any(directory).(conditionalRecordRemover)
	if !ok {
		t.Fatal("private records lack checked removal under publication ownership")
	}
	if err := directory.PublishFileContext(t.Context(), "record.json", []byte("newer"), ".record-"); err != nil {
		t.Fatal(err)
	}
	removed, err := remover.CompareAndRemoveFileContext(t.Context(), "record.json", []byte("older"))
	if err == nil || removed {
		t.Fatalf("changed record removed: %v, %v", removed, err)
	}
	data, err := directory.ReadFile("record.json", 32)
	if err != nil || string(data) != "newer" {
		t.Fatalf("changed record lost: %q, %v", data, err)
	}
	removed, err = remover.CompareAndRemoveFileContext(t.Context(), "record.json", []byte("newer"))
	if err != nil || !removed {
		t.Fatalf("matching removal: %v, %v", removed, err)
	}
	if _, err := directory.ReadFile("record.json", 32); !os.IsNotExist(err) {
		t.Fatalf("removed record remains: %v", err)
	}
	removed, err = remover.CompareAndRemoveFileContext(t.Context(), "record.json", []byte("newer"))
	if err != nil || removed {
		t.Fatalf("idempotent retry: %v, %v", removed, err)
	}
}
