package runtime

import (
	"testing"
	"time"

	"github.com/agentstation/starmap"
	"github.com/agentstation/starmap/pkg/sources"
)

func TestManualCheckpointRetainsResetHistoryAtBatchLimit(t *testing.T) {
	at := time.Date(2026, 9, 12, 0, 0, 0, 0, time.UTC)
	original := providerResetObservation(t, sources.ModelsDevHTTPID, manualProviderObservation(t, 200, at).Catalog, at, nil)
	observations, err := prepareManualObservations(t.Context(), []sources.Observation{original})
	if err != nil {
		t.Fatal(err)
	}
	resets := []ObservationReset{{SourceID: sources.ModelsDevHTTPID}}
	history := &manualBatch{observations: observations}
	for range maxManualHistoryBatches - 1 {
		history = &manualBatch{parent: history, observations: observations, resets: resets}
	}
	incoming := providerResetObservation(t, sources.ModelsDevHTTPID, manualProviderObservation(t, 300, at).Catalog, at.Add(time.Minute), nil)
	input, err := prepareManualObservations(t.Context(), []sources.Observation{incoming})
	if err != nil {
		t.Fatal(err)
	}
	baseline := starmap.CatalogState{GenerationID: "baseline", Catalog: manualProviderObservation(t, 100, at).Catalog, GeneratedAt: at.Add(-time.Minute)}
	layers := layerSet{manual: history, embedded: baseline}
	selected, err := layers.prepareManualInputs(t.Context(), input, nil, resets)
	if err != nil {
		t.Fatalf("reset history blocked the next acquisition: %v", err)
	}
	layers.manual = &manualBatch{parent: layers.manual, observations: selected, resets: resets}
	expected := layerSet{manual: &manualBatch{parent: history, observations: input, resets: resets}, embedded: baseline}
	before, err := expected.build(t.Context(), baseline)
	if err != nil {
		t.Fatal(err)
	}
	after, err := layers.build(t.Context(), baseline)
	if err != nil || before.GenerationID != after.GenerationID || before.PayloadChecksum != after.PayloadChecksum {
		t.Fatalf("checkpoint changed catalog facts or reset identity: %v", err)
	}
	store, err := newLayerStore(privateRuntimeDirectory(t))
	if err != nil {
		t.Fatal(err)
	}
	reference, err := store.stageManualBatch(t.Context(), layers.manual)
	if err != nil {
		t.Fatal(err)
	}
	if err := store.saveManualHead(t.Context(), reference); err != nil {
		t.Fatal(err)
	}
	restored, err := store.loadManualHistory(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	restarted := layerSet{manual: restored, embedded: baseline}
	actual, err := restarted.build(t.Context(), baseline)
	if err != nil || actual.GenerationID != before.GenerationID || actual.PayloadChecksum != before.PayloadChecksum {
		t.Fatalf("checkpoint restart changed accepted reset history: %v", err)
	}
	batches := manualBatches(restored)
	if len(batches) != maxManualHistoryBatches+1 {
		t.Fatalf("checkpoint lost ordered batches: %d", len(batches))
	}
	for index, batch := range batches {
		want := original.ID
		if index == len(batches)-1 {
			want = incoming.ID
		}
		if len(batch.observations) != 1 || batch.observations[0].Receipt.Link.ObservationID != want || (index > 0 && len(batch.resets) != 1) {
			t.Fatalf("checkpoint changed original evidence at batch %d", index)
		}
	}
	if len(manualBatches(history)) != maxManualHistoryBatches {
		t.Fatal("checkpoint changed the accepted history in place")
	}
}
