package workspace

import (
	"context"
	stderrors "errors"
	"io/fs"
	"os"
	"path/filepath"

	"github.com/agentstation/starmap/internal/filepublish"
	"github.com/agentstation/starmap/pkg/errors"
)

type legacyStoreMove struct {
	originalParent *os.Root
	stateParent    *os.Root
	originalName   string
	stateName      string
	store          os.FileInfo
}

func prepareLegacyStoreMove(legacy, state string, store os.FileInfo) (*legacyStoreMove, error) {
	originalParent, err := os.OpenRoot(filepath.Dir(legacy))
	if err != nil {
		return nil, err
	}
	stateParent, err := os.OpenRoot(filepath.Dir(state))
	if err != nil {
		_ = originalParent.Close()
		return nil, err
	}
	return &legacyStoreMove{
		originalParent: originalParent, stateParent: stateParent,
		originalName: filepath.Base(legacy), stateName: filepath.Base(state), store: store,
	}, nil
}

func (m *legacyStoreMove) close() {
	_ = m.originalParent.Close()
	_ = m.stateParent.Close()
}

func (m *legacyStoreMove) checkStore(parent *os.Root, name string) error {
	info, err := parent.Lstat(name)
	if err != nil {
		return err
	}
	if !info.IsDir() || info.Mode()&os.ModeSymlink != 0 || !os.SameFile(m.store, info) {
		return &errors.ConflictError{
			Resource: "legacy catalog store", Actual: filepath.Join(parent.Name(), name),
			Message: "store identity changed during migration",
		}
	}
	return nil
}

func (m *legacyStoreMove) relocate() error {
	if err := m.checkStore(m.originalParent, m.originalName); err != nil {
		return err
	}
	return filepublish.DirectoryBetweenRootsNoReplace(m.originalParent, m.originalName, m.stateParent, m.stateName)
}

func (m *legacyStoreMove) rollback(ctx context.Context, projected treeSnapshot) error {
	cleanup, cancel := context.WithTimeout(context.WithoutCancel(ctx), workspaceCleanupTimeout)
	defer cancel()
	if err := m.checkStore(m.stateParent, m.stateName); err != nil {
		return err
	}
	if projected.ID == "" {
		_, err := m.originalParent.Lstat(m.originalName)
		if err == nil {
			return replacementConflict(m.originalName, "vacated catalog path was recreated during migration")
		}
		if !stderrors.Is(err, fs.ErrNotExist) {
			return err
		}
	} else if err := cleanupWorkspaceTreeAt(cleanup, m.originalParent, m.originalName, projected); err != nil {
		return err
	}
	if err := cleanup.Err(); err != nil {
		return err
	}
	if err := m.restore(); err != nil {
		return err
	}
	return m.sync()
}

func (m *legacyStoreMove) restore() error {
	if err := m.checkStore(m.stateParent, m.stateName); err != nil {
		return err
	}
	return filepublish.DirectoryBetweenRootsNoReplace(m.stateParent, m.stateName, m.originalParent, m.originalName)
}

func (m *legacyStoreMove) sync() error {
	if err := filepublish.SyncDirectory(m.originalParent); err != nil {
		return err
	}
	return filepublish.SyncDirectory(m.stateParent)
}
