# AGENTS.md

> LLM coding assistant instructions for the Starmap project

This file provides Codex with project-specific guidance for working in this repository. For technical architecture details, see **[ARCHITECTURE.md](docs/ARCHITECTURE.md)**.

---

## Go Development Standards

**Starmap supports Go 1.25 and uses Go 1.26.6 for development and releases.** Write idiomatic, thread-safe, production-ready code:

- **Simplicity over cleverness** - Follow Effective Go, prioritize readability
- **Thread safety first** - Deep copies for shared data, proper RWMutex usage
- **Typed errors only** - Use `pkg/errors` types, wrap with context, no panic/recover
- **Measure then optimize** - Profile before optimizing, understand allocations
- **Table-driven tests** - Use testdata patterns, always run with `-race`
- **Context propagation** - Cancel-aware operations, timeout handling
- **Defer cleanup** - Always close resources properly
- **Godoc everything exported** - Clear documentation on public APIs

### Modern Go and goago

- Use Go 1.25 language and library features when they improve directness.
- Use `sync.WaitGroup.Go` for goroutines whose lifetimes match the group.
- Run `go tool goago -list -format json` before you interpret the active restrictions.
- Run `go tool goago -stale-ignores -format json ./...` after each Go change.
- The built-in goago defaults apply because this repository has no policy file.
- Do not change the policy or add a suppression only to pass the linter.

### Technical writing

- Use `GLOSSARY.md` for developer-facing prose.
- Use the `technical-writing` skill before you edit durable prose.
- Run `make technical-writing-check` after each durable prose change.
- Strict mode applies to maintained documentation and source comments.
- The project policy excludes historical reviews and structured catalog data.

---

## Project Overview

Starmap is a unified AI model catalog system that combines data from provider APIs, models.dev, and embedded sources into a single authoritative catalog.

**For technical deep dive:** See [ARCHITECTURE.md](docs/ARCHITECTURE.md)

## Quick Start

```bash
make all                                # Clean, format, lint, test, build
starmap update                          # Update local catalog
starmap update openai                   # Update specific provider
make testdata PROVIDER=openai           # Refresh one governed provider fixture
```

## Tech Stack

- **Language floor**: Go 1.25.0 (tested with Go 1.25.12)
- **Development/release toolchain**: Go 1.26.6
- **Build System**: Make (see Makefile)
- **Key Dependencies**: zerolog (logging), cobra (CLI), goccy/go-yaml (YAML)
- **Testing**: Go testing, testdata pattern with `-update` flag
- **Providers**: OpenAI, Anthropic, Google AI/Vertex, Groq, DeepSeek, Cerebras, Hetzner, Alibaba Cloud, Fireworks AI, DeepInfra

## ⚠️ Critical Rules (YOU MUST FOLLOW)

### Thread Safety

**See docs/ARCHITECTURE.md § Thread Safety for full details**

**Publish concrete immutable catalogs. Copy values at collection boundaries:**

```go
// ❌ WRONG - publishes a mutable builder
func Catalog() *catalogs.Builder { return s.builder }

// ✅ CORRECT - atomically returns the concrete immutable catalog
func Catalog() *catalogs.Catalog {
    s.mu.RLock()
    defer s.mu.RUnlock()
    return s.catalog
}
```

**Key patterns:**
- `*catalogs.Builder` is the advanced mutation type. Publish with `Builder.Build()`.
- Published catalogs are immutable and swapped as complete generations
- Collection reads return caller-owned deep copies
- Double-checked locking for singletons
- RWMutex for concurrent access

### Error Handling

**ALWAYS use typed errors:**

```go
// Use typed errors from pkg/errors
&errors.NotFoundError{Resource: "model", ID: modelID}
&errors.SyncError{Provider: "openai", Err: err}
&errors.APIError{Provider: "openai", Endpoint: "/models", StatusCode: 500}
```

### Constants

**NEVER hardcode values:**

```go
// ✅ CORRECT
constants.DirPermissions
constants.DefaultTimeout

// ❌ WRONG
0755
30*time.Second
```

### Provider Clients

**Check OpenAI-compatible first:**

Most providers use unified OpenAI client (`internal/providers/openai/client.go`). Only create custom client if API is incompatible.

**Steps:**
1. Check if provider uses OpenAI-compatible API
2. If yes: configure in `internal/embedded/catalog/providers.yaml`
3. If no: create custom client in `internal/providers/<provider>/`
4. Register in `internal/providers/clients/provider.go`

### Provider Fixture Refresh

After making changes to provider code:

```bash
make testdata PROVIDER=<provider-id>
```

This opt-in command uses the selected provider's embedded YAML record and
catalog-acquisition credentials. Ordinary tests replay checked-in fixtures and
never call provider APIs.

## Architecture Quick Reference

For detailed architecture, see [ARCHITECTURE.md](docs/ARCHITECTURE.md). Here's a quick reference:

### System Layers

```
User Interfaces (CLI, Go Package)
    ↓
Application Composition (internal/cli/app concrete implementation)
    ↓
Root Package (starmap.Client - public API)
    ↓
Public Contracts (catalogs, storage, sources)
    ↑
Explicit Acquisition (acquisition.Syncer)
    ↓
Internal Implementations (reconciliation, CLI, embedded, providers, modelsdev)
```

**Key files:**
- `client.go` / `update.go` - Small immutable root API and publication
- `acquisition/syncer.go` - Explicit opt-in provider/source synchronization
- `internal/catalog/pipeline/` - Prepare-only source pipeline
- `internal/cli/commands/*/application.go` - Consumer-local command roles
- `internal/server/application.go` - HTTP server application role
- `internal/cli/app/app.go` - App implementation

### Sync Pipeline (13 Steps)

See docs/ARCHITECTURE.md § Sync Pipeline for details:

1. Check/set context
2. Parse options
3. Setup timeout
4. Load embedded catalog
5. Validate options
6. Filter sources
7. **Resolve dependencies** (check/install missing deps, filter optional sources)
8. Setup cleanup
9. Fetch from sources (concurrent)
10. Get existing catalog
11. Reconcile catalogs
12. Log changes
13. Save if not dry-run

### Reconciliation System

See docs/ARCHITECTURE.md § Reconciliation System for details:

- **Authority Strategy**: Field-level priorities (default)
- **Source Order Strategy**: Fixed precedence
- Sources: Provider APIs, models.dev (Git/HTTP), Local, Embedded
- Field-level authority determines which source wins

## Common Development Tasks

### Add New Provider

See docs/ARCHITECTURE.md § Data Sources for authority hierarchy.

1. Add to `internal/embedded/catalog/providers.yaml`
2. Add or reuse the canonical authored model under
   `internal/embedded/catalog/authors/{author}/models/{slug}.yaml`
3. Add the serving record under
   `internal/embedded/catalog/providers/{provider}/models` with the exact
   provider ID and an explicit `model: author/slug` link
4. Check if OpenAI-compatible (most are: OpenAI, Groq, DeepSeek, Cerebras, Alibaba Cloud, Fireworks AI, DeepInfra)
5. If compatible: Configure in YAML. If not: Create custom client
6. Register in `internal/providers/clients/provider.go`
7. Add or refresh a governed fixture only when it proves a current wire or
   mapping contract: `make testdata PROVIDER=<provider-id>`

### Modify Sync Logic

See docs/ARCHITECTURE.md § Sync Pipeline for 12-step process.

The sync pipeline is in `internal/catalog/pipeline/` behind the explicit
`acquisition.Syncer` composition:
- Filter → Fetch (concurrent) → Reconcile → Save
- Each stage has clear purpose and error handling

### Update Reconciliation

See docs/ARCHITECTURE.md § Reconciliation System for strategy details.

- Modify authorities: `pkg/catalogs/authority/authority.go`
- Strategies: `internal/catalog/reconciler/strategy.go`
- Field patterns support wildcards: "Pricing.*"

### Working with Commands

Commands define narrow dependency roles in the package that consumes them:

```go
type application interface {
    Catalog() (*catalogs.Catalog, error)
    Logger() *zerolog.Logger
}

func NewCommand(app application) *cobra.Command {
    return &cobra.Command{
        RunE: func(cmd *cobra.Command, args []string) error {
            catalog, err := app.Catalog()  // Atomic immutable generation
            // ... use catalog
        },
    }
}
```

### Dependency Management

Sources can declare external dependencies via `Dependencies()` interface method. The dependency resolver runs in step 7 of the sync pipeline before fetch.

**Implementation:**
- Add `Dependencies() []Dependency` and `IsOptional() bool` methods to Source
- Core resolution is noninteractive by default. The CLI supplies the only prompt adapter.
- Explicit noninteractive policies support auto-install or optional-source skipping
- Optional sources are gracefully skipped if deps missing
- Use `//nolint:gosec` for subprocess calls (commands from trusted source code)

See `internal/deps/checker.go` and `lifecycle.go:resolveDependencies()` for implementation.

## Code Patterns

### Functional Options

Used throughout for configuration:

```go
// Creating instances
sm, _ := starmap.New(
    starmap.WithCatalogPath("./catalog"),
)

syncer, _ := acquisition.New(sm)
result, _ := syncer.Sync(ctx,
    sync.WithProvider("openai"),
    sync.WithDryRun(true),
)
```

See examples: `starmap.New()`, `catalogs.New(catalogs.WithFS(catalogFS))`, `catalogs.NewEmpty()`, `sync.WithProvider()`

### Dependency Injection

See docs/ARCHITECTURE.md § Application Composition for interface pattern.

```go
// Interface defined in the command package where it is consumed.
type application interface {
    Catalog() (*catalogs.Catalog, error)
    Logger() *zerolog.Logger
}

// Implementation in internal/cli/app/
type App struct { /* ... */ }
func (a *App) Catalog() (*catalogs.Catalog, error) { /* ... */ }
```

### Concurrent Fetching

See docs/ARCHITECTURE.md § Data Sources for concurrent pattern.

Provider APIs run in parallel with goroutines and channels:
```go
var wg sync.WaitGroup
results := make(chan Result, len(providers))
for _, provider := range providers {
    wg.Go(func() {
        models, err := provider.Client.ListModels(ctx)
        results <- Result{Provider: provider, Models: models, Error: err}
    })
}
wg.Wait()
close(results)
```

### Merge Strategies

- `MergeReplaceAll`: Provider APIs (fresh data replaces all)
- `MergeAdditive`: models.dev (enhancements, no removal)

## Package Map

**Public contracts**: catalogs, storage, sources, errors, logging, constants

**Internal packages**:

- bootstrap/{manifest,budget}, catalog/{authority,reconciler}, and cli/{app,commands,convert}
- embedded, server, and server/handlers
- sources/{providers,modelsdev,local,payload} and providers/{clients,openai,anthropic,google}
- test/{catalog,logging,providerfixture} and transport

**Application**: consumer-local command/server roles, internal/cli/app (implementation)

See [ARCHITECTURE.md § Package Organization](docs/ARCHITECTURE.md#package-organization) for full structure.

## Environment Variables

**Required** (per provider):
```bash
OPENAI_API_KEY=sk-...
ANTHROPIC_API_KEY=sk-ant-...
GOOGLE_API_KEY=...
GROQ_API_KEY=...
DEEPSEEK_API_KEY=...
CEREBRAS_API_KEY=...
HETZNER_API_KEY=...
DASHSCOPE_API_KEY=...
FIREWORKS_API_KEY=...
DEEPINFRA_TOKEN=...
```

`DEEPINFRA_TOKEN` is optional for DeepInfra catalog fetching because
`GET /v1/openai/models` is public. DeepInfra inference calls require the token.

**Alibaba Cloud Model Studio** (optional non-US workspace domains):
```bash
ALIBABA_MODEL_STUDIO_BASE_URL=https://{WorkspaceId}.ap-southeast-1.maas.aliyuncs.com/compatible-mode/v1
```

**Google Vertex** (optional):
```bash
GOOGLE_VERTEX_PROJECT=my-project
GOOGLE_VERTEX_LOCATION=us-central1
GOOGLE_APPLICATION_CREDENTIALS=/path/to/service-account.json
```

## Key File Locations

| File | Purpose |
|------|---------|
| `client.go` / `update.go` | Immutable root API and explicit publication |
| `acquisition/syncer.go` | Opt-in provider/source synchronization |
| `internal/catalog/pipeline/` | Prepare-only source pipeline |
| `internal/cli/commands/*/application.go` | Consumer-local command dependency roles |
| `internal/server/application.go` | HTTP server application role |
| `internal/cli/app/app.go` | App implementation |
| `internal/cli/commands/serve/command.go` | HTTP server CLI command |
| `internal/server/server.go` | Server lifecycle & dependencies |
| `internal/server/router.go` | Route registration & middleware |
| `internal/server/handlers/handlers.go` | Handler base structure |
| `internal/catalog/reconciler/reconciler.go` | Multi-source reconciliation |
| `pkg/catalogs/authority/authority.go` | Field-level authorities |
| `internal/sources/providers/providers.go` | Concurrent provider fetching |
| `internal/providers/clients/provider.go` | Provider client registry |
| `internal/embedded/catalog/providers.yaml` | Provider configurations |
| `internal/embedded/catalog/authors/*/models/*.yaml` | Canonical authored identity and intrinsic facts |
| `internal/embedded/catalog/providers/*/models/**/*.yaml` | Exact provider-serving facts linked by `model: author/slug` |
| `internal/embedded/catalog/endpoints.yaml` | Generated digest-bound endpoint projection, never editable authority |

## Development Commands

### Build & Development

```bash
make all            # Full cycle: clean, fix, lint, test, build
make build          # Build binary
make install        # Install to $GOPATH/bin
make fix            # Format and tidy
make lint           # Run golangci-lint and goago
```

### Testing

```bash
make test                                   # Run all tests
go test ./pkg/catalogs -race -v            # Race detection
go test ./... -race -short                 # All packages with race detector
```

### Verification gates

```bash
make verify                                     # scripts/verify.sh runs every automated gate
go tool goago -stale-ignores -format json ./...   # Run the pinned restriction linter
bash scripts/verify-live-providers.sh           # Manual only: calls live provider APIs
bash scripts/verify-provider-fixture-drift.sh   # Manual only: calls live provider APIs
```

`make verify` owns every `scripts/verify-*.sh` gate except the two gates above.
Both need real catalog-acquisition credentials, which no workflow holds today, so
run them by hand before a provider client change. A gate that no workflow runs
cannot report a regression, so add each new gate to `scripts/verify.sh` or name
it here.

`verify-provider-fixture-drift.sh` owns the fixture maximum-age and wire-drift
policy. Offline tests stay hermetic. `Fixture.Verify` checks identity, bytes,
and the content digest. It never consults the calendar.
`Fixture.VerifyFreshness` enforces `max_age`. Only this credentialed gate calls
it. A live capture must clear a stale or drifted fixture. Clear a reported
fixture with `make testdata PROVIDER=<provider-id>`.

Each governed fixture belongs to the client that proves its wire contract, so a
custom protocol client owns its own capture path under
`internal/providers/<client>/testdata/providers/<provider-id>/`. Anthropic is the
current example. `make testdata PROVIDER=<provider-id>` selects the right capture
path for you, and the drift gate covers every client.

### Catalog Management

```bash
make update-catalog                         # Update embedded catalog (all providers)
make update-catalog-provider PROVIDER=openai  # Update specific provider
make catalog-generation-check               # Verify safe download/promotion/CLI tooling
make testdata                               # Refresh all governed fixtures
make testdata PROVIDER=openai               # Refresh one provider fixture
```

### Documentation

```bash
make generate       # Generate Go docs
make godoc          # Go docs only
make docs-check     # Verify docs current (CI)
```

## Implementation Notes

**Important Constraints:**
- Go embed requires binary rebuild for catalog changes
- Sync pipeline order: Filter → Fetch → Reconcile → Save
- Provider sources fetch concurrently (goroutines + channels)
- Authority system determines field-level source priority
- Always prefer editing existing files over creating new ones

**Thread Safety:**
- Collections return values (not pointers) for safety
- All catalog access returns deep copies
- See docs/ARCHITECTURE.md § Thread Safety for full guidelines

**Import Cycles:**
- Zero import cycles (validated)
- Dependency flow is unidirectional (see docs/ARCHITECTURE.md)
- Commands define the smallest interface they consume and do not import `internal/cli/app/`

## References

- **[ARCHITECTURE.md](docs/ARCHITECTURE.md)** - Technical deep dive (system components, thread safety, sync pipeline)
- **[CLI.md](docs/CLI.md)** - CLI implementation reference (flags, patterns, examples)
- **[README.md](README.md)** - User-facing documentation
- **[Makefile](Makefile)** - Build automation and commands
- **[pkg/*/README.md](pkg/)** - Individual package documentation
