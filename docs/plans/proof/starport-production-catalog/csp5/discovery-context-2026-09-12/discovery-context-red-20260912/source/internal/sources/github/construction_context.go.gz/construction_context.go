package github

import "context"

// NewContext constructs a source with the existing constructor behavior.
func NewContext(_ context.Context, opts ...Option) (*Source, error) {
	return New(opts...)
}
