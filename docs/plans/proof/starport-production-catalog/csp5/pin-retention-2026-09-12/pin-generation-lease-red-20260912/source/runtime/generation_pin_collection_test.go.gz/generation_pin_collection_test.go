package runtime

import (
	"bytes"
	"testing"

	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/catalogs/storage"
)

func TestOriginGenerationPinProtectsItsOriginalSelectionFromCollection(t *testing.T) {
	store := storage.NewMemory()
	source := newStubSource("pin-collection")
	first := aliasGeneration(t, "pin-collection-first")
	source.replies = []SourceRead{aliasRead(first)}
	options := []Option{WithStateDirectory(privateRuntimeDirectory(t)), WithCatalogSource("embedded"),
		WithSource(source), WithSourceRefreshMode("manual"), WithAuthorityOrigin(store, originTestConfig())}
	r := openTestRuntime(t, options...)
	if _, err := r.RefreshSource(t.Context()); err != nil {
		t.Fatal(err)
	}
	selected, err := store.Current(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	next := first.Copy()
	next.Manifest.GenerationID = "pin-collection-second"
	next.Payload = bytes.ReplaceAll(next.Payload, []byte(`"Current"`), []byte(`"Changed"`))
	next.Manifest.Payload = catalogs.DescribeCatalogPayload(next.Payload)
	source.mu.Lock()
	source.replies = []SourceRead{aliasRead(next)}
	source.mu.Unlock()
	if _, err := r.RefreshSource(t.Context()); err != nil {
		t.Fatal(err)
	}
	if err := r.Close(); err != nil {
		t.Fatal(err)
	}
	pinned := openTestRuntime(t, append(options, WithGenerationPin(selected.Manifest.GenerationID))...)
	current := pinned.State()
	if current.GenerationID == selected.Manifest.GenerationID {
		t.Fatal("fixture did not reissue the pinned payload at a new authority generation")
	}
	report, err := store.Collect(t.Context(), storage.RetentionRequest{
		ExpectedGenerationID: current.GenerationID, MaxGenerations: 1, MaxBytes: 1,
	})
	if err != nil {
		t.Fatal(err)
	}
	if _, err := store.Get(t.Context(), selected.Manifest.GenerationID); err != nil {
		t.Fatalf("collection removed the running origin's original pin selection: %v; report = %+v", err, report)
	}
}
