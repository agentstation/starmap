package permission

import "github.com/agentstation/starmap/pkg/catalogs/storage"

// GenerationLeaser forwards optional read leases without exposing an unguarded writer.
func (p *Publisher) GenerationLeaser() (storage.GenerationLeaser, bool) {
	if p == nil || nilPublicationStore(p.store) {
		return nil, false
	}
	return storage.GenerationLeaserFor(p.store)
}

var _ storage.GenerationLeaseProvider = (*Publisher)(nil)
