package starmap

import (
	"context"

	bootstraploader "github.com/agentstation/starmap/internal/bootstrap"
	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/catalogs/storage"
	"github.com/agentstation/starmap/pkg/errors"
)

// CanLeaseGenerations reports whether the selected store supports generation read leases.
// It reads no storage and starts no background work.
func (c *Client) CanLeaseGenerations() bool {
	if c == nil || c.options == nil || isNilCatalogStore(c.options.catalogStore) {
		return false
	}
	_, ok := storage.GenerationLeaserFor(c.options.catalogStore)
	return ok
}

// AcquireGeneration reads and protects a stored generation until release.
// The selected store must support read leases. A missing embedded generation
// returns the verified compiled artifact, which cannot need storage collection.
// The caller must release every successful acquisition, even after cancellation.
func (c *Client) AcquireGeneration(ctx context.Context, id string) (catalogs.Generation, func() error, error) {
	if c == nil || c.options == nil {
		return catalogs.Generation{}, nil, &errors.ValidationError{Field: "starmap.client", Message: "is required"}
	}
	if ctx == nil {
		ctx = context.Background()
	}
	if err := ctx.Err(); err != nil {
		return catalogs.Generation{}, nil, err
	}
	if !c.CanLeaseGenerations() {
		return catalogs.Generation{}, nil, &errors.ConfigError{Component: "catalog generation lease", Message: "selected store does not support generation read leases"}
	}
	leaser, _ := storage.GenerationLeaserFor(c.options.catalogStore)
	generation, release, err := leaser.AcquireGeneration(ctx, id)
	if err == nil || !errors.IsNotFound(err) {
		return generation, release, err
	}
	c.mu.RLock()
	embeddedID := c.embeddedBootstrap.GenerationID
	c.mu.RUnlock()
	if id != embeddedID {
		return catalogs.Generation{}, nil, err
	}
	generation, err = bootstraploader.Generation()
	if err != nil {
		return catalogs.Generation{}, nil, err
	}
	return generation, func() error { return nil }, nil
}
