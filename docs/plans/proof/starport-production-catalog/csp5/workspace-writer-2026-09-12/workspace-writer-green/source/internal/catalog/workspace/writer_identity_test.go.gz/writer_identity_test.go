package workspace

import (
	stderrors "errors"
	"io/fs"
	"os"
	"path/filepath"
	"runtime"
	"testing"
)

func TestWorkspaceWriterReplacementStopsPublication(t *testing.T) {
	for _, journal := range []bool{false, true} {
		t.Run(map[bool]string{false: "native", true: "journal"}[journal], func(t *testing.T) {
			target := filepath.Join(t.TempDir(), "workspace")
			old, oldID := testCatalog(t, "old", "Old Model")
			if _, err := Project(t.Context(), target, old, oldID); err != nil {
				t.Fatal(err)
			}
			next, nextID := testCatalog(t, "new", "New Model")
			var contender func()
			var replacement os.FileInfo
			nativeRefusal := false
			p := projector{journalReplacement: journal, beforePromote: func() error {
				path := writerLockPath(target)
				if err := os.Rename(path, path+".original"); err != nil {
					if runtime.GOOS == "windows" && stderrors.Is(err, fs.ErrPermission) {
						nativeRefusal = true
						return nil
					}
					return err
				}
				if err := os.WriteFile(path, nil, fileMode); err != nil {
					return err
				}
				var err error
				replacement, err = os.Stat(path)
				if err != nil {
					return err
				}
				contender, err = acquireWriterLock(target)
				return err
			}}
			_, err := p.project(t.Context(), target, next, nextID, InputExpectation{})
			if contender != nil {
				defer contender()
			}
			if nativeRefusal {
				if err != nil {
					t.Fatal(err)
				}
				assertWorkspaceModel(t, target, "new", "New Model")
				return
			}
			assertReadConflict(t, err)
			if contender == nil || replacement == nil {
				t.Fatal("replacement writer did not acquire its lock")
			}
			after, statErr := os.Stat(writerLockPath(target))
			if statErr != nil || !os.SameFile(replacement, after) {
				t.Fatalf("old writer changed replacement lock: %v", statErr)
			}
			assertWorkspaceModel(t, target, "old", "Old Model")
		})
	}
}
