package runtime

import (
	"bytes"
	"encoding/json"
	"os"
	"path/filepath"
	"testing"

	"github.com/agentstation/starmap"
	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/catalogs/storage"
)

func TestGenerationPinRecordsOneAcceptanceAcrossRestart(t *testing.T) {
	store := storage.NewMemory()
	selected := aliasGeneration(t, "receipt-selected")
	if err := store.Commit(t.Context(), selected, ""); err != nil {
		t.Fatal(err)
	}
	newer := aliasGeneration(t, "receipt-newer")
	if err := store.Commit(t.Context(), newer, selected.Manifest.GenerationID); err != nil {
		t.Fatal(err)
	}
	directory := privateRuntimeDirectory(t)
	options := []Option{WithCatalogSource("embedded"), WithStateDirectory(directory), WithGenerationPin(selected.Manifest.GenerationID),
		WithClientOptions(starmap.WithCatalogStore(store))}
	var prior []byte
	for range 2 {
		r := openTestRuntime(t, options...)
		raw, err := os.ReadFile(filepath.Join(directory, "catalog-runtime", "generation-pin.json"))
		if err != nil {
			t.Fatal(err)
		}
		var record struct {
			Phase   string `json:"phase"`
			Receipt struct {
				OperationID          string `json:"operation_id"`
				SelectedGenerationID string `json:"selected_generation_id"`
				AcceptedGenerationID string `json:"accepted_generation_id"`
				PreviousGenerationID string `json:"previous_generation_id"`
			} `json:"receipt"`
		}
		if err := json.Unmarshal(raw, &record); err != nil {
			t.Fatal(err)
		}
		if record.Phase != "accepted" || record.Receipt.OperationID == "" || record.Receipt.SelectedGenerationID != selected.Manifest.GenerationID ||
			record.Receipt.AcceptedGenerationID != r.State().GenerationID || record.Receipt.PreviousGenerationID != newer.Manifest.GenerationID {
			t.Fatal("pin acceptance does not identify the selected artifact and predecessor")
		}
		if prior != nil && !bytes.Equal(raw, prior) {
			t.Fatal("restart replaced the acceptance event")
		}
		prior = raw
		if err := r.Close(); err != nil {
			t.Fatal(err)
		}
	}
}

func TestOriginGenerationPinPublishesPriorPayloadAtNewRevision(t *testing.T) {
	store := storage.NewMemory()
	source := newStubSource("origin-pin")
	first := aliasGeneration(t, "origin-input-first")
	source.replies = []SourceRead{aliasRead(first)}
	options := []Option{WithStateDirectory(privateRuntimeDirectory(t)), WithCatalogSource("embedded"),
		WithSource(source), WithSourceRefreshMode("manual"), WithAuthorityOrigin(store, originTestConfig())}
	r := openTestRuntime(t, options...)
	if _, err := r.RefreshSource(t.Context()); err != nil {
		t.Fatal(err)
	}
	selected, err := store.Current(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	next := first.Copy()
	next.Manifest.GenerationID = "origin-input-second"
	next.Payload = bytes.ReplaceAll(next.Payload, []byte(`"Current"`), []byte(`"Changed"`))
	next.Manifest.Payload = catalogs.DescribeCatalogPayload(next.Payload)
	if err := next.Validate(); err != nil {
		t.Fatal(err)
	}
	source.mu.Lock()
	source.replies = []SourceRead{aliasRead(next)}
	source.mu.Unlock()
	if _, err := r.RefreshSource(t.Context()); err != nil {
		t.Fatal(err)
	}
	previous := r.State()
	if previous.PayloadChecksum == selected.Manifest.Payload.Checksum {
		t.Fatal("fixture did not change the catalog")
	}
	if err := r.Close(); err != nil {
		t.Fatal(err)
	}
	options = append(options, WithGenerationPin(selected.Manifest.GenerationID))
	var activated string
	for range 2 {
		pinned := openTestRuntime(t, options...)
		state := pinned.State()
		if state.GenerationID == selected.Manifest.GenerationID || state.AuthorityHead.Sequence != previous.AuthorityHead.Sequence+1 ||
			state.PayloadChecksum != selected.Manifest.Payload.Checksum {
			t.Fatal("origin rollback did not bind the prior payload to a new authority revision")
		}
		if activated != "" && state.GenerationID != activated {
			t.Fatal("restart issued another rollback revision")
		}
		activated = state.GenerationID
		permission, err := pinned.ReadPermission(t.Context())
		if err != nil || permission.Head != state.AuthorityHead {
			t.Fatalf("issuer differs from the rollback: %v", err)
		}
		if err := pinned.Close(); err != nil {
			t.Fatal(err)
		}
	}
}
