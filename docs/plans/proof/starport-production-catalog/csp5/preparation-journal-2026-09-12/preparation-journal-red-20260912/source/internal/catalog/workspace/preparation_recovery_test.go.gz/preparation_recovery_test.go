package workspace

import (
	"os"
	"os/exec"
	"path/filepath"
	"testing"
)

func TestPreparationRecoveryAfterProcessExit(t *testing.T) {
	if target := os.Getenv("STARMAP_TEST_PREPARATION_EXIT"); target != "" {
		catalog, identity := testCatalog(t, "new", "New")
		_, err := (projector{afterStageRender: func(string) error {
			os.Exit(89)
			return nil
		}}).project(t.Context(), target, catalog, identity, InputExpectation{})
		t.Fatalf("child did not exit during preparation: %v", err)
	}
	target := filepath.Join(t.TempDir(), "workspace")
	command := exec.CommandContext(t.Context(), os.Args[0], "-test.run=^TestPreparationRecoveryAfterProcessExit$")
	command.Env = append(os.Environ(), "STARMAP_TEST_PREPARATION_EXIT="+target)
	output, err := command.CombinedOutput()
	if command.ProcessState == nil || command.ProcessState.ExitCode() != 89 {
		t.Fatalf("child exit: %v, %s", err, output)
	}
	stages, err := filepath.Glob(filepath.Join(filepath.Dir(target), ".workspace.preparing-*"))
	if err != nil || len(stages) != 1 {
		t.Fatalf("abandoned preparation: %v, %v", stages, err)
	}
	catalog, identity := testCatalog(t, "new", "New")
	if _, err := Repair(t.Context(), target, catalog, identity); err != nil {
		t.Fatal(err)
	}
	if _, err := os.Lstat(stages[0]); !os.IsNotExist(err) {
		t.Fatalf("owned preparation survived recovery: %v", err)
	}
	assertNoProjectionStaging(t, target)
}
