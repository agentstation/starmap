package starmap

import (
	"context"
	"strings"

	"github.com/agentstation/starmap/internal/catalog/workspace"
	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/catalogs/projection"
	"github.com/agentstation/starmap/pkg/errors"
)

// RollbackResult describes an activated, retained immutable generation.
type RollbackResult struct {
	// FromGenerationID is the generation active before rollback.
	FromGenerationID string
	// GenerationID is the retained generation selected by rollback.
	GenerationID string
	// PayloadChecksum identifies the exact immutable generation payload.
	PayloadChecksum string
	// Sequence is the in-process publication sequence after rollback.
	Sequence uint64
	// Projection reports exact workspace restoration or pending repair.
	Projection *projection.Result
}

// Rollback atomically makes a retained generation current and projects its
// exact catalog semantics and provenance into the configured human catalog workspace.
// Repeating a rollback to the current durable generation is idempotent.
func (c *Client) Rollback(ctx context.Context, generationID string) (*RollbackResult, error) {
	if c == nil {
		return nil, &errors.ValidationError{Field: "starmap.client", Message: "is required"}
	}
	generationID = strings.TrimSpace(generationID)
	if generationID == "" {
		return nil, &errors.ValidationError{Field: "generation_id", Message: "is required"}
	}
	if ctx == nil {
		ctx = context.Background()
	}
	if err := c.requireWritableCatalogStore(); err != nil {
		return nil, err
	}
	if err := c.authorizePublication(ctx); err != nil {
		return nil, err
	}
	catalogPath := c.options.catalogPath
	if err := validateCatalogLayout(c.options.catalogStore, catalogPath); err != nil {
		return nil, err
	}

	release, err := c.updates.acquire(ctx)
	if err != nil {
		return nil, err
	}
	defer release()
	if err := c.authorizePublication(ctx); err != nil {
		return nil, err
	}

	target, err := c.Generation(ctx, generationID)
	if err != nil {
		return nil, err
	}
	if err := target.Validate(); err != nil {
		return nil, errors.WrapResource("validate", "rollback generation", generationID, err)
	}
	if target.Manifest.GenerationID != generationID {
		return nil, &errors.ValidationError{
			Field:   "rollback.generation_id",
			Value:   target.Manifest.GenerationID,
			Message: "does not match the requested retained generation",
		}
	}
	published, err := catalogs.DecodeCatalogGeneration(target)
	if err != nil {
		return nil, errors.WrapResource("decode", "rollback generation", generationID, err)
	}

	input, err := observeBoundWorkspaceInput(ctx, catalogPath)
	if err != nil {
		return nil, err
	}

	c.mu.RLock()
	expectedGenerationID := c.generationID
	fromGenerationID := expectedGenerationID
	if fromGenerationID == "" && c.usingEmbeddedBootstrap {
		fromGenerationID = c.embeddedBootstrap.GenerationID
	}
	sequence := c.generationSequence
	c.mu.RUnlock()

	result := &RollbackResult{
		FromGenerationID: fromGenerationID,
		GenerationID:     target.Manifest.GenerationID,
		PayloadChecksum:  target.Manifest.Payload.Checksum,
		Sequence:         sequence,
	}
	if expectedGenerationID == "" && fromGenerationID == target.Manifest.GenerationID {
		return result, nil
	}

	if err := c.options.catalogStore.Commit(ctx, target, expectedGenerationID); err != nil {
		return nil, errors.WrapResource("rollback", "catalog generation", generationID, err)
	}
	if expectedGenerationID != target.Manifest.GenerationID {
		c.publishCommittedGeneration(published, target)
		result.Sequence = c.CurrentCatalogState().Sequence
	}
	if catalogPath != "" {
		result.Projection = projectRollbackCatalog(
			ctx,
			published,
			catalogPath,
			workspace.Identity{
				GenerationID:    target.Manifest.GenerationID,
				PayloadChecksum: target.Manifest.Payload.Checksum,
			},
			input,
		)
	}
	return result, nil
}

func projectRollbackCatalog(
	ctx context.Context,
	catalog *catalogs.Catalog,
	path string,
	identity workspace.Identity,
	input workspace.InputExpectation,
) *projection.Result {
	result := &projection.Result{
		Path:         path,
		Status:       projection.StatusPendingRepair,
		GenerationID: identity.GenerationID,
	}
	receipt, err := workspace.ProjectExpected(ctx, path, catalog, identity, input)
	result.WorkspaceChecksum = receipt.WorkspaceChecksum
	if err != nil {
		result.IssueCode = projection.IssueWorkspaceFailed
		return result
	}
	result.Status = projection.StatusApplied
	return result
}

func observeBoundWorkspaceInput(ctx context.Context, path string) (workspace.InputExpectation, error) {
	var input workspace.InputExpectation
	err := workspace.Read(ctx, path, func(observed workspace.InputExpectation) error {
		input = observed
		if !input.Exists {
			return nil
		}
		builder, err := catalogs.NewFromPath(path)
		if err != nil {
			return errors.WrapResource("load", "rollback workspace", path, err)
		}
		if err := builder.LoadReport().Err(); err != nil {
			return errors.WrapResource("load", "rollback workspace model", path, err)
		}
		catalog, err := builder.Build()
		if err != nil {
			return errors.WrapResource("publish", "rollback workspace input", path, err)
		}
		input, err = workspace.BindInputCatalog(input, catalog)
		return err
	})
	if err != nil {
		return workspace.InputExpectation{}, err
	}
	return input, nil
}
