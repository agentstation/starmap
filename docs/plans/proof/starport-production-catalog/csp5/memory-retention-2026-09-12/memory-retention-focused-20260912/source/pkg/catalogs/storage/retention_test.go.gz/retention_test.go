package storage

import (
	"context"
	"errors"
	"reflect"
	"testing"
	"time"

	"github.com/agentstation/starmap/pkg/catalogs"
)

func TestMemoryRetentionProtectsCurrentRequiredAndLeasedGenerations(t *testing.T) {
	store := NewMemory()
	retaining, ok := any(store).(RetainingStore)
	if !ok {
		t.Fatal("memory catalog store cannot collect obsolete generations with read leases")
	}
	ctx := t.Context()
	var generations []catalogs.Generation
	previous := ""
	for _, id := range []string{"baseline", "expired", "leased", "pin", "current"} {
		generation := testGeneration(id, id)
		generation.Manifest.GeneratedAt = generation.Manifest.GeneratedAt.Add(time.Duration(len(generations)) * time.Minute)
		generation.Manifest.Validation.ValidatedAt = generation.Manifest.GeneratedAt
		if err := store.Commit(ctx, generation, previous); err != nil {
			t.Fatal(err)
		}
		generations = append(generations, generation)
		previous = id
	}
	leased, release, err := retaining.AcquireGeneration(ctx, "leased")
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = release() })
	leased.Payload[0] = '!'
	request := RetentionRequest{ExpectedGenerationID: "current", RequiredGenerationIDs: []string{"baseline", "pin"}, MaxGenerations: 2, MaxBytes: 1 << 20}
	dry := request
	dry.DryRun = true
	preview, err := retaining.Collect(ctx, dry)
	if err != nil || !reflect.DeepEqual(preview.Candidates, []string{"expired"}) || len(preview.Removed) != 0 || preview.After != preview.Before {
		t.Fatalf("dry collection changed storage or selected protected content: %+v, %v", preview, err)
	}
	report, err := retaining.Collect(ctx, request)
	if err != nil || !report.OverLimit || report.Protected.Generations != 4 || report.After.Generations != 4 || !reflect.DeepEqual(report.Removed, []string{"expired"}) {
		t.Fatalf("collection failed to retain protected generations: %+v, %v", report, err)
	}
	for _, index := range []int{0, 2, 3, 4} {
		got, err := store.Get(ctx, generations[index].Manifest.GenerationID)
		if err != nil || !sameGeneration(got, generations[index]) {
			t.Fatalf("protected generation changed: %v", err)
		}
	}
	if err := release(); err != nil {
		t.Fatal(err)
	}
	if err := release(); err != nil {
		t.Fatal(err)
	}
	report, err = retaining.Collect(ctx, request)
	if err != nil || !reflect.DeepEqual(report.Removed, []string{"leased"}) || report.After.Generations != 3 {
		t.Fatalf("released generation remains protected: %+v, %v", report, err)
	}
}

func TestMemoryRetentionRefusesStaleMissingAndIncompleteRequests(t *testing.T) {
	store := NewMemory()
	retaining, ok := any(store).(RetainingStore)
	if !ok {
		t.Fatal("memory catalog store cannot enforce retention preconditions")
	}
	first, current := testGeneration("first", "first"), testGeneration("current", "current")
	if err := store.Commit(t.Context(), first, ""); err != nil {
		t.Fatal(err)
	}
	if err := store.Commit(t.Context(), current, "first"); err != nil {
		t.Fatal(err)
	}
	base := RetentionRequest{ExpectedGenerationID: "current", MaxGenerations: 1, MaxBytes: 1 << 20}
	for _, name := range []string{"stale", "missing-required", "scan-limit", "invalid-count", "invalid-bytes", "canceled"} {
		t.Run(name, func(t *testing.T) {
			request := base
			ctx, cancel := context.WithCancel(t.Context())
			defer cancel()
			switch name {
			case "stale":
				request.ExpectedGenerationID = "first"
			case "missing-required":
				request.RequiredGenerationIDs = []string{"missing"}
			case "scan-limit":
				request.ScanEntries = 1
			case "invalid-count":
				request.MaxGenerations = 0
			case "invalid-bytes":
				request.MaxBytes = 0
			case "canceled":
				cancel()
			}
			report, err := retaining.Collect(ctx, request)
			if err == nil || len(report.Removed) != 0 {
				t.Fatalf("invalid request changed storage: %+v, %v", report, err)
			}
			if name == "canceled" && !errors.Is(err, context.Canceled) {
				t.Fatalf("lost cancellation: %v", err)
			}
			if _, err := store.Get(t.Context(), "first"); err != nil {
				t.Fatalf("refusal removed the prior generation: %v", err)
			}
		})
	}
}
