package workspace

import (
	"bytes"
	stderrors "errors"
	"os"
	"path/filepath"
	"testing"
)

func TestPreparationCleanupPreservesOperatorChanges(t *testing.T) {
	for _, change := range []string{"unknown-child", "changed-render", "replaced-render-file", "replaced-enclosure"} {
		t.Run(change, func(t *testing.T) {
			path := filepath.Join(t.TempDir(), "workspace")
			catalog, identity := testCatalog(t, "new", "New")
			fault := stderrors.New("stop after operator change")
			var preserved string
			var want []byte
			_, err := (projector{afterStageRender: func(render string) error {
				enclosure := filepath.Dir(render)
				preserved = filepath.Join(render, "providers.yaml")
				var err error
				want, err = os.ReadFile(preserved)
				if err != nil {
					return err
				}
				switch change {
				case "unknown-child":
					preserved = filepath.Join(enclosure, "operator-note")
					want = []byte("preserve this note")
				case "changed-render":
					want = []byte("operator change")
				case "replaced-render-file":
					if err := os.Rename(preserved, filepath.Join(filepath.Dir(enclosure), "original-provider-file")); err != nil {
						return err
					}
				case "replaced-enclosure":
					if err := os.Rename(enclosure, enclosure+".moved"); err != nil {
						return err
					}
					if err := os.Mkdir(enclosure, directoryMode); err != nil {
						return err
					}
					preserved = filepath.Join(enclosure, "operator-note")
					want = []byte("preserve this replacement")
				}
				if err := os.WriteFile(preserved, want, fileMode); err != nil {
					return err
				}
				return fault
			}}).project(t.Context(), path, catalog, identity, InputExpectation{})
			if !stderrors.Is(err, fault) {
				t.Fatalf("projection error: %v", err)
			}
			data, err := os.ReadFile(preserved)
			if err != nil || !bytes.Equal(data, want) {
				t.Fatalf("preparation removed operator content: %q, %v", data, err)
			}
			if _, err := os.Lstat(path); !os.IsNotExist(err) {
				t.Fatalf("failed preparation published a workspace: %v", err)
			}
		})
	}
}
