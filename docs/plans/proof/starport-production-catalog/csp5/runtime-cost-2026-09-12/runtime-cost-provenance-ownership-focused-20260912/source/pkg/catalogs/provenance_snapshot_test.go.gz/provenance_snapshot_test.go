package catalogs

import (
	"bytes"
	"testing"

	"github.com/agentstation/starmap/pkg/catalogs/evidence"
	"github.com/agentstation/starmap/pkg/provenance"
)

func TestImmutableProvenanceOwnsNestedValues(t *testing.T) {
	for _, observation := range []bool{false, true} {
		name := "catalog"
		if observation {
			name = "observation"
		}
		t.Run(name, func(t *testing.T) {
			input := map[string]any{"nested": []any{map[string]any{"name": "original"}}}
			previous := map[string]any{"name": "previous"}
			rejections := []provenance.Rejection{{Reason: "original rejection"}}
			builder := NewEmpty()
			if err := builder.SetAuthor(Author{ID: "author", Name: "Author"}); err != nil {
				t.Fatal(err)
			}
			const key = "author:author:metadata"
			builder.SetProvenance(provenance.Map{key: {{Field: "metadata", Value: input, PreviousValue: previous, Rejections: rejections}}})
			var catalog *Catalog
			var err error
			if observation {
				catalog, err = NewObservationCatalog(builder)
			} else {
				catalog, err = builder.Build()
			}
			if err != nil {
				t.Fatal(err)
			}
			want, err := EncodeCatalogPayload(catalog)
			if err != nil {
				t.Fatal(err)
			}
			input["nested"].([]any)[0].(map[string]any)["name"] = "changed input"
			previous["name"] = "changed previous"
			rejections[0].Reason = "changed rejection"
			reader := catalog.Provenance()
			for _, entries := range [][]provenance.Entry{
				reader.Map()[key],
				reader.FindByField(evidence.ResourceTypeAuthor, "author", "metadata"),
				reader.FindByResource(evidence.ResourceTypeAuthor, "author")["metadata"],
			} {
				if len(entries) != 1 {
					t.Fatal("provenance entry disappeared")
				}
				entry := entries[0]
				value := entry.Value.(map[string]any)["nested"].([]any)[0].(map[string]any)
				if value["name"] != "original" || entry.PreviousValue.(map[string]any)["name"] != "previous" || entry.Rejections[0].Reason != "original rejection" {
					t.Fatal("immutable provenance retained mutable input references")
				}
				value["name"] = "changed read"
				entry.PreviousValue.(map[string]any)["name"] = "changed read"
				entry.Rejections[0].Reason = "changed read"
			}
			fresh, err := encodeCatalogPayload(catalog)
			if err != nil || !bytes.Equal(fresh, want) {
				t.Fatalf("catalog reads diverged from its encoded payload: %v", err)
			}
		})
	}
}
