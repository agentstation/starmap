package reconciler

import (
	"bytes"
	"encoding/json"
	"testing"

	"github.com/agentstation/starmap/pkg/catalogs"
)

func TestSemanticEvidenceMatchesCanonicalSnapshot(t *testing.T) {
	for _, record := range catalogs.PublishedModelRecords() {
		t.Run(string(record), func(t *testing.T) {
			model := knownRecordModel(t, record)
			merger := newMerger(nil, nil, nil)
			value := merger.modelFieldValue(&model, recordPolicyPaths[record])
			encoded, err := json.Marshal(value)
			if err != nil {
				t.Fatal(err)
			}
			decoder := json.NewDecoder(bytes.NewReader(encoded))
			decoder.UseNumber()
			var restored any
			if err := decoder.Decode(&restored); err != nil {
				t.Fatal(err)
			}
			if !semanticValueEqual(recordPolicyPaths[record], value, restored) {
				t.Fatalf("typed evidence differs from its canonical snapshot: %s", encoded)
			}
		})
	}
}
