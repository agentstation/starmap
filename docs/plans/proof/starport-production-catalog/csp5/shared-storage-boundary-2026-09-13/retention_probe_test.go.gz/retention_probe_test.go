package catalog

import (
	"fmt"
	"reflect"
	"testing"
	"time"

	"github.com/stretchr/testify/require"
)

func TestCSP5GenerationHistoryDoesNotCollectStoredRecords(t *testing.T) {
	kv := openInMemoryBadger(t)
	generations, err := NewGenerationStore(kv)
	require.NoError(t, err)
	source := freshnessTestCatalog(t, []freshnessModelFact{{slug: "model", inputPer1M: 1, outputPer1M: 2}}, nil)
	expected := ""
	started := time.Date(2026, 9, 13, 0, 0, 0, 0, time.UTC)
	for i := range catalogGenerationIndexCap + 1 {
		id := fmt.Sprintf("retention-%03d", i)
		generation := runtimeTestGeneration(t, id, source, started.Add(time.Duration(i)*time.Minute))
		require.NoError(t, generations.Commit(t.Context(), generation, expected))
		expected = id
	}
	history, err := generations.History(t.Context())
	require.NoError(t, err)
	keys, err := kv.ScanWithPrefix(t.Context(), catalogGenerationKeyPrefix, 128)
	require.NoError(t, err)
	chunks, err := kv.ScanWithPrefix(t.Context(), catalogGenerationChunkKeyPrefix, 128)
	require.NoError(t, err)
	first, err := generations.Get(t.Context(), "retention-000")
	require.NoError(t, err)
	require.Len(t, history, catalogGenerationIndexCap)
	require.Len(t, keys, catalogGenerationIndexCap+1)
	require.Equal(t, "retention-000", first.Manifest.GenerationID)
	_, hasCollector := reflect.TypeOf(generations).MethodByName("Collect")
	_, hasReadLease := reflect.TypeOf(generations).MethodByName("AcquireGeneration")
	t.Logf("history_entries=%d stored_generation_records=%d stored_chunks=%d oldest_generation_readable=true collector_method=%t read_lease_method=%t", len(history), len(keys), len(chunks), hasCollector, hasReadLease)
}
