package workspace

import (
	"os"
	"os/exec"
	"path/filepath"
	"testing"
)

func TestCandidateRecoveryAfterProcessExit(t *testing.T) {
	if target := os.Getenv("STARMAP_TEST_CANDIDATE_EXIT"); target != "" {
		catalog, identity := testCatalog(t, "new", "New Model")
		p := projector{}
		stop := func() error { os.Exit(88); return nil }
		if os.Getenv("STARMAP_TEST_CANDIDATE_PHASE") == "prepared" {
			p.beforePromote = stop
		} else {
			p.beforeMarker = stop
		}
		_, err := p.project(t.Context(), target, catalog, identity, InputExpectation{})
		t.Fatalf("child did not exit during candidate publication: %v", err)
	}
	for _, phase := range []string{"prepared", "installed"} {
		t.Run(phase, func(t *testing.T) {
			target := filepath.Join(t.TempDir(), "workspace")
			old, oldID := testCatalog(t, "old", "Old Model")
			if _, err := Project(t.Context(), target, old, oldID); err != nil {
				t.Fatal(err)
			}
			command := exec.CommandContext(t.Context(), os.Args[0], "-test.run=^TestCandidateRecoveryAfterProcessExit$")
			command.Env = append(os.Environ(), "STARMAP_TEST_CANDIDATE_EXIT="+target, "STARMAP_TEST_CANDIDATE_PHASE="+phase)
			output, err := command.CombinedOutput()
			if command.ProcessState == nil || command.ProcessState.ExitCode() != 88 {
				t.Fatalf("child: %v, %s", err, output)
			}
			catalog, identity := testCatalog(t, "new", "New Model")
			if _, err := Repair(t.Context(), target, catalog, identity); err != nil {
				t.Fatal(err)
			}
			if phase == "installed" {
				assertWorkspaceModel(t, target, "new", "New Model")
			} else {
				assertWorkspaceModel(t, target, "old", "Old Model")
			}
			assertNoProjectionStaging(t, target)
		})
	}
}
