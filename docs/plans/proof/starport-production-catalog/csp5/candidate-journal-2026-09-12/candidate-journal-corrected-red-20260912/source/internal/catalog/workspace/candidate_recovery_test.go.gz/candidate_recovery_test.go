package workspace

import (
	"os"
	"os/exec"
	"path/filepath"
	"testing"
)

func TestCandidateRecoveryAfterProcessExit(t *testing.T) {
	if target := os.Getenv("STARMAP_TEST_CANDIDATE_EXIT"); target != "" {
		catalog, identity := testCatalog(t, "new", "New Model")
		p := projector{}
		stop := func() error { os.Exit(88); return nil }
		if os.Getenv("STARMAP_TEST_CANDIDATE_PHASE") == "prepared" {
			p.beforePromote = stop
		} else {
			p.beforeMarker = stop
		}
		_, err := p.project(t.Context(), target, catalog, identity, InputExpectation{})
		t.Fatalf("child did not exit during candidate publication: %v", err)
	}
	for _, phase := range []string{"prepared", "installed"} {
		t.Run(phase, func(t *testing.T) {
			target := filepath.Join(t.TempDir(), "workspace")
			old, oldID := testCatalog(t, "old", "Old Model")
			if _, err := Project(t.Context(), target, old, oldID); err != nil {
				t.Fatal(err)
			}
			command := exec.CommandContext(t.Context(), os.Args[0], "-test.run=^TestCandidateRecoveryAfterProcessExit$")
			command.Env = append(os.Environ(), "STARMAP_TEST_CANDIDATE_EXIT="+target, "STARMAP_TEST_CANDIDATE_PHASE="+phase)
			output, err := command.CombinedOutput()
			if command.ProcessState == nil || command.ProcessState.ExitCode() != 88 {
				t.Fatalf("child: %v, %s", err, output)
			}
			catalog, identity := testCatalog(t, "new", "New Model")
			if _, err := Repair(t.Context(), target, catalog, identity); err != nil {
				t.Fatal(err)
			}
			assertWorkspaceModel(t, target, "new", "New Model")
			assertNoProjectionStaging(t, target)
		})
	}
}

func TestCandidatePublicationRefusesChangedOwnership(t *testing.T) {
	for _, journal := range []bool{false, true} {
		t.Run(map[bool]string{false: "native", true: "journal"}[journal], func(t *testing.T) {
			for _, change := range []string{"entry-bytes", "entry-identity", "journal-bytes"} {
				t.Run(change, func(t *testing.T) {
					target := filepath.Join(t.TempDir(), "workspace")
					old, oldID := testCatalog(t, "old", "Old Model")
					if _, err := Project(t.Context(), target, old, oldID); err != nil {
						t.Fatal(err)
					}
					catalog, identity := testCatalog(t, "new", "New Model")
					p := projector{journalReplacement: journal, beforePromote: func() error {
						candidates, err := filepath.Glob(filepath.Join(filepath.Dir(target), ".workspace.candidate-*"))
						if err != nil || len(candidates) != 1 {
							t.Fatalf("candidate: %v, %v", candidates, err)
						}
						path := filepath.Join(candidates[0], "providers.yaml")
						data, err := os.ReadFile(path)
						if err != nil {
							return err
						}
						switch change {
						case "entry-bytes":
							data = []byte("operator bytes")
						case "entry-identity":
							if err := os.Rename(path, filepath.Join(filepath.Dir(target), "original-provider")); err != nil {
								return err
							}
						case "journal-bytes":
							stages, err := filepath.Glob(filepath.Join(filepath.Dir(target), ".workspace.preparing-*"))
							if err != nil || len(stages) != 1 {
								t.Fatalf("preparation: %v, %v", stages, err)
							}
							path = filepath.Join(stages[0], preparationJournalName)
							data, err = os.ReadFile(path)
							if err != nil {
								return err
							}
							data = append(data, '\n')
						}
						return os.WriteFile(path, data, fileMode)
					}}
					receipt, err := p.project(t.Context(), target, catalog, identity, InputExpectation{})
					if err == nil || receipt.GenerationID != "" {
						t.Fatalf("changed ownership published: receipt=%+v, err=%v", receipt, err)
					}
					assertWorkspaceModel(t, target, "old", "Old Model")
				})
			}
		})
	}
}
