package workspace

import (
	"bytes"
	stderrors "errors"
	"os"
	"path/filepath"
	"strings"
	"testing"
)

func TestWorkspaceRecordCleanupPreservesOperatorFiles(t *testing.T) {
	for _, flow := range []string{"projection", "journal", "journal-marker"} {
		for _, change := range []string{"changed-bytes", "replaced-identical", "recreated-after-publication", "replaced-after-partial-write"} {
			t.Run(flow+"/"+change, func(t *testing.T) {
				root := t.TempDir()
				target := filepath.Join(root, "workspace")
				if flow != "projection" {
					catalog, identity := testCatalog(t, "old", "Old")
					if _, err := Project(t.Context(), target, catalog, identity); err != nil {
						t.Fatal(err)
					}
				}
				fault := stderrors.New("stop record publication")
				var preserved string
				var want []byte
				var identity os.FileInfo
				selected := func(name string) bool {
					if flow == "journal" {
						return strings.Contains(filepath.Base(name), ".starmap-replacement.json.")
					}
					return strings.Contains(filepath.Base(name), ".starmap-projection.json.")
				}
				edit := func(name string) error {
					if !selected(name) {
						return nil
					}
					preserved = name
					want = []byte("operator content must survive\n")
					if change == "replaced-identical" {
						var err error
						want, err = os.ReadFile(name)
						if err != nil {
							return err
						}
					}
					if change != "changed-bytes" {
						if err := os.Rename(name, filepath.Join(root, "original-record")); err != nil && !os.IsNotExist(err) {
							return err
						}
					}
					if err := os.WriteFile(name, want, fileMode); err != nil {
						return err
					}
					var err error
					identity, err = os.Stat(name)
					if err != nil {
						return err
					}
					return fault
				}
				hooks := recordWriteHooks{}
				switch change {
				case "recreated-after-publication":
					hooks.afterPublish = edit
				case "replaced-after-partial-write":
					hooks.writeBytes = func(file *os.File, data []byte) (int, error) {
						if !selected(file.Name()) {
							return file.Write(data)
						}
						n, err := file.Write(data[:3])
						if err != nil {
							return n, err
						}
						return n, edit(file.Name())
					}
				default:
					hooks.beforePublish = edit
				}
				catalog, generation := testCatalog(t, "new", "New")
				_, err := (projector{journalReplacement: flow != "projection", recordWrites: hooks}).
					project(t.Context(), target, catalog, generation, InputExpectation{})
				if !stderrors.Is(err, fault) || preserved == "" || identity == nil {
					t.Fatalf("fault did not reach the selected record: %v", err)
				}
				got, readErr := os.ReadFile(preserved)
				if readErr != nil || !bytes.Equal(got, want) {
					t.Fatalf("cleanup removed operator content at %s: %v", preserved, readErr)
				}
				after, err := os.Stat(preserved)
				if err != nil || !os.SameFile(identity, after) {
					t.Fatalf("cleanup replaced the operator file: %v", err)
				}
			})
		}
	}
}
