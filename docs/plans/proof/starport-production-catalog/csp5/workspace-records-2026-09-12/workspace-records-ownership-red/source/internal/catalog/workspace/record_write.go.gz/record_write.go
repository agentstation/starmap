package workspace

import "os"

type recordWriteHooks struct {
	beforePublish func(string) error
	afterPublish  func(string) error
	writeBytes    func(*os.File, []byte) (int, error)
}

func (h recordWriteHooks) write(file *os.File, data []byte) (int, error) {
	if h.writeBytes != nil {
		return h.writeBytes(file, data)
	}
	return file.Write(data)
}
