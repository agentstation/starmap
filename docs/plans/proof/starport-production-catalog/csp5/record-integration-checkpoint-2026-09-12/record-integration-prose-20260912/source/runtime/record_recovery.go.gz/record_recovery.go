package runtime

import (
	"context"
	"os"

	"github.com/agentstation/starmap/internal/privatefiles"
)

func (s *layerStore) recoverRecordPublications(ctx context.Context) error {
	if !s.durable() {
		return ctx.Err()
	}
	directories := []*privatefiles.Directory{s.directory, s.providers, s.bindings}
	inputs, err := s.directory.ExistingChild(inputPublicationDirectory)
	if err != nil && !os.IsNotExist(err) {
		return err
	}
	if inputs != nil {
		directories = append(directories, inputs)
	}
	for _, directory := range directories {
		if directory != nil {
			if err := directory.RecoverPublications(ctx); err != nil {
				return err
			}
		}
	}
	return ctx.Err()
}
