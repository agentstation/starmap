package runtime

import (
 "os"
 "path/filepath"
 "testing"
)

func TestRuntimeMigrationPreservesUnrelatedRecordDirectory(t *testing.T) {
 request := directoryMigrationRequestFixture(t)
 parent := filepath.Join(request.SourceDirectory, "operator-data", ".record-publications")
 if err := os.MkdirAll(parent, 0o700); err != nil { t.Fatal(err) }
 path := filepath.Join(parent, "notes.jsonl")
 if err := os.WriteFile(path, []byte("operator-owned data"), 0o600); err != nil { t.Fatal(err) }
 manifest, err := PrepareDirectoryMigration(t.Context(), request)
 if err != nil { t.Fatalf("migration adopted an unrelated receipt directory: %v", err) }
 found := false
 for _, file := range manifest.Files { if file.Source == "operator-data/.record-publications/notes.jsonl" { found = true } }
 if !found { t.Fatal("migration omitted operator data") }
 data, err := os.ReadFile(path)
 if err != nil || string(data) != "operator-owned data" { t.Fatalf("migration changed operator data: %q %v", data, err) }
}
