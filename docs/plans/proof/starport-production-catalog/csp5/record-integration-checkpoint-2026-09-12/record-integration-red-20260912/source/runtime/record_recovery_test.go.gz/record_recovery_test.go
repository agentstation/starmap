package runtime

import (
	"context"
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/agentstation/starmap/pkg/catalogs"
)

type exitAfterRuntimeRecordStage struct {
	context.Context
	directory string
}

func (c exitAfterRuntimeRecordStage) Err() error {
	for _, relative := range []string{layerDirectoryName, layerDirectoryName + "/providers", layerDirectoryName + "/providers/bindings", layerDirectoryName + "/publication-inputs"} {
		entries, _ := os.ReadDir(filepath.Join(c.directory, relative))
		for _, entry := range entries {
			if strings.HasPrefix(entry.Name(), ".layer-") || strings.HasPrefix(entry.Name(), ".input-") {
				info, err := entry.Info()
				if err == nil && info.Size() > 0 {
					os.Exit(88)
				}
			}
		}
	}
	return c.Context.Err()
}

func TestRuntimeRecoversRecordPublicationAfterProcessExit(t *testing.T) {
	if path := os.Getenv("STARMAP_TEST_RUNTIME_RECORD_EXIT"); path != "" {
		store, err := newLayerStore(path)
		if err != nil {
			t.Fatal(err)
		}
		ctx := exitAfterRuntimeRecordStage{Context: t.Context(), directory: path}
		at := time.Date(2026, 9, 1, 12, 0, 0, 0, time.UTC)
		switch os.Getenv("STARMAP_TEST_RUNTIME_RECORD_KIND") {
		case "source":
			payload := testCatalogPayload(t, "source", "model", "Model")
			err = store.saveSource(ctx, sourceLayer{Identity: "test-source", GenerationID: "candidate", Payload: payload, Checksum: catalogs.DescribeCatalogPayload(payload).Checksum, PublishedAt: at, ObservedAt: at})
		case "provider":
			err = store.saveProvider(ctx, testProviderLayer(t, "provider", "model", "Model", at))
		case "binding":
			err = store.saveProvider(ctx, scopedProviderLayer(t, "account-a", "1", at))
		case "input":
			_, err = store.stageInput(ctx, map[string]string{"generation": "candidate"})
		case "pin":
			err = store.savePinRecord(ctx, generationPinRecord{Version: generationPinRecordVersion, Binding: strings.Repeat("0", 64), Phase: pinPrepared, Receipt: GenerationPinAcceptance{OperationID: "operation", SelectedGenerationID: "candidate", AcceptedGenerationID: "candidate", PayloadChecksum: "sha256:" + strings.Repeat("0", 64), RequestedAt: at}})
		default:
			t.Fatal("unknown child record")
		}
		t.Fatalf("writer did not exit: %v", err)
	}
	for _, kind := range []string{"source", "provider", "binding", "input", "pin"} {
		t.Run(kind, func(t *testing.T) {
			directory := privateRuntimeDirectory(t)
			command := exec.CommandContext(t.Context(), os.Args[0], "-test.run=^TestRuntimeRecoversRecordPublicationAfterProcessExit$")
			command.Env = append(os.Environ(), "STARMAP_TEST_RUNTIME_RECORD_EXIT="+directory, "STARMAP_TEST_RUNTIME_RECORD_KIND="+kind)
			output, err := command.CombinedOutput()
			if command.ProcessState == nil || command.ProcessState.ExitCode() != 88 {
				t.Fatalf("child exit: %v %s", err, output)
			}
			runtime := openTestRuntime(t, WithStateDirectory(directory), WithCatalogSource("embedded"), WithSourceRefreshMode("manual"))
			if !runtime.Status().Usable || runtime.Catalog() == nil {
				t.Fatal("recovery lost the embedded baseline")
			}
			for _, relative := range []string{layerDirectoryName, layerDirectoryName + "/providers", layerDirectoryName + "/providers/bindings", layerDirectoryName + "/publication-inputs"} {
				entries, err := os.ReadDir(filepath.Join(directory, relative))
				if os.IsNotExist(err) {
					continue
				}
				if err != nil {
					t.Fatal(err)
				}
				for _, entry := range entries {
					if strings.HasPrefix(entry.Name(), ".layer-") || strings.HasPrefix(entry.Name(), ".input-") {
						t.Errorf("startup retained abandoned record %s/%s", relative, entry.Name())
					}
				}
			}
		})
	}
}
