import json, subprocess
from pathlib import Path
source=Path('internal/catalog/workspace/replacement_identity_test.go').resolve()
support=Path('.tmp/csp5-update-controls/journal-backup-identity-probe/support').resolve()
support.mkdir(parents=True,exist_ok=True)
extra=r'''
func TestJournalRecoveryPreservesIdenticalBackupReplacement(t *testing.T) {
 f := interruptedReplacement(t, replacementMarkerSaved)
 var name string
 for _, entry := range f.record.Old.Entries {
  if !entry.Directory { name = entry.Path; break }
 }
 if name == "" { t.Fatal("fixture has no backup file") }
 path := filepath.Join(filepath.Dir(f.path), f.record.Backup, filepath.FromSlash(name))
 data, err := os.ReadFile(path)
 if err != nil { t.Fatal(err) }
 info, err := os.Stat(path)
 if err != nil { t.Fatal(err) }
 if err := os.Rename(path, filepath.Join(filepath.Dir(f.path), "operator-retained-original")); err != nil { t.Fatal(err) }
 if err := os.WriteFile(path, data, info.Mode().Perm()); err != nil { t.Fatal(err) }
 saved, err := os.Stat(path)
 if err != nil { t.Fatal(err) }
 _, recoveryErr := Repair(t.Context(), f.path, f.catalog, f.identity)
 after, err := os.Stat(path)
 if err != nil || !os.SameFile(saved, after) {
  t.Fatalf("recovery removed identical replacement backup file: recovery=%v, file=%v", recoveryErr, err)
 }
 assertReadConflict(t, recoveryErr)
}
'''
candidate=support/'backup_identity_test.go'
candidate.write_text(source.read_text()+extra)
overlay=support/'overlay.json'
overlay.write_text(json.dumps({'Replace':{str(source):str(candidate)}},indent=2)+'\n')
(support/'probe.py').write_bytes(Path(__file__).read_bytes())
command=['go','test','-overlay',str(overlay),'-json','-race','-count=1','-timeout','5m','./internal/catalog/workspace','-run','^TestJournalRecoveryPreservesIdenticalBackupReplacement$']
print(json.dumps({'probe_command':command}),flush=True)
raise SystemExit(subprocess.run(command).returncode)
