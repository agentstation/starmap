package workspace

import (
	"bytes"
	stderrors "errors"
	"os"
	"path/filepath"
	"testing"
)

func TestReplacementCompletionPreservesChangedJournal(t *testing.T) {
	for _, recovery := range []bool{false, true} {
		mode := map[bool]string{false: "publication", true: "recovery"}[recovery]
		for _, change := range []string{"identical-replacement", "equivalent-json", "access"} {
			t.Run(mode+"/"+change, func(t *testing.T) {
				target := filepath.Join(t.TempDir(), "workspace")
				old, oldIdentity := testCatalog(t, "old", "Old Model")
				if _, err := Project(t.Context(), target, old, oldIdentity); err != nil {
					t.Fatal(err)
				}
				catalog, identity := testCatalog(t, "new", "New Model")
				journal := replacementJournalPath(target)
				var saved os.FileInfo
				var want []byte
				changeJournal := func(phase replacementPhase) error {
					if phase != replacementBackupRemoved {
						return nil
					}
					data, err := os.ReadFile(journal)
					if err != nil {
						return err
					}
					info, err := os.Stat(journal)
					if err != nil {
						return err
					}
					switch change {
					case "identical-replacement":
						if err := os.Rename(journal, journal+".original"); err != nil {
							return err
						}
						if err := os.WriteFile(journal, data, info.Mode().Perm()); err != nil {
							return err
						}
					case "equivalent-json":
						data = append([]byte(" "), data...)
						if err := os.WriteFile(journal, data, info.Mode().Perm()); err != nil {
							return err
						}
					case "access":
						if err := os.Chmod(journal, 0444); err != nil {
							return err
						}
						t.Cleanup(func() { _ = os.Chmod(journal, fileMode) })
					}
					want = data
					saved, err = os.Stat(journal)
					return err
				}
				p := projector{journalReplacement: true, afterReplacementPhase: changeJournal}
				if recovery {
					fault := stderrors.New("stop before replacement")
					p.afterReplacementPhase = func(phase replacementPhase) error {
						if phase == replacementJournalSaved {
							return fault
						}
						return nil
					}
					if _, err := p.project(t.Context(), target, catalog, identity, InputExpectation{}); !stderrors.Is(err, fault) {
						t.Fatalf("prepare recovery: %v", err)
					}
					root, err := os.OpenRoot(filepath.Dir(target))
					if err != nil {
						t.Fatal(err)
					}
					defer func() { _ = root.Close() }()
					record, err := readReplacementRecord(root, target)
					if err != nil {
						t.Fatal(err)
					}
					_, err = advanceReplacement(t.Context(), root, record, replacementHooks{after: changeJournal})
					assertReadConflict(t, err)
				} else {
					_, err := p.project(t.Context(), target, catalog, identity, InputExpectation{})
					assertReadConflict(t, err)
				}
				if saved == nil {
					t.Fatal("journal change did not run")
				}
				actual, err := os.Stat(journal)
				if err != nil || !os.SameFile(saved, actual) || actual.Mode() != saved.Mode() {
					t.Fatalf("completion removed or changed the operator journal: %v", err)
				}
				data, err := os.ReadFile(journal)
				if err != nil || !bytes.Equal(data, want) {
					t.Fatalf("completion changed journal bytes: %v", err)
				}
				assertWorkspaceModel(t, target, "new", "New Model")
			})
		}
	}
}
