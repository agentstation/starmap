package main

import (
 "context"
 "encoding/json"
 "os"
 "path/filepath"

 "github.com/agentstation/starmap/pkg/catalogs/storage"
 "github.com/agentstation/starmap/pkg/errors"
)

func main() {
 parent,err:=os.MkdirTemp("","starmap-retention-empty-");if err!=nil{panic(err)}
 defer os.RemoveAll(parent)
 root:=filepath.Join(parent,"absent")
 absent,err:=storage.NewFilesystem(root);if err!=nil{panic(err)}
 _,release,readErr:=absent.AcquireGeneration(context.Background(),"missing")
 if release!=nil{_ = release()}
 empty,err:=storage.NewFilesystem(parent);if err!=nil{panic(err)}
 _,collectErr:=empty.Collect(context.Background(),storage.RetentionRequest{MaxGenerations:1,MaxBytes:1024})
 _=json.NewEncoder(os.Stdout).Encode(map[string]any{"missing_root_acquire_catalog_not_found":errors.IsNotFound(readErr),"missing_root_acquire_error":text(readErr),"empty_root_collect_error":text(collectErr)})
}
func text(err error)string{if err==nil{return ""};return err.Error()}
