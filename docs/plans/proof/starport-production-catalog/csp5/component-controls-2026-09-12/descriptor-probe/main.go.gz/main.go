package main

import (
	"encoding/json"
	"os"

	"github.com/agentstation/starmap/pkg/catalogs/config"
)

func main() {
	if err := json.NewEncoder(os.Stdout).Encode(config.Descriptors()); err != nil {
		panic(err)
	}
}
