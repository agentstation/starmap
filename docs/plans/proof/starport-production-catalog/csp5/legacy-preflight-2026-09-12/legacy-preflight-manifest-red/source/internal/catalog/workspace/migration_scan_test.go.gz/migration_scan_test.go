package workspace

import (
	stderrors "errors"
	"os"
	"path/filepath"
	"testing"

	"github.com/agentstation/starmap/pkg/catalogs/storage"
	pkgerrors "github.com/agentstation/starmap/pkg/errors"
)

func TestLegacyPreflightRejectsOversizedRetainedManifestBeforeParsing(t *testing.T) {
	root := t.TempDir()
	legacy := filepath.Join(root, "legacy")
	state := filepath.Join(root, "state", "catalog")
	store := migrationStore(t, legacy)
	retained := migrationGeneration(t, "retained", "old", "Old")
	current := migrationGeneration(t, "current", "new", "New")
	if err := store.Commit(t.Context(), retained, ""); err != nil {
		t.Fatal(err)
	}
	if err := store.Commit(t.Context(), current, retained.Manifest.GenerationID); err != nil {
		t.Fatal(err)
	}
	manifest := migrationManifestPath(legacy, retained.Manifest.GenerationID)
	if err := os.Truncate(manifest, storage.MaxFilesystemManifestBytes+1); err != nil {
		t.Fatal(err)
	}
	_, err := MigrateLegacyLayout(t.Context(), legacy, state)
	var validation *pkgerrors.ValidationError
	if !stderrors.As(err, &validation) || validation.Field != "private.file" {
		t.Fatalf("expected the bounded file reader to refuse the retained manifest, got %v", err)
	}
	info, statErr := os.Stat(manifest)
	if statErr != nil || info.Size() != storage.MaxFilesystemManifestBytes+1 {
		t.Fatalf("preflight changed the retained manifest: %v", statErr)
	}
	if _, err := os.Stat(filepath.Dir(state)); !stderrors.Is(err, os.ErrNotExist) {
		t.Fatalf("preflight created the target parent: %v", err)
	}
	got, err := store.Current(t.Context())
	if err != nil || !sameMigrationGeneration(current, got) {
		t.Fatalf("preflight changed current: %v", err)
	}
}
