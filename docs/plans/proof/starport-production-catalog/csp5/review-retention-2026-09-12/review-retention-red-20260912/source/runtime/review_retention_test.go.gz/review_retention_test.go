package runtime

import (
	"bytes"
	"encoding/json"
	"testing"
	"time"

	"github.com/agentstation/starmap"
	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/sources"
)

func providerReviewHistory(t *testing.T, count int, distinct bool) (*manualBatch, sources.Observation) {
	t.Helper()
	at := time.Date(2026, 9, 12, 0, 0, 0, 0, time.UTC)
	var history *manualBatch
	var latest sources.Observation
	for i := range count {
		limit := int64(200)
		if distinct {
			limit += int64(i)
		}
		latest = manualProviderObservation(t, limit, at.Add(time.Duration(i)*time.Minute))
		prepared, err := prepareManualObservations(t.Context(), []sources.Observation{latest})
		if err != nil {
			t.Fatal(err)
		}
		history = &manualBatch{parent: history, observations: prepared}
	}
	return history, latest
}

func unreviewedBaseline(t *testing.T) starmap.CatalogState {
	t.Helper()
	catalog, err := catalogs.NewEmpty().Build()
	if err != nil {
		t.Fatal(err)
	}
	return starmap.CatalogState{GenerationID: "unreviewed", Catalog: catalog, GeneratedAt: time.Date(2026, 9, 11, 0, 0, 0, 0, time.UTC)}
}

func TestProviderReviewHistorySelectsCurrentReceipt(t *testing.T) {
	history, latest := providerReviewHistory(t, 12, true)
	layers := layerSet{manual: history}
	state, err := layers.build(t.Context(), unreviewedBaseline(t))
	if err != nil {
		t.Fatal(err)
	}
	reviews := layers.buildEvidence.ReviewCandidates
	if len(reviews) != 1 || reviews[0].SourceObservationID != latest.ID || reviews[0].EvidenceChecksum != latest.EvidenceChecksum {
		t.Fatalf("current review set retained superseded observations: %+v", reviews)
	}
	if len(layers.buildEvidence.SourceObservations) != 1 || layers.buildEvidence.SourceObservations[0].ObservationID != latest.ID {
		t.Fatalf("obsolete reviews pinned old generation receipts: %+v", layers.buildEvidence.SourceObservations)
	}
	if _, err := state.Catalog.ProviderModel("provider", "model"); err == nil {
		t.Fatal("unreviewed model became routable")
	}
	if len(manualBatches(history)) != 12 {
		t.Fatal("review selection discarded durable source observations")
	}
}

func TestProviderReviewHistorySurvivesBaselineChangeAndCompaction(t *testing.T) {
	history, _ := providerReviewHistory(t, 12, false)
	compacted, err := compactRepeatedProviderHistory(t.Context(), history)
	if err != nil {
		t.Fatal(err)
	}
	if len(manualBatches(compacted)[0].observations) >= 12 {
		t.Fatal("fixture did not compact repeated observations")
	}
	for _, baseline := range []starmap.CatalogState{
		{GenerationID: "reviewed", Catalog: manualProviderObservation(t, 100, time.Date(2026, 9, 11, 0, 0, 0, 0, time.UTC)).Catalog},
		unreviewedBaseline(t),
	} {
		t.Run(baseline.GenerationID, func(t *testing.T) {
			full := layerSet{manual: history}
			before, err := full.build(t.Context(), baseline)
			if err != nil {
				t.Fatal(err)
			}
			reduced := layerSet{manual: compacted}
			after, err := reduced.build(t.Context(), baseline)
			if err != nil {
				t.Fatal(err)
			}
			beforeEvidence, err := json.Marshal(full.buildEvidence)
			if err != nil {
				t.Fatal(err)
			}
			afterEvidence, err := json.Marshal(reduced.buildEvidence)
			if err != nil {
				t.Fatal(err)
			}
			if before.PayloadChecksum != after.PayloadChecksum || !bytes.Equal(beforeEvidence, afterEvidence) {
				t.Fatalf("compaction changed replay after baseline selection: before=%s after=%s reviews=%d/%d", before.PayloadChecksum, after.PayloadChecksum, len(full.buildEvidence.ReviewCandidates), len(reduced.buildEvidence.ReviewCandidates))
			}
		})
	}
}
