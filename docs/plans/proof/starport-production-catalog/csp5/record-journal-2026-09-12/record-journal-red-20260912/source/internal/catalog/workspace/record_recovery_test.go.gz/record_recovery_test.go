package workspace

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

func TestWorkspaceRecordRecoveryAfterProcessExit(t *testing.T) {
	if target := os.Getenv("STARMAP_TEST_RECORD_EXIT"); target != "" {
		flow := os.Getenv("STARMAP_TEST_RECORD_FLOW")
		phase := os.Getenv("STARMAP_TEST_RECORD_PHASE")
		stop := func(name string) error {
			if selectedRecoveryRecord(name, flow) {
				os.Exit(87)
			}
			return nil
		}
		hooks := workspaceRecordWriter{}
		if phase == "prepared" {
			hooks.beforePublish = stop
		} else {
			hooks.afterPublish = stop
		}
		catalog, identity := testCatalog(t, "new", "New Model")
		_, err := (projector{journalReplacement: flow != "projection", recordWrites: hooks}).
			project(t.Context(), target, catalog, identity, InputExpectation{})
		t.Fatalf("child did not exit during record publication: %v", err)
	}
	for _, flow := range []string{"projection", "journal", "journal-marker"} {
		for _, phase := range []string{"prepared", "published"} {
			t.Run(flow+"/"+phase, func(t *testing.T) {
				target := filepath.Join(t.TempDir(), "workspace")
				crashWorkspaceRecord(t, target, flow, phase)
				catalog, identity := testCatalog(t, "new", "New Model")
				if _, err := Repair(t.Context(), target, catalog, identity); err != nil {
					t.Fatal(err)
				}
				assertWorkspaceModel(t, target, "new", "New Model")
				assertNoProjectionStaging(t, target)
				entries, err := os.ReadDir(filepath.Dir(target))
				if err != nil {
					t.Fatal(err)
				}
				for _, entry := range entries {
					if selectedRecoveryRecord(entry.Name(), flow) {
						t.Errorf("temporary publication record survived recovery: %s", entry.Name())
					}
				}
			})
		}
	}
}

func selectedRecoveryRecord(name, flow string) bool {
	if flow == "journal" {
		return strings.Contains(filepath.Base(name), ".starmap-replacement.json.")
	}
	return strings.Contains(filepath.Base(name), ".starmap-projection.json.")
}

func crashWorkspaceRecord(t *testing.T, target, flow, phase string) {
	t.Helper()
	if flow != "projection" {
		old, identity := testCatalog(t, "old", "Old Model")
		if _, err := Project(t.Context(), target, old, identity); err != nil {
			t.Fatal(err)
		}
	}
	command := exec.CommandContext(t.Context(), os.Args[0], "-test.run=^TestWorkspaceRecordRecoveryAfterProcessExit$")
	command.Env = append(os.Environ(), "STARMAP_TEST_RECORD_EXIT="+target, "STARMAP_TEST_RECORD_FLOW="+flow, "STARMAP_TEST_RECORD_PHASE="+phase)
	output, err := command.CombinedOutput()
	if command.ProcessState == nil || command.ProcessState.ExitCode() != 87 {
		t.Fatalf("child exit: %v, %s", err, output)
	}
}
