package runtime

import (
	"testing"
	"time"

	"github.com/agentstation/starmap"
	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/sources"
)

func TestManualHistoryCompactsRepeatedProviderInventoriesBeforeBatchLimit(t *testing.T) {
	at := time.Date(2026, 9, 12, 0, 0, 0, 0, time.UTC)
	missing := manualProviderObservation(t, 200, at)
	provider, err := missing.Catalog.Provider("provider")
	if err != nil {
		t.Fatal(err)
	}
	omitted := catalogs.DeepCopyModel(*provider.Models["model"])
	omitted.ID = "omitted"
	provider.Models["omitted"] = &omitted
	builder, err := catalogs.NewBuilderFrom(missing.Catalog)
	if err != nil {
		t.Fatal(err)
	}
	if err := builder.SetProvider(provider); err != nil {
		t.Fatal(err)
	}
	observed, err := catalogs.NewObservationCatalog(builder)
	if err != nil {
		t.Fatal(err)
	}
	missing, err = sources.NewObservation(sources.ProvidersID, observed, sources.ObservationMetadata{
		ObservedAt: at, Revision: sources.Revision{Kind: sources.RevisionKindContentDigest},
		Completeness: sources.ObservationCompletenessComplete, Status: sources.ObservationStatusSucceeded,
	})
	if err != nil {
		t.Fatal(err)
	}
	prepared, err := prepareManualObservations(t.Context(), []sources.Observation{missing})
	if err != nil {
		t.Fatal(err)
	}
	history := &manualBatch{observations: prepared}
	var latest sources.Observation
	for i := 1; i < maxManualHistoryBatches; i++ {
		latest = manualProviderObservation(t, 300, at.Add(time.Duration(i)*time.Minute))
		input, err := prepareManualObservations(t.Context(), []sources.Observation{latest})
		if err != nil {
			t.Fatal(err)
		}
		history = &manualBatch{parent: history, observations: input}
	}
	incoming := manualProviderObservation(t, 400, at.Add(time.Duration(maxManualHistoryBatches)*time.Minute))
	input, err := prepareManualObservations(t.Context(), []sources.Observation{incoming})
	if err != nil {
		t.Fatal(err)
	}
	baseline := starmap.CatalogState{GenerationID: "baseline", Catalog: manualProviderObservation(t, 100, at).Catalog, GeneratedAt: at.Add(-time.Minute)}
	layers := layerSet{manual: history, embedded: baseline}
	selected, err := layers.prepareManualInputs(t.Context(), input, nil, nil)
	if err != nil {
		t.Fatalf("repeated inventories blocked the next acquisition: %v", err)
	}
	layers.manual = &manualBatch{parent: layers.manual, observations: selected}
	if count := len(manualBatches(layers.manual)); count >= maxManualHistoryBatches {
		t.Fatalf("compaction retained %d batches", count)
	}
	before, err := layers.build(t.Context(), baseline)
	if err != nil {
		t.Fatal(err)
	}
	provider, err = before.Catalog.Provider("provider")
	if err != nil || provider.Models["omitted"] == nil || provider.Models["model"].Limits.ContextWindow != 400 {
		t.Fatalf("compaction lost current or omitted provider records: %v", err)
	}
	if len(manualBatches(history)) != maxManualHistoryBatches {
		t.Fatal("compaction changed the accepted history in place")
	}
	store, err := newLayerStore(privateRuntimeDirectory(t))
	if err != nil {
		t.Fatal(err)
	}
	reference, err := store.stageManualBatch(t.Context(), layers.manual)
	if err != nil {
		t.Fatal(err)
	}
	if err := store.saveManualHead(t.Context(), reference); err != nil {
		t.Fatal(err)
	}
	restored, err := store.loadManualHistory(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	restarted := layerSet{manual: restored, embedded: baseline}
	after, err := restarted.build(t.Context(), baseline)
	if err != nil || before.GenerationID != after.GenerationID || before.PayloadChecksum != after.PayloadChecksum {
		t.Fatalf("restart changed the compacted catalog: %v", err)
	}
	found := false
	for _, batch := range manualBatches(restored) {
		for _, retained := range batch.observations {
			if retained.Receipt.Link.ObservationID != missing.ID {
				continue
			}
			original, err := retained.restore()
			if err != nil || original.EvidenceChecksum != missing.EvidenceChecksum {
				t.Fatalf("compaction rewrote the omitted model receipt: %v", err)
			}
			found = true
		}
	}
	if !found {
		t.Fatal("compaction discarded the omitted model's original observation")
	}
}
