package privatefiles

import (
	"os"
	"os/exec"
	"path/filepath"
	"strings"
	"testing"
)

func TestPrivateRecordRecoveryAfterProcessExit(t *testing.T) {
	if path := os.Getenv("STARMAP_TEST_PRIVATE_RECORD_EXIT"); path != "" {
		directory, err := ExistingDirectory(path)
		if err != nil {
			t.Fatal(err)
		}
		phase := os.Getenv("STARMAP_TEST_PRIVATE_RECORD_PHASE")
		var syncDirectory func(*os.Root) error
		if phase == "prepared" {
			directory.beforePublish = func(string) error { os.Exit(88); return nil }
		} else {
			syncDirectory = func(*os.Root) error { os.Exit(88); return nil }
		}
		err = directory.publishFileContext(t.Context(), "source.json", []byte("candidate"), ".layer-", syncDirectory)
		t.Fatalf("child did not exit: %v", err)
	}
	for _, phase := range []string{"prepared", "published"} {
		t.Run(phase, func(t *testing.T) {
			path := filepath.Join(t.TempDir(), "records")
			directory, err := NewDirectory(path)
			if err != nil {
				t.Fatal(err)
			}
			if err := directory.WriteFile("source.json", []byte("retained"), ".layer-"); err != nil {
				t.Fatal(err)
			}
			command := exec.CommandContext(t.Context(), os.Args[0], "-test.run=^TestPrivateRecordRecoveryAfterProcessExit$")
			command.Env = append(os.Environ(), "STARMAP_TEST_PRIVATE_RECORD_EXIT="+path, "STARMAP_TEST_PRIVATE_RECORD_PHASE="+phase)
			output, err := command.CombinedOutput()
			if command.ProcessState == nil || command.ProcessState.ExitCode() != 88 {
				t.Fatalf("child exit: %v, %s", err, output)
			}
			reopened, err := ExistingDirectory(path)
			if err != nil {
				t.Fatal(err)
			}
			if err := reopened.RecoverPublications(t.Context()); err != nil {
				t.Fatal(err)
			}
			want := "retained"
			if phase == "published" {
				want = "candidate"
			}
			data, err := reopened.ReadFile("source.json", 128)
			if err != nil || string(data) != want {
				t.Fatalf("recovery changed accepted bytes: %q, %v", data, err)
			}
			entries, err := os.ReadDir(path)
			if err != nil {
				t.Fatal(err)
			}
			for _, entry := range entries {
				if strings.HasPrefix(entry.Name(), ".layer-") {
					t.Fatalf("recovery retained abandoned file %s", entry.Name())
				}
			}
		})
	}
}
