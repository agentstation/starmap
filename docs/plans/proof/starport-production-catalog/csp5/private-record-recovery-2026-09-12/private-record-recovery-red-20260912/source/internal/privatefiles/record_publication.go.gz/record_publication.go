package privatefiles

import (
	"context"
	"os"
)

// PublishFileContext publishes a private record with durable staging ownership.
// Recovery never treats an unrecorded temporary filename as proof of ownership.
func (d *Directory) PublishFileContext(ctx context.Context, name string, data []byte, prefix string) error {
	return d.publishFileContext(ctx, name, data, prefix, nil)
}

func (d *Directory) publishFileContext(ctx context.Context, name string, data []byte, prefix string, syncDirectory func(*os.Root) error) error {
	return d.WriteFileContextWithSync(ctx, name, data, prefix, syncDirectory)
}

// RecoverPublications removes unchanged staging records under an exclusive writer lock.
// It preserves unknown files and incomplete receipts.
func (d *Directory) RecoverPublications(ctx context.Context) error {
	return ctx.Err()
}
