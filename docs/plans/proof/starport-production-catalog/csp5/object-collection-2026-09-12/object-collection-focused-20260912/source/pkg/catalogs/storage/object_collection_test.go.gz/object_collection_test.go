package storage

import (
	"testing"

	"github.com/agentstation/starmap/pkg/errors"
)

func TestMemoryObjectCollectionPages(t *testing.T) {
	backend := NewMemoryObjectBackend()
	for _, key := range []string{"catalog/a", "catalog/b", "catalog/c", "other/a"} {
		if _, err := backend.Put(t.Context(), key, []byte(key), ObjectPutCondition{IfAbsent: true}); err != nil {
			t.Fatal(err)
		}
	}
	collection, ok := any(backend).(ObjectCollectionBackend)
	if !ok {
		t.Fatal("memory object backend cannot enumerate retained catalog objects")
	}
	page, err := collection.List(t.Context(), ObjectListRequest{Prefix: "catalog/", Limit: 2})
	if err != nil || len(page.Objects) != 2 || page.Next == "" {
		t.Fatalf("first page = %+v, %v", page, err)
	}
	if page.Objects[0].Key != "catalog/a" || page.Objects[1].Key != "catalog/b" {
		t.Fatalf("first page keys = %+v", page.Objects)
	}
	for _, entry := range page.Objects {
		value, err := backend.Get(t.Context(), entry.Key)
		if err != nil || entry.Version != value.Version || entry.Size != int64(len(value.Data)) {
			t.Fatalf("entry = %+v, value = %+v, error = %v", entry, value, err)
		}
	}
	page, err = collection.List(t.Context(), ObjectListRequest{Prefix: "catalog/", Cursor: page.Next, Limit: 2})
	if err != nil || len(page.Objects) != 1 || page.Objects[0].Key != "catalog/c" || page.Next != "" {
		t.Fatalf("last page = %+v, %v", page, err)
	}
}

func TestMemoryObjectCollectionConditionalDelete(t *testing.T) {
	backend := NewMemoryObjectBackend()
	original, err := backend.Put(t.Context(), "catalog/a", []byte("old"), ObjectPutCondition{IfAbsent: true})
	if err != nil {
		t.Fatal(err)
	}
	current, err := backend.Put(t.Context(), "catalog/a", []byte("new"), ObjectPutCondition{IfVersion: original.Version})
	if err != nil {
		t.Fatal(err)
	}
	collection, ok := any(backend).(ObjectCollectionBackend)
	if !ok {
		t.Fatal("memory object backend cannot conditionally delete a retained object")
	}
	if err := collection.Delete(t.Context(), "catalog/a", original.Version); !isConflict(err) {
		t.Fatalf("stale delete = %v", err)
	}
	value, err := backend.Get(t.Context(), "catalog/a")
	if err != nil || string(value.Data) != "new" {
		t.Fatalf("replacement = %+v, %v", value, err)
	}
	if err := collection.Delete(t.Context(), "catalog/a", current.Version); err != nil {
		t.Fatal(err)
	}
	if _, err := backend.Get(t.Context(), "catalog/a"); !errors.IsNotFound(err) {
		t.Fatalf("deleted object = %v", err)
	}
}
