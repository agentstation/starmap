package s3

import (
	"testing"

	"github.com/agentstation/starmap/pkg/catalogs/storage"
)

func TestBackendObjectCollectionCapability(t *testing.T) {
	backend, _ := newTestBackend(t, newProtocolServer())
	if _, ok := any(backend).(storage.ObjectCollectionBackend); !ok {
		t.Fatal("S3 backend cannot enumerate or conditionally delete retained catalog objects")
	}
}
