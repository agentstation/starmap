package remote

import (
	"fmt"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"sync/atomic"
	"testing"
	"time"

	"github.com/agentstation/starmap"
	protocol "github.com/agentstation/starmap/pkg/catalogs/remote"
	"github.com/agentstation/starmap/pkg/catalogs/storage"
	"github.com/agentstation/starmap/runtime"
)

func TestManualRuntimeRefreshNeverOpensStream(t *testing.T) {
	generation := subscriberTestGeneration(t, "manual-source", "manual-provider", time.Date(2026, 9, 11, 20, 0, 0, 0, time.UTC))
	var streams atomic.Int64
	var manifests atomic.Int64
	server := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		switch r.URL.Path {
		case "/api/v1" + protocol.ManifestPath:
			manifests.Add(1)
			writeSubscriberManifest(t, w, generation)
		case "/api/v1" + protocol.PayloadPath(generation.Manifest.GenerationID):
			_, _ = w.Write(generation.Payload)
		case "/api/v1" + protocol.SourceChainPath:
			writeSourceTestChain(t, w, generation)
		case "/api/v1" + protocol.EventStreamPath:
			streams.Add(1)
			w.Header().Set("Content-Type", protocol.EventStreamMediaType)
			_, _ = fmt.Fprint(w, ": connected\n\n")
			w.(http.Flusher).Flush()
			<-r.Context().Done()
		default:
			http.NotFound(w, r)
		}
	}))
	t.Cleanup(server.Close)
	source, err := NewSource(t.Context(), SourceConfig{Subscriber: Config{
		BaseURL: server.URL + "/api/v1", HTTPClient: server.Client(), CatalogStore: storage.NewMemory(),
	}})
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = source.Close() })
	connected, err := runtime.Open(t.Context(),
		runtime.WithClientOptions(starmap.WithCatalogStore(storage.NewMemory())),
		runtime.WithStateDirectory(filepath.Join(t.TempDir(), "runtime")),
		runtime.WithSource(source),
		runtime.WithSourceRefreshMode("manual"),
	)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(func() { _ = connected.Close() })
	if manifests.Load() != 0 {
		t.Fatal("manual runtime fetched the source during construction")
	}
	for range 2 {
		if _, err := connected.RefreshSource(t.Context()); err != nil {
			t.Fatal(err)
		}
	}
	if got := streams.Load(); got != 0 {
		t.Fatalf("manual refresh opened %d event streams", got)
	}
	if got := manifests.Load(); got != 2 {
		t.Fatalf("two manual refreshes fetched %d manifests, want two", got)
	}
}
