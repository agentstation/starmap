Catalog permission checks need bounded UTC evidence without time-service calls on the request path. This change adds optional native clock adapters for Linux, macOS, and Windows. Constructors start no background work. Windows requires explicit bounds for synchronization age, drift, and source uncertainty. Application scheduling and production qualification remain separate work.

Windows verifies the running time service and its local pipe before requesting the service principal. SSPI uses the process identity with packet privacy and identification-only access. Authentication failure never triggers an unauthenticated status fallback. The RPC transport retains its fixed pipe, reply limits, and two-second deadline. One native worker bounds calls that outlive cancellation. Host authentication policy can require domain services.

Native tests cover encryption, changed headers, changed payloads, changed signatures, replay, and handle cleanup. The CI fixture starts the existing time service on disposable runners and retains local status and privilege diagnostics. Product code starts no service, enables no privilege, and changes no clock setting.

The full repository verifier passed all 41 stages before the authentication change. The diagnostic candidate passes 194 permission race events per supported Go toolchain, four Windows cross-builds, Windows lint/vet, ago, and 1,497-file prose. Both Windows architectures pass native SSPI encryption, tampering, replay, and cleanup tests at the preceding authentication commit.

Both native W32Time reads still fail at the principal check. The current increment distinguishes RPC status, missing reply, empty name, and excessive name without printing the principal. It preserves every rejection condition. Native CI must resolve this failure before merge.

Sol reports zero findings. Opus flags the known native failure as a merge blocker and recommends allowing the fixture to skip. The merge blocker remains in force. The mandatory fixture remains enabled, and this diagnostic increment runs only in the unmerged task branch. The secret scan passes. Fresh review and passing native checks remain required before merge.

Production clock bounds and service-account privileges remain unqualified.
