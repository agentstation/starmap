autoreview panel findings: 1
[P0] Windows CI is knowingly red: fixture flag turns TestWindowsLocalTimeService into a hard failure
.github/workflows/pr.yaml:232
Reviewer: claude model=opus thinking=high

This change does two things together that make the shared PR workflow fail on every Windows job:

1. `.github/workflows/pr.yaml:243` adds `./pkg/catalogs/permission/...` to `native_packages`, so the new W32Time tests now run in the native job on all runners.
2. `.github/workflows/pr.yaml:232` exports `STARMAP_WINDOWS_CLOCK_FIXTURE_REQUIRED=1`, which flips `TestWindowsLocalTimeService` (`pkg/catalogs/permission/hostclock/internal/w32timerpc/pipe_windows_test.go`) from `t.Skipf` to `t.Fatalf` whenever `ObserveStatus` returns an error.

The supplied review dataset states this error path is still taken: `known_limits` records "Both Windows jobs fail TestWindowsLocalTimeService" and "The actual returned principal status and name category remain unknown until the diagnostic candidate runs," and `manual_review.result` says this follow-up "splits diagnostics only and preserves every rejection condition" — i.e. the real service read still fails at principal validation (`security_windows.go:validateLocalPrincipal`). `verification.candidate` lists only cross-builds, lint/vet and unit runs; no native Windows job is reported green.

So merging this to `main` makes both windows/amd64 and windows/arm64 native jobs fail for every subsequent PR, with no workaround short of reverting or disabling the step. That is a landing blocker even though the underlying diagnostic work is deliberate.

Smallest landable fix: keep the fixture-preparation step and the evidence artifacts, but do not set `STARMAP_WINDOWS_CLOCK_FIXTURE_REQUIRED=1` (leave the test skipping while still logging the status) until a native run confirms `ObserveStatus` succeeds. Gate the required flag behind an opt-in input/label if the failing run is intentionally wanted for diagnosis, so it does not become the default for all PRs.

overall: patch is incorrect (0.98)
Panel review complete. claude model=opus thinking=high: 1 finding(s), codex model=gpt-5.6-sol thinking=xhigh: 0 finding(s).
