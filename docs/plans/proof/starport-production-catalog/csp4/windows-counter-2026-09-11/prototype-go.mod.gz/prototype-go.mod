module starmap-windows-clock-prototype

go 1.25.0

require github.com/oiweiwei/go-msrpc v1.5.4

require (
	github.com/Microsoft/go-winio v0.6.2 // indirect
	github.com/geoffgarside/ber v1.1.0 // indirect
	github.com/hashicorp/go-uuid v1.0.3 // indirect
	github.com/indece-official/go-ebcdic v1.2.0 // indirect
	github.com/jcmturner/aescts/v2 v2.0.0 // indirect
	github.com/jcmturner/dnsutils/v2 v2.0.0 // indirect
	github.com/jcmturner/gofork v1.7.6 // indirect
	github.com/jcmturner/goidentity/v6 v6.0.1 // indirect
	github.com/jcmturner/gokrb5/v8 v8.4.4 // indirect
	github.com/jcmturner/rpc/v2 v2.0.3 // indirect
	github.com/mattn/go-colorable v0.1.14 // indirect
	github.com/mattn/go-isatty v0.0.20 // indirect
	github.com/oiweiwei/go-math v1.0.0 // indirect
	github.com/oiweiwei/go-oem v1.0.0 // indirect
	github.com/oiweiwei/go-smb2.fork v1.0.2 // indirect
	github.com/oiweiwei/gokrb5.fork/v9 v9.0.7 // indirect
	github.com/rs/zerolog v1.35.1 // indirect
	golang.org/x/crypto v0.55.0 // indirect
	golang.org/x/net v0.58.0 // indirect
	golang.org/x/sys v0.47.0 // indirect
	golang.org/x/text v0.41.0 // indirect
)
