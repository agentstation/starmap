package clockprobe

import (
	"context"
	"errors"
	"net"
	"time"

	"github.com/Microsoft/go-winio"
	"github.com/oiweiwei/go-msrpc/msrpc/w32t"
	"golang.org/x/sys/windows"
	"golang.org/x/sys/windows/svc"
	"golang.org/x/sys/windows/svc/mgr"
)

// ObserveStatus is an unqualified prototype. It reads only the local W32Time service.
func ObserveStatus(ctx context.Context) (*w32t.StatusInfo, error) {
	ctx, cancel := context.WithTimeout(ctx, 2*time.Second)
	defer cancel()
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	manager, err := windows.OpenSCManager(nil, nil, windows.SC_MANAGER_CONNECT)
	if err != nil {
		return nil, err
	}
	defer windows.CloseServiceHandle(manager)
	name, err := windows.UTF16PtrFromString("W32Time")
	if err != nil {
		return nil, err
	}
	handle, err := windows.OpenService(manager, name, windows.SERVICE_QUERY_STATUS)
	if err != nil {
		return nil, err
	}
	service := &mgr.Service{Name: "W32Time", Handle: handle}
	defer service.Close()
	before, err := service.Query()
	if err != nil {
		return nil, err
	}
	if before.State != svc.Running || before.ProcessId == 0 {
		return nil, errors.New("W32Time is not running")
	}
	process, err := windows.OpenProcess(windows.SYNCHRONIZE, false, before.ProcessId)
	if err != nil {
		return nil, err
	}
	defer windows.CloseHandle(process)
	pipe, err := winio.DialPipeContext(ctx, `\\.\pipe\W32TIME`)
	if err != nil {
		return nil, err
	}
	defer pipe.Close()
	if err := checkPipeProcess(pipe, before.ProcessId); err != nil {
		return nil, err
	}
	status, err := query(ctx, pipe)
	if err != nil {
		return nil, err
	}
	after, err := service.Query()
	if err != nil {
		return nil, err
	}
	if after.State != svc.Running || after.ProcessId != before.ProcessId {
		return nil, errors.New("W32Time process changed")
	}
	wait, err := windows.WaitForSingleObject(process, 0)
	if err != nil {
		return nil, err
	}
	if wait != uint32(windows.WAIT_TIMEOUT) {
		return nil, errors.New("W32Time process stopped")
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	return status, nil
}

func checkPipeProcess(pipe net.Conn, expected uint32) error {
	fd, ok := pipe.(interface{ Fd() uintptr })
	if !ok {
		return errors.New("pipe does not expose its handle")
	}
	var actual uint32
	if err := windows.GetNamedPipeServerProcessId(windows.Handle(fd.Fd()), &actual); err != nil {
		return err
	}
	if actual == 0 || actual != expected {
		return errors.New("pipe is not owned by W32Time")
	}
	return nil
}
