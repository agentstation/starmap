package clockprobe

import (
	"context"
	"errors"
	"net"
	"sync/atomic"
	"time"

	"github.com/oiweiwei/go-msrpc/dcerpc"
	"github.com/oiweiwei/go-msrpc/msrpc/w32t"
	w32time "github.com/oiweiwei/go-msrpc/msrpc/w32t/w32time/v4"
)

const streamBinding = "ncacn_ip_tcp:127.0.0.1[1]"

type fixedStream struct {
	conn net.Conn
	used atomic.Bool
}

func (s *fixedStream) DialContext(ctx context.Context, network, address string) (net.Conn, error) {
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	if network != "tcp" || address != "127.0.0.1:1" || !s.used.CompareAndSwap(false, true) {
		return nil, errors.New("refused another transport")
	}
	return s.conn, nil
}

type noDNS struct{}

func (noDNS) LookupIPAddr(context.Context, string) ([]net.IPAddr, error) {
	return nil, errors.New("DNS is prohibited")
}

// query owns an already-connected stream. Only the generated QueryStatus method is used.
func query(ctx context.Context, raw net.Conn) (*w32t.StatusInfo, error) {
	defer raw.Close()
	ctx, cancel := context.WithTimeout(ctx, 2*time.Second)
	defer cancel()
	stop := context.AfterFunc(ctx, func() { _ = raw.Close() })
	defer stop()
	deadline, _ := ctx.Deadline()
	if err := raw.SetDeadline(deadline); err != nil {
		return nil, err
	}
	stream := &boundedStream{Conn: raw, deadline: deadline}
	conn, err := dcerpc.Dial(ctx, streamBinding, dcerpc.WithDialer(&fixedStream{conn: stream}), dcerpc.WithDNSResolver(noDNS{}), dcerpc.WithTimeout(2*time.Second), dcerpc.WithInsecure())
	if err != nil {
		return nil, err
	}
	defer conn.Close(context.Background())
	client, err := w32time.NewW32TimeClient(ctx, conn, dcerpc.WithInsecure())
	if err != nil {
		return nil, err
	}
	response, err := client.QueryStatus(ctx, &w32time.QueryStatusRequest{})
	if err != nil {
		return nil, err
	}
	if response == nil || response.StatusInfo == nil {
		return nil, errors.New("missing status")
	}
	return response.StatusInfo, nil
}
