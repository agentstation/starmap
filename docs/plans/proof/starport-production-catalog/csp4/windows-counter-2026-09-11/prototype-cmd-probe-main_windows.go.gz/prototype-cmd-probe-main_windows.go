package main

import (
	"context"
	"encoding/json"
	"fmt"
	"os"

	clockprobe "starmap-windows-clock-prototype"
)

func main() {
	status, err := clockprobe.ObserveStatus(context.Background())
	if err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
	// Omit the source address; the prototype records only clock evidence.
	status.Source = ""
	status.Entries = nil
	if err := json.NewEncoder(os.Stdout).Encode(status); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
