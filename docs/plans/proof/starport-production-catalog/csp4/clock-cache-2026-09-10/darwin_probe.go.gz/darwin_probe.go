package main

import (
	"encoding/json"
	"fmt"
	"os"
	"runtime"
	"testing"
	"time"
	"unsafe"

	"github.com/ebitengine/purego"
	"golang.org/x/sys/unix"
)

type ntpTime struct {
	Seconds, Nanoseconds, MaxError, EstError, TAI int64
	State                                         int32
	Padding                                       int32
}
type timebase struct{ Numerator, Denominator uint32 }

func run() error {
	library, err := purego.Dlopen("/usr/lib/libSystem.B.dylib", purego.RTLD_NOW|purego.RTLD_LOCAL)
	if err != nil {
		return err
	}
	defer func() { _ = purego.Dlclose(library) }()
	names := []string{"ntp_gettime", "mach_continuous_time", "mach_timebase_info"}
	symbols := make([]uintptr, len(names))
	for i, name := range names {
		symbols[i], err = purego.Dlsym(library, name)
		if err != nil {
			return err
		}
	}
	var getTime func(*ntpTime) int32
	var continuous func() uint64
	var scale func(*timebase) int32
	purego.RegisterFunc(&getTime, symbols[0])
	purego.RegisterFunc(&continuous, symbols[1])
	purego.RegisterFunc(&scale, symbols[2])
	var sample ntpTime
	var base timebase
	before := time.Now()
	status := getTime(&sample)
	after := time.Now()
	scaleStatus := scale(&base)
	var sink uint64
	typed := testing.Benchmark(func(b *testing.B) {
		for b.Loop() {
			sink = continuous()
		}
	})
	raw := testing.Benchmark(func(b *testing.B) {
		for b.Loop() {
			value, _, _ := purego.SyscallN(symbols[1])
			sink = uint64(value)
		}
	})
	var stamp unix.Timespec
	if err := unix.ClockGettime(unix.CLOCK_MONOTONIC_RAW, &stamp); err != nil {
		return err
	}
	unixCall := testing.Benchmark(func(b *testing.B) {
		for b.Loop() {
			_ = unix.ClockGettime(unix.CLOCK_MONOTONIC_RAW, &stamp)
		}
	})
	runtime.KeepAlive(sink)
	return json.NewEncoder(os.Stdout).Encode(map[string]any{
		"qualification": "read-only binding observation, not production clock qualification",
		"go":            runtime.Version(), "os": runtime.GOOS, "arch": runtime.GOARCH,
		"ntp_structure_bytes": unsafe.Sizeof(sample), "status": status,
		"sample": sample, "before": before.UTC(), "after": after.UTC(),
		"timebase_status": scaleStatus, "timebase": base,
		"registered_call":    map[string]any{"iterations": typed.N, "ns_per_op": typed.NsPerOp(), "allocs_per_op": typed.AllocsPerOp(), "bytes_per_op": typed.AllocedBytesPerOp()},
		"unix_clock_gettime": map[string]any{"iterations": unixCall.N, "ns_per_op": unixCall.NsPerOp(), "allocs_per_op": unixCall.AllocsPerOp(), "bytes_per_op": unixCall.AllocedBytesPerOp()},
		"syscall_n":          map[string]any{"iterations": raw.N, "ns_per_op": raw.NsPerOp(), "allocs_per_op": raw.AllocsPerOp(), "bytes_per_op": raw.AllocedBytesPerOp()},
	})
}

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, err)
		os.Exit(1)
	}
}
