Authority servers need a current permission head even when their serving catalog cannot activate the latest publication. This change adds independent authority records and a passive receipt issuer that reads the selected durable head.

The authority publisher enforces fixed identity, monotonic sequence, immutable retries, and compare-and-swap. Generation preparation derives permission revisions from the complete permitted catalog and retains canonical aliases until explicit operator or baseline removal.

The runtime origin option prepares the final authority identity before journal staging. Activation and explicit bootstrap pass through the client publication guard. Tests cover ambiguous commits, restart, rejected updates, and unchanged rebuilds.

The caller supplies qualified clock evidence and authorizes the origin. Standalone server configuration, native clock adapters, shared followers, and Starport consumer qualification remain CSP4 work. Origin startup currently requires the publication lease.

Validation:

- Origin runtime race tests pass on Go 1.26.6 and Go 1.25.12. Each run passes seven cases.
- Final ordinary transaction regression passes with the race detector: 36 test events.
- Root and permission package race tests pass: 112 and 90 test events.
- Full `make verify` passes: 82 packages in both test modes, 15 coverage thresholds, container smoke, documentation, prose, and offline CLI checks.
- Catalog pointer reads: 8.100–11.43 ns/op, zero bytes, and zero allocations across three runs.
- Required pre-PR review passes with Sol and Opus. Both report zero findings. The changed-content secret scan is clean.
- Native CI qualification: PENDING.

CSP4 remains in progress. Its eight product acceptance checks remain UNVERIFIED.
