package runtime

import (
	"errors"
	"testing"
	"time"

	"github.com/agentstation/starmap"
	"github.com/agentstation/starmap/pkg/catalogs/storage"
)

func TestCSP4BaselineWarmRetainedStartup(t *testing.T) {
	store, err := storage.NewFilesystem(privateRuntimeDirectory(t))
	if err != nil {
		t.Fatal(err)
	}
	source := newStubSource("internal-authority")
	payload := testCatalogPayload(t, "internal-provider", "retained-model", "Retained Model")
	source.replies = []SourceRead{testSourceRead(t, "accepted-internal", payload, time.Now().UTC())}
	options := []Option{
		WithStateDirectory(privateRuntimeDirectory(t)),
		WithClientOptions(starmap.WithCatalogStore(store)),
		WithSource(source), WithSourceStartupPolicy("require_source"),
		WithSourcePollInterval(0), WithStartupSpread(0), WithAcquisitionEnabled(false),
		WithRefreshTimeout(100 * time.Millisecond), WithRandom(func() float64 { return 0 }),
	}
	active, err := Open(t.Context(), options...)
	if err != nil {
		t.Fatal(err)
	}
	accepted := active.State()
	if _, err := active.Catalog().Provider("internal-provider"); err != nil {
		t.Fatal(err)
	}
	if err := active.Close(); err != nil {
		t.Fatal(err)
	}
	source.mu.Lock()
	source.errs = []error{errors.New("internal source is offline")}
	source.mu.Unlock()
	reopened, err := Open(t.Context(), options...)
	if err != nil {
		t.Fatalf("existing policy cannot retain offline startup after accepted generation %s: %v", accepted.GenerationID, err)
	}
	defer reopened.Close()
	if reopened.State().GenerationID != accepted.GenerationID {
		t.Fatal("warm startup replaced the accepted generation")
	}
}

func TestCSP4BaselineColdLeaseFollower(t *testing.T) {
	leases := &stubLeaseStore{}
	leases.refuseEvery()
	source := newStubSource("internal-authority")
	source.errs = []error{errors.New("internal source is offline")}
	active, err := Open(t.Context(),
		WithStateDirectory(privateRuntimeDirectory(t)), WithSource(source), WithLeaseStore(leases),
		WithSourceStartupPolicy("require_source"), WithSourcePollInterval(0),
		WithStartupSpread(0), WithAcquisitionEnabled(false), WithRandom(func() float64 { return 0 }),
	)
	if err != nil {
		t.Fatal(err)
	}
	defer active.Close()
	if source.readCount() != 0 {
		t.Fatal("lease follower unexpectedly read the source")
	}
	if active.Status().Usable {
		t.Fatal("lease follower reports usable state without an accepted internal catalog")
	}
}
