Starport must retain catalog authority metadata and enforce the current permission when it admits inference. This change preserves that metadata through accepted catalog storage and snapshots, and orders authority updates by publication sequence.

Request admission checks the connected runtime before route selection, each provider attempt, and cached response delivery. Cached streams check permission before their first read. Unknown or expired permission returns a retryable gateway error while retained catalog metadata remains available for diagnostics.

Canonical Starport settings select the authority identity and native permission clock. Starport names take precedence over Starmap aliases within each configuration source. The connected runtime owns clock startup and shutdown.

Development sessions let Starmap create missing catalog state directories with its native ownership and access rules. Startup tests synchronize with background authority polling and cover unavailable and pending responses.

This change pins reviewed Starmap revision `6419ea856cf5`, which runtime PR agentstation/starmap#152 retains. That PR must merge before this one. Full fleet recovery and released-pair qualification remain separate plan work.

Validation: all 33 required repository commands pass with the published Starmap module and `GOWORK=off`. This includes the Go suite, vet, lint, build, first-run check, and all SDK smoke checks.

The pair passes all eight CSP4 subcases with 56 race-test events and no failures or skips. The startup cases pass 100 repetitions with 300 test events. Development and authority cases pass ten repetitions with 180 events. Independent pre-PR reviews report zero findings, and the secret scan passes.
