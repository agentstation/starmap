import datetime, json, os, re, shlex, socket, subprocess
from pathlib import Path
root=Path.cwd()
out=root/'.tmp/csp4-starport-main'
now=lambda: datetime.datetime.now(datetime.timezone.utc).isoformat()
git=lambda *args: subprocess.check_output(['git',*args],text=True).strip()
assert not git('status','--porcelain'), 'Commit the dependency before final checks'
env=os.environ.copy();env.update(GOWORK='off',GOTOOLCHAIN='go1.26.6')
env['PATH']=str(Path.home()/'go/bin')+os.pathsep+env['PATH']
module=json.loads(subprocess.check_output(['go','list','-m','-json','github.com/agentstation/starmap'],env=env,text=True))
assert not module.get('Replace'), 'Published dependency required'
assert module['Version'] != 'v0.16.6-0.20260911063726-852a548c4959', 'The old pin lacks the clock API'
for name in ('CATALOG_DRIVEN_STARMAP_ROOT','STARMAP_OWNERSHIP_STARMAP_ROOT'):env[name]=module['Dir']
for name in ('CSP_STARPORT_WORKTREE','CATALOG_DISTRIBUTION_STARPORT_ROOT'):env[name]=str(root)
with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
env['STARPORT_SMOKE_PORT']=str(port)
section=(root/'AGENTS.md').read_text().split('Before a pull request, run:',1)[1]
block=re.search(r'```bash\n(.*?)```',section,re.S).group(1)
commands=[shlex.split(line) for line in block.splitlines() if line.strip()]
assert len(commands)==33, len(commands)
benchmark=['bash','scripts/benchmark-overhead.sh'];commands.remove(benchmark);commands.insert(0,benchmark)
record={'source_commit':git('rev-parse','HEAD'),'source_tree':git('rev-parse','HEAD^{tree}'),'starmap_module':module,'started_at':now(),'status':'running','environment_overrides':{key:env[key] for key in ('GOWORK','GOTOOLCHAIN','CATALOG_DRIVEN_STARMAP_ROOT','STARMAP_OWNERSHIP_STARMAP_ROOT','CSP_STARPORT_WORKTREE','CATALOG_DISTRIBUTION_STARPORT_ROOT','STARPORT_SMOKE_PORT')},'checks':[]}
save=lambda:(out/'verification.json').write_text(json.dumps(record,indent=2)+'\n')
save()
for index,command in enumerate(commands,1):
 name=Path(command[1]).name if command[0]=='bash' else re.sub(r'[^A-Za-z0-9_.-]+','_', '-'.join(command))
 log=out/(str(index).zfill(2)+'-'+name+'.log')
 item={'command':command,'started_at':now(),'status':'running','log':str(log)};record['checks'].append(item);save()
 with log.open('w') as stream:
  try:code=subprocess.run(command,env=env,stdout=stream,stderr=subprocess.STDOUT,timeout=3600).returncode
  except subprocess.TimeoutExpired:code=124
 item.update(exit_code=code,status='passed' if code==0 else 'failed',finished_at=now());save()
 print(str(index)+'/33 '+name+' '+item['status'],flush=True)
record.update(status='passed' if all(c['exit_code']==0 for c in record['checks']) else 'failed',finished_at=now())
record['summary']={'commands':len(commands),'passed':sum(c['exit_code']==0 for c in record['checks']),'failed':sum(c['exit_code']!=0 for c in record['checks'])}
save()
raise SystemExit(0 if record['status']=='passed' else 1)
