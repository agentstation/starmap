Starmap could not configure authority origins and native permission clocks through its host settings. This change connects those settings to runtime-owned clock monitors and explicit authority issuance.

Followers retain and adopt the accepted catalog without claiming a writer lease. Restart refuses ordinary mode for an authoritative stored catalog. Explicit authority and policy transitions use their own alias inventory and require current permission before inference.

The native clock adapters arrive through PR #151. This delivery owns their configuration and lifecycle. Full shared-input recovery and fleet fencing qualification remain with CSP11.

Add validation results after the repository verifier and CSP4 task checks finish.
