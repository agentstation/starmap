package main

import (
 "context"
 "encoding/json"
 "fmt"
 "os"
 "time"

 "github.com/agentstation/starmap/internal/sources/github"
)

func main() {
 state, err := os.MkdirTemp("", "starmap-public-observation-")
 if err != nil { panic(err) }
 defer os.RemoveAll(state)
 source, err := github.New(github.WithStateDirectory(state))
 if err != nil { panic(err) }
 defer source.Cleanup()
 ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
 defer cancel()
 observation, readErr := source.Observe(ctx)
 retained, retainedErr := source.RollbackTarget()
 output := map[string]any{"observation_source": observation.SourceID, "retained": retained, "read_error": fmt.Sprint(readErr), "retained_error": fmt.Sprint(retainedErr), "provider_credentials_supplied": false, "github_token_supplied": false}
 if err := json.NewEncoder(os.Stdout).Encode(output); err != nil { panic(err) }
}
