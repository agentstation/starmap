package main

import (
 "context"
 "encoding/json"
 "fmt"
 "os"
 "time"

 catalogruntime "github.com/agentstation/starmap/runtime"
)

func main() {
 state, err := os.MkdirTemp("", "starmap-public-runtime-")
 if err != nil { panic(err) }
 defer os.RemoveAll(state)
 ctx, cancel := context.WithTimeout(context.Background(), 90*time.Second)
 defer cancel()
 runtime, err := catalogruntime.Open(ctx, catalogruntime.WithStateDirectory(state), catalogruntime.WithAcquisitionEnabled(false), catalogruntime.WithSourcePollInterval(0))
 if err != nil { panic(err) }
 before := runtime.Status()
 report, refreshErr := runtime.RefreshSource(ctx)
 after := runtime.Status()
 closeErr := runtime.Close()
 output := map[string]any{"before": before, "refresh": report, "after": after, "refresh_error": fmt.Sprint(refreshErr), "close_error": fmt.Sprint(closeErr), "provider_credentials_supplied": false, "github_token_supplied": false}
 if err := json.NewEncoder(os.Stdout).Encode(output); err != nil { panic(err) }
}
