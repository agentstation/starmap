#!/usr/bin/env bash
set -euo pipefail
TMPDIR="$(mktemp -d "${TMPDIR:-/tmp}/starmap-verify-remainder.XXXXXX")"
TMPDIR="$(cd "$TMPDIR" && pwd -P)"
VERIFY_HOME="$TMPDIR/home"
trap 'rm -rf "$TMPDIR"' EXIT
run() {
 printf '\n==> %s\n' "$*"
 "$@"
}
run git diff --check

run go build -o "$TMPDIR/starmap" ./cmd/starmap
# Each CLI check uses only the embedded catalog and operation-owned paths.
run_cli() (
	cd "$TMPDIR"
	env -i \
		PATH="$PATH" \
		TMPDIR="$TMPDIR" \
		HOME="$VERIFY_HOME" \
		XDG_CONFIG_HOME="$VERIFY_HOME/.config" \
		CLOUDSDK_CONFIG="$VERIFY_HOME/.config/gcloud" \
		STARMAP_HOME="$TMPDIR/product" \
		STARMAP_CATALOG_SOURCE=embedded \
		STARMAP_CATALOG_ACQUISITION_ENABLED=false \
		STARMAP_CATALOG_WORKSPACE_PATH= \
		"$TMPDIR/starmap" "$@"
)

mkdir -p "$VERIFY_HOME"
run run_cli version
run run_cli validate catalog
run run_cli providers
run run_cli models list --limit 5

printf '\nrepository verification passed\n'
