validateAcceptedOrder uses authority sequence or ordinary publication time.
Changing authority requires an explicit transition outside candidate acceptance.
