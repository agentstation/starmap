import os, json, subprocess, tempfile, tarfile, pathlib, time
root = pathlib.Path.cwd()
out = root / ".tmp/csp4-public-acceptance"
stage = pathlib.Path(tempfile.mkdtemp(prefix="starmap-public-generation-"))
archive = stage / "source.tar"
with archive.open("wb") as stream:
    subprocess.run(["git", "archive", "HEAD"], stdout=stream, check=True)
source = stage / "source"
source.mkdir()
with tarfile.open(archive) as bundle:
    bundle.extractall(source, filter="data")
cache = subprocess.check_output(["go", "env", "GOCACHE"], text=True).strip()
gopath = subprocess.check_output(["go", "env", "GOPATH"], text=True).strip()
env = {"PATH": os.environ["PATH"], "TMPDIR": tempfile.gettempdir(), "GOCACHE": cache, "GOPATH": gopath, "GOTOOLCHAIN": "go1.26.6", "GOFLAGS": "-p=2", "GOMAXPROCS": "4", "STARMAP_GENERATION_NONINTERACTIVE": "1", "STARMAP_GENERATION_STATE_PATH": str(stage / "state"), "STARMAP_GENERATION_STORE_PATH": str(stage / "state/catalog-store"), "STARMAP_GENERATION_REPORT_PATH": str(out / "live-generation-report.json")}
started = time.time()
meta = {"source_commit": subprocess.check_output(["git", "rev-parse", "HEAD"], text=True).strip(), "source_copy": str(source), "provider_credentials": "No credentials passed", "command": ["bash", "scripts/generate-embedded-catalog.sh"], "started": started, "publication": "Local isolated source copy only"}
(out / "live-generation-probe.json").write_text(json.dumps(meta, indent=2) + "\n")
with (out / "live-generation.log").open("w") as log:
    result = subprocess.run(meta["command"], cwd=source, env=env, stdout=log, stderr=subprocess.STDOUT, timeout=900)
meta.update(exit_code=result.returncode, duration_seconds=time.time() - started)
(out / "live-generation-probe.json").write_text(json.dumps(meta, indent=2) + "\n")
raise SystemExit(result.returncode)
