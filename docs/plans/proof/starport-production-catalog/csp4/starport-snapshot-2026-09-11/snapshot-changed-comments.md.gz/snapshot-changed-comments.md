ErrCatalogAuthorityMismatch reports authority metadata from a different publication.

AuthorityHead returns the authority head bound to this catalog.

This read does not grant permission.
