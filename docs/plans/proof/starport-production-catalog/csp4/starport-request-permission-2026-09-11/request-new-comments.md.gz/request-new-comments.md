CheckNewAttempt returns a retryable gateway refusal when current permission is unavailable.

A refusal carries no provider-health evidence. Successful checks allocate no memory.

GatewayUnavailable identifies a temporary gateway admission refusal.

Read the first event before headers so cache permission refusals keep their HTTP status.
