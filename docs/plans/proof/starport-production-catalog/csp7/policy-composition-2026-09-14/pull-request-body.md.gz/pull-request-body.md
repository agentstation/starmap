Starmap now resolves catalog credentials as complete handles and applies STARMAP-prefixed environment names before conventional names. Explicit empty values, alias conflicts, invalid references, and expired material stop resolution without selecting a lower candidate.

Persistent installations compare their complete legacy and current selections before accepting a provider migration. A changed selection requires an explicit reference or removal of the conflicting variable. Private records retain selection policy without storing credential values or hashes. Fresh startup records the current policy before catalog writes.

`acquisition.OpenCredentialResolver` exposes deployment-secret sources and optional policy storage to Go hosts. Provider diagnostics report the selected source names and distinguish unavailable material from absent configuration. Starport's role namespace and shared configuration integration remain separate consumer work.

Validation:

- The complete repository suite passes 6,838 test events with eight explicit skips before the S3 module update. Go source remained unchanged during that run.
- Auth and table qualification passes 124 race events per toolchain (`go1.26.6`, `go1.25.12`). Migration and backend recovery checks preserve their failed regressions.
- Six Starmap component cases pass 76 events. Product cases A11 and A12 remain unverified until Starport integration.
- Generated documentation, strict prose, pinned lint, Go policy, and consumer dependency checks pass. After the S3 module update, auth, acquisition, and S3 suites pass 268 race events.
- Native CI now includes credential tests on all six platform jobs. Windows jobs now allow 120 minutes. Hosted results and merge remain pending.
