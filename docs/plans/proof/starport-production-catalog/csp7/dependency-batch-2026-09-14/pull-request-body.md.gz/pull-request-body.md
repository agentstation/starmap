Starmap now resolves catalog credentials as complete handles and applies STARMAP-prefixed environment names before conventional names. Explicit empty values, alias conflicts, invalid references, and expired material stop resolution without selecting a lower candidate.

Persistent installations compare their complete legacy and current selections before accepting a provider migration. A changed selection requires an explicit reference or removal of the conflicting variable. Private records retain selection policy without storing credential values or hashes. Fresh startup records the current policy before catalog writes.

`acquisition.OpenCredentialResolver` exposes deployment-secret sources and optional policy storage to Go hosts. Provider diagnostics report the selected source names and distinguish unavailable material from absent configuration. Starport's role namespace and shared configuration integration remain separate consumer work.

The branch also integrates three dependency updates:

- PR #156: AWS configuration SDK `1.33.4`.
- PR #158: Secrets Manager SDK `1.49.0`.
- PR #159: flock `0.13.1`.

Root and consumer modules use the combined versions. Those PRs remain open until this integration merges.

Validation:

- The complete repository suite passes 6,838 test events with eight explicit skips before the S3 module update. Go source remained unchanged during that run.
- Auth and table qualification passes 124 race events per toolchain (`go1.26.6`, `go1.25.12`). Migration and backend recovery checks preserve their failed regressions.
- The CSP7 component gate passes after dependency integration. Product cases A11 and A12 remain unverified until Starport integration.
- Generated documentation, strict prose, pinned lint, Go policy, and consumer dependency checks pass. The integrated credential, acquisition, private-file, and S3 suites pass 386 race events. Eleven process-lock tests pass 14 race events. All six external-consumer profiles pass.
- Native CI now includes credential tests on all six platform jobs. Windows jobs now allow 120 minutes. Hosted results and merge remain pending.
