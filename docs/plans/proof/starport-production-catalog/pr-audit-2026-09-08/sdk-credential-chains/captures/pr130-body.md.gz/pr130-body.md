Bumps [github.com/aws/aws-sdk-go-v2/service/s3](https://github.com/aws/aws-sdk-go-v2) in `/` from 1.109.1 to 1.110.0.

Updates `github.com/aws/aws-sdk-go-v2/service/s3` from 1.109.1 to 1.110.0
<details>
<summary>Commits</summary>
<ul>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/5a5ee7a736838df1cb7c39f2b3f5d78bed226463"><code>5a5ee7a</code></a> Release 2026-08-31.2</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/bb728165a2693e50d6b2f3daf87c297431fd0ba6"><code>bb72816</code></a> Regenerated Clients</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/41672340b694210f8668b498d45dae3c1c10e293"><code>4167234</code></a> Update API model</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/85ddf74cf51912ae62d47e5cd286b93a9411e481"><code>85ddf74</code></a> Remove credential source middleware (<a href="https://redirect.github.com/aws/aws-sdk-go-v2/issues/3539">#3539</a>)</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/258c696b788c342a4ea451e2ae994a4e124ee256"><code>258c696</code></a> Release 2026-08-31</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/029ffebfef8fbd53fb7fd96ed237006990204c56"><code>029ffeb</code></a> Regenerated Clients</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/c884b0f00dacb633e805ee615393d847ab309ce4"><code>c884b0f</code></a> Update API model</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/71ac84b03a64cf14673a40e5d040f5951a0914cf"><code>71ac84b</code></a> schema-serde: json wave 3 (<a href="https://redirect.github.com/aws/aws-sdk-go-v2/issues/3538">#3538</a>)</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/b63d8be8c659dabab8165fd12a18c22338fd75cc"><code>b63d8be</code></a> Release 2026-08-28.2</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/43288f751afc3a9f8e55093c023a4dfffcc454d7"><code>43288f7</code></a> Regenerated Clients</li>
<li>Additional commits viewable in <a href="https://github.com/aws/aws-sdk-go-v2/compare/service/s3/v1.109.1...service/s3/v1.110.0">compare view</a></li>
</ul>
</details>
<br />

Updates `github.com/aws/aws-sdk-go-v2/service/s3` from 1.109.1 to 1.110.0
<details>
<summary>Commits</summary>
<ul>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/5a5ee7a736838df1cb7c39f2b3f5d78bed226463"><code>5a5ee7a</code></a> Release 2026-08-31.2</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/bb728165a2693e50d6b2f3daf87c297431fd0ba6"><code>bb72816</code></a> Regenerated Clients</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/41672340b694210f8668b498d45dae3c1c10e293"><code>4167234</code></a> Update API model</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/85ddf74cf51912ae62d47e5cd286b93a9411e481"><code>85ddf74</code></a> Remove credential source middleware (<a href="https://redirect.github.com/aws/aws-sdk-go-v2/issues/3539">#3539</a>)</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/258c696b788c342a4ea451e2ae994a4e124ee256"><code>258c696</code></a> Release 2026-08-31</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/029ffebfef8fbd53fb7fd96ed237006990204c56"><code>029ffeb</code></a> Regenerated Clients</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/c884b0f00dacb633e805ee615393d847ab309ce4"><code>c884b0f</code></a> Update API model</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/71ac84b03a64cf14673a40e5d040f5951a0914cf"><code>71ac84b</code></a> schema-serde: json wave 3 (<a href="https://redirect.github.com/aws/aws-sdk-go-v2/issues/3538">#3538</a>)</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/b63d8be8c659dabab8165fd12a18c22338fd75cc"><code>b63d8be</code></a> Release 2026-08-28.2</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/43288f751afc3a9f8e55093c023a4dfffcc454d7"><code>43288f7</code></a> Regenerated Clients</li>
<li>Additional commits viewable in <a href="https://github.com/aws/aws-sdk-go-v2/compare/service/s3/v1.109.1...service/s3/v1.110.0">compare view</a></li>
</ul>
</details>
<br />


Dependabot will resolve any conflicts with this PR as long as you don't alter it yourself. You can also trigger a rebase manually by commenting `@dependabot rebase`.

[//]: # (dependabot-automerge-start)
[//]: # (dependabot-automerge-end)

---

<details>
<summary>Dependabot commands and options</summary>
<br />

You can trigger Dependabot actions by commenting on this PR:
- `@dependabot rebase` will rebase this PR
- `@dependabot recreate` will recreate this PR, overwriting any edits that have been made to it
- `@dependabot show <dependency name> ignore conditions` will show all of the ignore conditions of the specified dependency
- `@dependabot ignore <dependency name> major version` will close this group update PR and stop Dependabot creating any more for the specific dependency's major version (unless you unignore this specific dependency's major version or upgrade to it yourself)
- `@dependabot ignore <dependency name> minor version` will close this group update PR and stop Dependabot creating any more for the specific dependency's minor version (unless you unignore this specific dependency's minor version or upgrade to it yourself)
- `@dependabot ignore <dependency name>` will close this group update PR and stop Dependabot creating any more for the specific dependency (unless you unignore this specific dependency or upgrade to it yourself)
- `@dependabot unignore <dependency name>` will remove all of the ignore conditions of the specified dependency
- `@dependabot unignore <dependency name> <ignore condition>` will remove the ignore condition of the specified dependency and ignore conditions


</details>

<!-- catalog-pr-audit -->
Current disposition (2026-09-08)

Retain as the S3 dependency update. This PR also updates the server-storage consumer fixture module and checksum file. Current required checks pass. Preserve those fixture changes during integration and complete dependency review before merge.

<!-- catalog-pr-current-queue -->
Local SDK qualification (2026-09-08)

Local SDK qualification now exercises the production secret-source factories on both existing and proposed dependency versions.

AWS coverage includes environment credentials, shared files, environment precedence, web identity exchange through STS, missing credentials, and denied secret reads. Azure coverage includes environment credentials, workload identity, and denied secret reads.

Each full authentication race suite passes 78 test events and one package result, with no failures or skips. The updated dependencies also pass with Go 1.25.12. Package lint and Ago pass.

The tests use real SDK selection, signing, token exchange, and decoding against local TLS fixtures. They do not qualify live cloud IAM policy, SSO, device login, or managed identity services.

The earlier combined dependency suite passes 169 test events and four packages. All six consumer checks pass after the checksum repair at `9575418e`. Preserve that repair during catalog-branch integration.

The new tests reside in local catalog commit `d35a62ee` and isolated dependency commit `e2343509`. This PR's attached CI does not include those new tests. Current-head checks and owner authorization still govern a default-branch merge.
