Local SDK qualification now exercises the production secret-source factories on both existing and proposed dependency versions.

AWS coverage includes environment credentials, shared files, environment precedence, web identity exchange through STS, missing credentials, and denied secret reads. Azure coverage includes environment credentials, workload identity, and denied secret reads.

Each full authentication race suite passes 78 test events and one package result, with no failures or skips. The updated dependencies also pass with Go 1.25.12. Package lint and Ago pass.

The tests use real SDK selection, signing, token exchange, and decoding against local TLS fixtures. They do not qualify live cloud IAM policy, SSO, device login, or managed identity services.

The earlier combined dependency suite passes 169 test events and four packages. All six consumer checks pass after the checksum repair at `9575418e`. Preserve that repair during catalog-branch integration.

The new tests reside in local catalog commit `d35a62ee` and isolated dependency commit `e2343509`. This PR's attached CI does not include those new tests. Current-head checks and owner authorization still govern a default-branch merge.
