Retain catalog qualification captures, PR dispositions, and integration evidence for #136. This evidence-only PR uses #133 as its parent.

The diff contains 174 proof files. This update changes 99 files. It preserves failed runs, the repaired native run, the final CSP2 report, and separate CSP3 and Starport candidate results.

Reviewed Starmap source 7e591262 passes all eleven jobs in run 34193810413. All 22 selected CSP2 subcases pass. The native artifacts retain both architectures for Linux, macOS, and Windows. The earlier allocation failure remains available.

Validation: the prose check passes across 1,159 files. An explicit credential scan passes for 95 new or changed captures, including decoded compressed sources. Four additional files retain the inventory and scan result. The automatic pre-PR gate passes without model review because this diff contains only evidence.

The isolated CSP3 repair passes 103 focused race events and eighteen minimum-Go events. Starport passes both full suites with the published Starmap commit. Its stable-version gate still rejects that pseudo-version. These checks do not qualify the released pair.

Current disposition (2026-09-08): retain as the evidence parent for #136. The audit closed superseded #127. Fourteen PRs remain across both repositories. Revalidate the combined tree after lower stack merges. This update adds no PR.

<!-- catalog-pr-current-queue -->
Current queue review (2026-09-08)

The qualification evidence head now includes acquisition PR #133 at 07dcb63d. This parent update changes 23 proof paths. Source, test, and configuration bytes remain unchanged from 50557f05. This evidence PR retains its ownership and does not add product qualification.
