Register Starmap path, file-inventory, and migration contracts in the catalog verifier. Application tests prove distinct instance seeds, duplicate-owner refusal, empty-path rejection, and explicit service roots.

Native qualification requires both supported architectures, exact named tests, matching source and test inputs, unchanged capture files, and successful package completion. Linux also requires the privileged configuration check when its unprivileged suite skips that case.

The allocation repair skips model-diff work when no model observer needs it. An isolated process checks zero allocations for fresh, updated, and restarted baseline reads. A positive control records one allocation.

Reviewed source 7e591262 passes all eleven jobs in [run 34193810413](https://github.com/agentstation/starmap/actions/runs/34193810413). All 22 assigned CSP2 subcases pass. Native runtime coverage includes Linux, macOS, and Windows on both architectures. The evidence retains the earlier failed run.

Validation includes all 39 local repository stages, 79 ordinary and 79 race package suites, and 73 verifier tests. The final allocation suite passes twelve race events. Ago and lint pass. Required Sol xhigh and Opus high review passes with zero findings.

The plan marks CSP2 done and CSP3 in progress. Eight of 38 tasks are terminal. This update changes only proof and plan state after the qualified source. It grants no released-pair qualification. The primary roster remains 50 cases and 324 required subcases.

Current disposition (2026-09-08): retain this implementation PR above evidence PR #135. The PR audit preserves fourteen distinct or dependent changes across both repositories. Revalidate the combined tree after lower stack merges. No main merge or release belongs to this update.

<!-- catalog-pr-current-queue -->
Current queue review (2026-09-08)

The qualification head now includes evidence PR #135 at aff5fd53. This parent update changes 23 proof paths. Source, test, and configuration bytes match the previous head, `e68f61a6`.
The CSP2 native evidence identifies commit `7e591262`. Unpublished CSP3 changes remain in the plan worktree and require their own publication review.
