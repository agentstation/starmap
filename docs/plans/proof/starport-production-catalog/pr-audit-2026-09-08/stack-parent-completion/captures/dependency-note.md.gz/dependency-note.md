The combined catalog-branch check applies Starmap PRs #128 through #131 to plan commit `14ccae87`.

Authentication, S3, provider-source, and acquisition suites pass 169 test events and four package results with no failures or skips.

The Go 1.25.12 authentication and S3 suite passes 76 test events and two package results. All six consumer integration checks pass. Module verification and Ago pass.

Combining these updates requires preserving all selected AWS versions and the catalog branch's purego requirement. Six consumer modules need refreshed checksum files. The isolated repair at `9575418e` passes their tidy checks and repeated consumer integration checks.

The authentication tests inject cloud SDK reads. Default credential-chain and live cloud authentication checks remain unverified. This evidence does not authorize a default-branch merge or qualify Starport #368.
