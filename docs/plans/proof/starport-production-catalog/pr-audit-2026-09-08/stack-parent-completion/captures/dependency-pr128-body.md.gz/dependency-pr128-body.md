Bumps [github.com/Azure/azure-sdk-for-go/sdk/azidentity](https://github.com/Azure/azure-sdk-for-go) in `/` from 1.14.0 to 1.14.1.

Updates `github.com/Azure/azure-sdk-for-go/sdk/azidentity` from 1.14.0 to 1.14.1
<details>
<summary>Release notes</summary>
<p><em>Sourced from <a href="https://github.com/Azure/azure-sdk-for-go/releases">github.com/Azure/azure-sdk-for-go/sdk/azidentity's releases</a>.</em></p>
<blockquote>
<h2>sdk/azidentity/v1.14.1</h2>
<h2>1.14.1 (2026-08-27)</h2>
<h3>Other Changes</h3>
<ul>
<li>Upgraded dependencies</li>
</ul>
</blockquote>
</details>
<details>
<summary>Commits</summary>
<ul>
<li><a href="https://github.com/Azure/azure-sdk-for-go/commit/920e79a1664fa91142c45775c8e0cc3bd1ae20dd"><code>920e79a</code></a> Prep azidentity for release (<a href="https://redirect.github.com/Azure/azure-sdk-for-go/issues/27473">#27473</a>)</li>
<li><a href="https://github.com/Azure/azure-sdk-for-go/commit/d86ae78bd655d233689866cf78930f3c5fd42c35"><code>d86ae78</code></a> Prep azcore for release (<a href="https://redirect.github.com/Azure/azure-sdk-for-go/issues/27471">#27471</a>)</li>
<li><a href="https://github.com/Azure/azure-sdk-for-go/commit/33dd768d272337b287d1c528b27d528e89f08435"><code>33dd768</code></a> [azwebpubsub] Fix GenerateClientAccessURL on the TokenCredential path (<a href="https://redirect.github.com/Azure/azure-sdk-for-go/issues/27422">#27422</a>)</li>
<li><a href="https://github.com/Azure/azure-sdk-for-go/commit/a27ca57b4db13090a9a10737e6bdc6c2a5f17657"><code>a27ca57</code></a> Upgrade TypeSpec Go emitter dependencies (<a href="https://redirect.github.com/Azure/azure-sdk-for-go/issues/27466">#27466</a>)</li>
<li><a href="https://github.com/Azure/azure-sdk-for-go/commit/af75eb0f82375ca03d963ba7795eb4d9b44dbdc6"><code>af75eb0</code></a> [AutoPR sdk-resourcemanager/purestorageblock/armpurestorageblock]-generated-f...</li>
<li><a href="https://github.com/Azure/azure-sdk-for-go/commit/8dcff8c3829a3c4759bcca66e15dbdca28ec0e46"><code>8dcff8c</code></a> [AutoPR sdk-resourcemanager/redisenterprise/armredisenterprise]-generated-fro...</li>
<li><a href="https://github.com/Azure/azure-sdk-for-go/commit/e4569f1adf68b4ea82d83f8fb20ac8773d0090bc"><code>e4569f1</code></a> [AutoPR sdk-resourcemanager/chaos/armchaos]-generated-from-SDK Generation - G...</li>
<li><a href="https://github.com/Azure/azure-sdk-for-go/commit/7069bf802def9d7ca3e3404c4fbacb0a45aa1cdc"><code>7069bf8</code></a> [AutoPR sdk-resourcemanager/horizondb/armhorizondb]-generated-from-SDK Genera...</li>
<li><a href="https://github.com/Azure/azure-sdk-for-go/commit/5ceffcea634d0832317ae199db60343c7971e7d9"><code>5ceffce</code></a> Bump gh-aw to v0.86.2 for mgmt review workflow (<a href="https://redirect.github.com/Azure/azure-sdk-for-go/issues/27460">#27460</a>)</li>
<li><a href="https://github.com/Azure/azure-sdk-for-go/commit/663b6ce414fb4f539fdc67633e2c55c4aa79eb66"><code>663b6ce</code></a> Enhance azblob perf tests with OAuth, parallel setup, and profiling (<a href="https://redirect.github.com/Azure/azure-sdk-for-go/issues/27324">#27324</a>)</li>
<li>Additional commits viewable in <a href="https://github.com/Azure/azure-sdk-for-go/compare/sdk/azcore/v1.14.0...sdk/azidentity/v1.14.1">compare view</a></li>
</ul>
</details>
<br />


[![Dependabot compatibility score](https://dependabot-badges.githubapp.com/badges/compatibility_score?dependency-name=github.com/Azure/azure-sdk-for-go/sdk/azidentity&package-manager=go_modules&previous-version=1.14.0&new-version=1.14.1)](https://docs.github.com/en/github/managing-security-vulnerabilities/about-dependabot-security-updates#about-compatibility-scores)

Dependabot will resolve any conflicts with this PR as long as you don't alter it yourself. You can also trigger a rebase manually by commenting `@dependabot rebase`.

[//]: # (dependabot-automerge-start)
[//]: # (dependabot-automerge-end)

---

<details>
<summary>Dependabot commands and options</summary>
<br />

You can trigger Dependabot actions by commenting on this PR:
- `@dependabot rebase` will rebase this PR
- `@dependabot recreate` will recreate this PR, overwriting any edits that have been made to it
- `@dependabot show <dependency name> ignore conditions` will show all of the ignore conditions of the specified dependency
- `@dependabot ignore <dependency name> major version` will close this group update PR and stop Dependabot creating any more for the specific dependency's major version (unless you unignore this specific dependency's major version or upgrade to it yourself)
- `@dependabot ignore <dependency name> minor version` will close this group update PR and stop Dependabot creating any more for the specific dependency's minor version (unless you unignore this specific dependency's minor version or upgrade to it yourself)
- `@dependabot ignore <dependency name>` will close this group update PR and stop Dependabot creating any more for the specific dependency (unless you unignore this specific dependency or upgrade to it yourself)
- `@dependabot unignore <dependency name>` will remove all of the ignore conditions of the specified dependency
- `@dependabot unignore <dependency name> <ignore condition>` will remove the ignore condition of the specified dependency and ignore conditions


</details>

<!-- catalog-pr-audit -->
Current disposition (2026-09-08)

Retain as the Azure dependency update. This PR includes all go.mod and go.sum changes from #127, which this PR supersedes. Current required checks pass. Complete dependency review and validate integration before merge.

<!-- catalog-pr-current-queue -->
Combined catalog dependency check (2026-09-08)

The combined catalog-branch check applies Starmap PRs #128 through #131 to plan commit `14ccae87`.

Authentication, S3, provider-source, and acquisition suites pass 169 test events and four package results with no failures or skips.

The Go 1.25.12 authentication and S3 suite passes 76 test events and two package results. All six consumer integration checks pass. Module verification and Ago pass.

Combining these updates requires preserving all selected AWS versions and the catalog branch's purego requirement. Six consumer modules need refreshed checksum files. The isolated repair at `9575418e` passes their tidy checks and repeated consumer integration checks.

The authentication tests inject cloud SDK reads. Default credential-chain and live cloud authentication checks remain unverified. This evidence does not authorize a default-branch merge or qualify Starport #368.
