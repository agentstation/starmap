Connect declared acquisition bindings through the CLI, server, and retained runtime layers. Fresh updates discard selected local acquisition results while preserving the embedded or upstream baseline and unrelated scopes.

Provider observations retain receipts, account scope, revision, and completeness through canonical reconciliation and restart. Pricing remains a complete validated record, and linked model membership survives absent optional pricing or limits. An immutable identity index removes full-provider copies from offering lookup.

Explicitly selected service-managed primary configuration permits checked administrator ownership. Catalog state and dotenv files remain private. Native Windows repairs grant temporary write access during workspace assembly and restore the original descriptors before publication.

The verification tools exercise passive constructors under enforced socket restrictions. A separate check starts two real offline server processes and verifies the saved baseline through HTTP and restart. GitHub Actions retains both reports in separate Linux jobs.

The requirements now distinguish permitted discovery, structural support, and caller readiness. The independent audit records current Starport cache, facet, and dependency gaps for their existing plan owners. Account-specific withdrawals still require explicit inference-profile links. Complete scoped deletion, Starport dependency adoption, remaining UI behavior, and released-pair acceptance remain open.

Validation: all 39 repository stages pass with Go 1.26.6. Ordinary and race suites each pass 79 packages, and all 62 verifier tests pass. The required Sol and Opus review passed all five portions with zero P0 findings.

Foundation CI passed all nine jobs. The follow-up CI run passed all 11 jobs. Each Windows architecture passed 1,223 test events. Each macOS architecture passed 1,278 events.

Each Linux architecture passed 1,222 events. Its unprivileged suite skipped the administrator-owned configuration read, which passed in a separate privileged invocation.

This draft uses evidence PR #134 as its actual base, following foundation PR #132. The complete code diff remains intact. CSP2 has seven passing component subcases and fifteen unverified subcases. This draft does not qualify the released product pair.


<!-- catalog-pr-audit -->
Current disposition (2026-09-08)

Retain as the acquisition and reset implementation parent for #135. Run 34186118026 passed all 11 jobs at 637f780a. This PR depends on #134. Revalidate the combined tree after lower stack merges.

<!-- catalog-pr-current-queue -->
Current queue review (2026-09-08)

The acquisition head now includes PR #134 at 99843ff8. This parent update changes 23 proof paths. Source, test, and configuration bytes remain unchanged from 637f780a. The complete diff outside the proof directory also remains unchanged. Existing native evidence applies to its recorded source. Further product qualification remains open.
