Bumps [github.com/aws/aws-sdk-go-v2/service/secretsmanager](https://github.com/aws/aws-sdk-go-v2) in `/` from 1.46.1 to 1.47.0.

Updates `github.com/aws/aws-sdk-go-v2/service/secretsmanager` from 1.46.1 to 1.47.0
<details>
<summary>Commits</summary>
<ul>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/a88ff68b5524ce9e4f816c8c313267e6d321ce8c"><code>a88ff68</code></a> Release 2023-11-29</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/023df359dd66f7b3970ddf2874c69d4b78b99126"><code>023df35</code></a> Regenerated Clients</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/41f99ac19a3c3fc2e7e177b8f2632d319bb590e4"><code>41f99ac</code></a> Update SDK's smithy-go dependency to v1.18.0</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/72478fb87eae54a9d5ea84b336daad6795aebe01"><code>72478fb</code></a> Update API model</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/4c4b852716f661378136f0e4d7e966d180057e26"><code>4c4b852</code></a> feat: add Options() getter to service clients (<a href="https://redirect.github.com/aws/aws-sdk-go-v2/issues/2398">#2398</a>)</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/6b86039a2b6015432b243b342b532f2db7a9c709"><code>6b86039</code></a> Update golang.org/x/net dependency (<a href="https://redirect.github.com/aws/aws-sdk-go-v2/issues/2391">#2391</a>)</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/0a955dd146a98d4b218893390a5c72512e0477c7"><code>0a955dd</code></a> Release 2023-11-28.3</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/94a398007cfac2c60a62c203faa363a4ecaa4abf"><code>94a3980</code></a> fix: correct wiring of disable s3express auth toggle (<a href="https://redirect.github.com/aws/aws-sdk-go-v2/issues/2394">#2394</a>)</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/4aeeb0d7a4293f0b31c2e0be83e65da6f7fd4ae2"><code>4aeeb0d</code></a> Release 2023-11-28.2</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/e09e153704d4da6ae2bb0ae3875058950d31206b"><code>e09e153</code></a> Regenerated Clients</li>
<li>Additional commits viewable in <a href="https://github.com/aws/aws-sdk-go-v2/compare/service/ivs/v1.46.1...service/s3/v1.47.0">compare view</a></li>
</ul>
</details>
<br />


[![Dependabot compatibility score](https://dependabot-badges.githubapp.com/badges/compatibility_score?dependency-name=github.com/aws/aws-sdk-go-v2/service/secretsmanager&package-manager=go_modules&previous-version=1.46.1&new-version=1.47.0)](https://docs.github.com/en/github/managing-security-vulnerabilities/about-dependabot-security-updates#about-compatibility-scores)

Dependabot will resolve any conflicts with this PR as long as you don't alter it yourself. You can also trigger a rebase manually by commenting `@dependabot rebase`.

[//]: # (dependabot-automerge-start)
[//]: # (dependabot-automerge-end)

---

<details>
<summary>Dependabot commands and options</summary>
<br />

You can trigger Dependabot actions by commenting on this PR:
- `@dependabot rebase` will rebase this PR
- `@dependabot recreate` will recreate this PR, overwriting any edits that have been made to it
- `@dependabot show <dependency name> ignore conditions` will show all of the ignore conditions of the specified dependency
- `@dependabot ignore <dependency name> major version` will close this group update PR and stop Dependabot creating any more for the specific dependency's major version (unless you unignore this specific dependency's major version or upgrade to it yourself)
- `@dependabot ignore <dependency name> minor version` will close this group update PR and stop Dependabot creating any more for the specific dependency's minor version (unless you unignore this specific dependency's minor version or upgrade to it yourself)
- `@dependabot ignore <dependency name>` will close this group update PR and stop Dependabot creating any more for the specific dependency (unless you unignore this specific dependency or upgrade to it yourself)
- `@dependabot unignore <dependency name>` will remove all of the ignore conditions of the specified dependency
- `@dependabot unignore <dependency name> <ignore condition>` will remove the ignore condition of the specified dependency and ignore conditions


</details>

<!-- catalog-pr-audit -->
Current disposition (2026-09-08)

Retain as the Secrets Manager dependency update. Current required checks pass. Complete dependency review and validate integration before merge.

<!-- catalog-pr-current-queue -->
Combined catalog dependency check (2026-09-08)

The combined catalog-branch check applies Starmap PRs #128 through #131 to plan commit `14ccae87`.

Authentication, S3, provider-source, and acquisition suites pass 169 test events and four package results with no failures or skips.

The Go 1.25.12 authentication and S3 suite passes 76 test events and two package results. All six consumer integration checks pass. Module verification and Ago pass.

Combining these updates requires preserving all selected AWS versions and the catalog branch's purego requirement. Six consumer modules need refreshed checksum files. The isolated repair at `9575418e` passes their tidy checks and repeated consumer integration checks.

The authentication tests inject cloud SDK reads. Default credential-chain and live cloud authentication checks remain unverified. This evidence does not authorize a default-branch merge or qualify Starport #368.
