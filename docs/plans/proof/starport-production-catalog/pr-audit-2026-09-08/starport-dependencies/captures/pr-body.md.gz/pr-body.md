Bumps the go-modules group with 9 updates:

| Package | From | To |
| --- | --- | --- |
| [github.com/aws/aws-sdk-go-v2/config](https://github.com/aws/aws-sdk-go-v2) | `1.33.1` | `1.33.2` |
| [github.com/aws/aws-sdk-go-v2/credentials](https://github.com/aws/aws-sdk-go-v2) | `1.20.1` | `1.20.2` |
| [github.com/aws/aws-sdk-go-v2/feature/s3/manager](https://github.com/aws/aws-sdk-go-v2) | `1.23.1` | `1.23.2` |
| [github.com/aws/aws-sdk-go-v2/service/s3](https://github.com/aws/aws-sdk-go-v2) | `1.109.1` | `1.110.0` |
| [github.com/aws/aws-sdk-go-v2/service/secretsmanager](https://github.com/aws/aws-sdk-go-v2) | `1.46.1` | `1.47.0` |
| [github.com/go-sql-driver/mysql](https://github.com/go-sql-driver/mysql) | `1.10.0` | `1.10.1` |
| [github.com/yuin/goldmark](https://github.com/yuin/goldmark) | `1.8.5` | `1.8.6` |
| [golang.org/x/crypto](https://github.com/golang/crypto) | `0.55.0` | `0.56.0` |
| [modernc.org/sqlite](https://gitlab.com/cznic/sqlite) | `1.57.0` | `1.58.0` |

Updates `github.com/aws/aws-sdk-go-v2/config` from 1.33.1 to 1.33.2
<details>
<summary>Commits</summary>
<ul>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/5a5ee7a736838df1cb7c39f2b3f5d78bed226463"><code>5a5ee7a</code></a> Release 2026-08-31.2</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/bb728165a2693e50d6b2f3daf87c297431fd0ba6"><code>bb72816</code></a> Regenerated Clients</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/41672340b694210f8668b498d45dae3c1c10e293"><code>4167234</code></a> Update API model</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/85ddf74cf51912ae62d47e5cd286b93a9411e481"><code>85ddf74</code></a> Remove credential source middleware (<a href="https://redirect.github.com/aws/aws-sdk-go-v2/issues/3539">#3539</a>)</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/258c696b788c342a4ea451e2ae994a4e124ee256"><code>258c696</code></a> Release 2026-08-31</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/029ffebfef8fbd53fb7fd96ed237006990204c56"><code>029ffeb</code></a> Regenerated Clients</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/c884b0f00dacb633e805ee615393d847ab309ce4"><code>c884b0f</code></a> Update API model</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/71ac84b03a64cf14673a40e5d040f5951a0914cf"><code>71ac84b</code></a> schema-serde: json wave 3 (<a href="https://redirect.github.com/aws/aws-sdk-go-v2/issues/3538">#3538</a>)</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/b63d8be8c659dabab8165fd12a18c22338fd75cc"><code>b63d8be</code></a> Release 2026-08-28.2</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/43288f751afc3a9f8e55093c023a4dfffcc454d7"><code>43288f7</code></a> Regenerated Clients</li>
<li>Additional commits viewable in <a href="https://github.com/aws/aws-sdk-go-v2/compare/config/v1.33.1...config/v1.33.2">compare view</a></li>
</ul>
</details>
<br />

Updates `github.com/aws/aws-sdk-go-v2/credentials` from 1.20.1 to 1.20.2
<details>
<summary>Commits</summary>
<ul>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/65023f312c12ce2707836e552ab55bb4f03f3345"><code>65023f3</code></a> Release 2023-08-17</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/0742a92e9b623ddaf650eaaea4abc3889b8a17f2"><code>0742a92</code></a> Regenerated Clients</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/0e3340f027ed652b13be24b63af875fe2d4985f7"><code>0e3340f</code></a> Update endpoints model</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/4526489235229d00a0735e6e28202556ae023729"><code>4526489</code></a> Update API model</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/18635b8d0644a641334d0b8cec6b6e1da2c8217c"><code>18635b8</code></a> Add X-Amz-Server-Side-Encryption-Context header to required signed headers al...</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/4682b6a4b93c5c23a30a064d5f1c8bc11c0636d4"><code>4682b6a</code></a> Achieve DisableMRAP parity in config loaders (<a href="https://redirect.github.com/aws/aws-sdk-go-v2/issues/2239">#2239</a>)</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/7ecab8687887d1131a9880aac17e12e589c04b4a"><code>7ecab86</code></a> Release 2023-08-16</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/1ac4adda4fb31aeca5db9e309a428d62ba85bf90"><code>1ac4add</code></a> Regenerated Clients</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/4f353cd96758cd06e28ea2bfb47d865c52b972d4"><code>4f353cd</code></a> Update API model</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/53f9e53a3e4404ee656500a4f5bf0da450d4f0ff"><code>53f9e53</code></a> remove checks on push because its redundant (<a href="https://redirect.github.com/aws/aws-sdk-go-v2/issues/2240">#2240</a>)</li>
<li>Additional commits viewable in <a href="https://github.com/aws/aws-sdk-go-v2/compare/v1.20.1...v1.20.2">compare view</a></li>
</ul>
</details>
<br />

Updates `github.com/aws/aws-sdk-go-v2/feature/s3/manager` from 1.23.1 to 1.23.2
<details>
<summary>Commits</summary>
<ul>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/4aeeb0d7a4293f0b31c2e0be83e65da6f7fd4ae2"><code>4aeeb0d</code></a> Release 2023-11-28.2</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/e09e153704d4da6ae2bb0ae3875058950d31206b"><code>e09e153</code></a> Regenerated Clients</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/8293e2ca285a7333a9931a0a3b37b2bcf7cdc05d"><code>8293e2c</code></a> Update endpoints model</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/713fb0f31a188015915d785556ebf16ddb08085a"><code>713fb0f</code></a> Update API model</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/830202d722c904c7e3da40e8dde7b9338d08752c"><code>830202d</code></a> Merge customizations for service s3</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/2de0027dc478a6ae80e9f2d24d904a425169a23b"><code>2de0027</code></a> Release 2023-11-28</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/f0c890c5eaf354ff23feb727ded9f50aaee9f1c4"><code>f0c890c</code></a> Regenerated Clients</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/e032d9ea8d98d366f2467a72834d2cc0ee865edd"><code>e032d9e</code></a> Update endpoints model</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/507661ff1edbc896fbdfe3ea2e4c2e74be3b4e3c"><code>507661f</code></a> Update API model</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/4128360684a451476e33c0f979921bc46ff63656"><code>4128360</code></a> fix: respect functional option modifications to RetryMaxAttempts (<a href="https://redirect.github.com/aws/aws-sdk-go-v2/issues/2390">#2390</a>)</li>
<li>Additional commits viewable in <a href="https://github.com/aws/aws-sdk-go-v2/compare/v1.23.1...v1.23.2">compare view</a></li>
</ul>
</details>
<br />

Updates `github.com/aws/aws-sdk-go-v2/service/s3` from 1.109.1 to 1.110.0
<details>
<summary>Commits</summary>
<ul>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/5a5ee7a736838df1cb7c39f2b3f5d78bed226463"><code>5a5ee7a</code></a> Release 2026-08-31.2</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/bb728165a2693e50d6b2f3daf87c297431fd0ba6"><code>bb72816</code></a> Regenerated Clients</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/41672340b694210f8668b498d45dae3c1c10e293"><code>4167234</code></a> Update API model</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/85ddf74cf51912ae62d47e5cd286b93a9411e481"><code>85ddf74</code></a> Remove credential source middleware (<a href="https://redirect.github.com/aws/aws-sdk-go-v2/issues/3539">#3539</a>)</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/258c696b788c342a4ea451e2ae994a4e124ee256"><code>258c696</code></a> Release 2026-08-31</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/029ffebfef8fbd53fb7fd96ed237006990204c56"><code>029ffeb</code></a> Regenerated Clients</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/c884b0f00dacb633e805ee615393d847ab309ce4"><code>c884b0f</code></a> Update API model</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/71ac84b03a64cf14673a40e5d040f5951a0914cf"><code>71ac84b</code></a> schema-serde: json wave 3 (<a href="https://redirect.github.com/aws/aws-sdk-go-v2/issues/3538">#3538</a>)</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/b63d8be8c659dabab8165fd12a18c22338fd75cc"><code>b63d8be</code></a> Release 2026-08-28.2</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/43288f751afc3a9f8e55093c023a4dfffcc454d7"><code>43288f7</code></a> Regenerated Clients</li>
<li>Additional commits viewable in <a href="https://github.com/aws/aws-sdk-go-v2/compare/service/s3/v1.109.1...service/s3/v1.110.0">compare view</a></li>
</ul>
</details>
<br />

Updates `github.com/aws/aws-sdk-go-v2/service/secretsmanager` from 1.46.1 to 1.47.0
<details>
<summary>Commits</summary>
<ul>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/a88ff68b5524ce9e4f816c8c313267e6d321ce8c"><code>a88ff68</code></a> Release 2023-11-29</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/023df359dd66f7b3970ddf2874c69d4b78b99126"><code>023df35</code></a> Regenerated Clients</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/41f99ac19a3c3fc2e7e177b8f2632d319bb590e4"><code>41f99ac</code></a> Update SDK's smithy-go dependency to v1.18.0</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/72478fb87eae54a9d5ea84b336daad6795aebe01"><code>72478fb</code></a> Update API model</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/4c4b852716f661378136f0e4d7e966d180057e26"><code>4c4b852</code></a> feat: add Options() getter to service clients (<a href="https://redirect.github.com/aws/aws-sdk-go-v2/issues/2398">#2398</a>)</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/6b86039a2b6015432b243b342b532f2db7a9c709"><code>6b86039</code></a> Update golang.org/x/net dependency (<a href="https://redirect.github.com/aws/aws-sdk-go-v2/issues/2391">#2391</a>)</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/0a955dd146a98d4b218893390a5c72512e0477c7"><code>0a955dd</code></a> Release 2023-11-28.3</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/94a398007cfac2c60a62c203faa363a4ecaa4abf"><code>94a3980</code></a> fix: correct wiring of disable s3express auth toggle (<a href="https://redirect.github.com/aws/aws-sdk-go-v2/issues/2394">#2394</a>)</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/4aeeb0d7a4293f0b31c2e0be83e65da6f7fd4ae2"><code>4aeeb0d</code></a> Release 2023-11-28.2</li>
<li><a href="https://github.com/aws/aws-sdk-go-v2/commit/e09e153704d4da6ae2bb0ae3875058950d31206b"><code>e09e153</code></a> Regenerated Clients</li>
<li>Additional commits viewable in <a href="https://github.com/aws/aws-sdk-go-v2/compare/service/ivs/v1.46.1...service/s3/v1.47.0">compare view</a></li>
</ul>
</details>
<br />

Updates `github.com/go-sql-driver/mysql` from 1.10.0 to 1.10.1
<details>
<summary>Release notes</summary>
<p><em>Sourced from <a href="https://github.com/go-sql-driver/mysql/releases">github.com/go-sql-driver/mysql's releases</a>.</em></p>
<blockquote>
<h2>v1.10.1</h2>
<h2>What's Changed</h2>
<ul>
<li>dsn: default Net to tcp in NewConfig so Addr-only configs round-trip by <a href="https://github.com/c-tonneslan"><code>@​c-tonneslan</code></a> in <a href="https://redirect.github.com/go-sql-driver/mysql/pull/1770">go-sql-driver/mysql#1770</a></li>
<li>Add LTS MariaDB 11.8 and 12.3 into the testing matrix by <a href="https://github.com/pgporada"><code>@​pgporada</code></a> in <a href="https://redirect.github.com/go-sql-driver/mysql/pull/1774">go-sql-driver/mysql#1774</a></li>
<li>Bump actions/checkout from 6 to 7 in the all-dependencies group by <a href="https://github.com/dependabot"><code>@​dependabot</code></a>[bot] in <a href="https://redirect.github.com/go-sql-driver/mysql/pull/1777">go-sql-driver/mysql#1777</a></li>
<li>ci: pin actions by <a href="https://github.com/methane"><code>@​methane</code></a> in <a href="https://redirect.github.com/go-sql-driver/mysql/pull/1778">go-sql-driver/mysql#1778</a></li>
<li>Bump the all-dependencies group with 3 updates by <a href="https://github.com/dependabot"><code>@​dependabot</code></a>[bot] in <a href="https://redirect.github.com/go-sql-driver/mysql/pull/1779">go-sql-driver/mysql#1779</a></li>
<li>Bump the all-dependencies group with 3 updates by <a href="https://github.com/dependabot"><code>@​dependabot</code></a>[bot] in <a href="https://redirect.github.com/go-sql-driver/mysql/pull/1780">go-sql-driver/mysql#1780</a></li>
<li>Interpolate typed-nil json.RawMessage as NULL by <a href="https://github.com/oha-4"><code>@​oha-4</code></a> in <a href="https://redirect.github.com/go-sql-driver/mysql/pull/1782">go-sql-driver/mysql#1782</a></li>
<li>Bump actions/setup-go from 6.5.0 to 7.0.0 in the all-dependencies group by <a href="https://github.com/dependabot"><code>@​dependabot</code></a>[bot] in <a href="https://redirect.github.com/go-sql-driver/mysql/pull/1783">go-sql-driver/mysql#1783</a></li>
<li>Bump the all-dependencies group across 1 directory with 5 updates by <a href="https://github.com/dependabot"><code>@​dependabot</code></a>[bot] in <a href="https://redirect.github.com/go-sql-driver/mysql/pull/1791">go-sql-driver/mysql#1791</a></li>
<li>Bump the all-dependencies group with 3 updates by <a href="https://github.com/dependabot"><code>@​dependabot</code></a>[bot] in <a href="https://redirect.github.com/go-sql-driver/mysql/pull/1794">go-sql-driver/mysql#1794</a></li>
<li>Bump the all-dependencies group with 5 updates by <a href="https://github.com/dependabot"><code>@​dependabot</code></a>[bot] in <a href="https://redirect.github.com/go-sql-driver/mysql/pull/1795">go-sql-driver/mysql#1795</a></li>
<li>Bump the all-dependencies group with 3 updates by <a href="https://github.com/dependabot"><code>@​dependabot</code></a>[bot] in <a href="https://redirect.github.com/go-sql-driver/mysql/pull/1796">go-sql-driver/mysql#1796</a></li>
<li>codeql: remove custom workflow by <a href="https://github.com/methane"><code>@​methane</code></a> in <a href="https://redirect.github.com/go-sql-driver/mysql/pull/1799">go-sql-driver/mysql#1799</a></li>
<li>doc: clarify timeTruncate units and when to use it by <a href="https://github.com/milanobrtlik"><code>@​milanobrtlik</code></a> in <a href="https://redirect.github.com/go-sql-driver/mysql/pull/1792">go-sql-driver/mysql#1792</a></li>
<li>release v1.10.1 by <a href="https://github.com/methane"><code>@​methane</code></a> in <a href="https://redirect.github.com/go-sql-driver/mysql/pull/1801">go-sql-driver/mysql#1801</a></li>
</ul>
<h2>New Contributors</h2>
<ul>
<li><a href="https://github.com/c-tonneslan"><code>@​c-tonneslan</code></a> made their first contribution in <a href="https://redirect.github.com/go-sql-driver/mysql/pull/1770">go-sql-driver/mysql#1770</a></li>
<li><a href="https://github.com/oha-4"><code>@​oha-4</code></a> made their first contribution in <a href="https://redirect.github.com/go-sql-driver/mysql/pull/1782">go-sql-driver/mysql#1782</a></li>
<li><a href="https://github.com/milanobrtlik"><code>@​milanobrtlik</code></a> made their first contribution in <a href="https://redirect.github.com/go-sql-driver/mysql/pull/1792">go-sql-driver/mysql#1792</a></li>
</ul>
<p><strong>Full Changelog</strong>: <a href="https://github.com/go-sql-driver/mysql/compare/v1.10.0...v1.10.1">https://github.com/go-sql-driver/mysql/compare/v1.10.0...v1.10.1</a></p>
</blockquote>
</details>
<details>
<summary>Changelog</summary>
<p><em>Sourced from <a href="https://github.com/go-sql-driver/mysql/blob/master/CHANGELOG.md">github.com/go-sql-driver/mysql's changelog</a>.</em></p>
<blockquote>
<h2>v1.10.1 (2026-09-02)</h2>
<ul>
<li>
<p>Fix <code>Config.FormatDSN()</code> dropping <code>Addr</code> when <code>Net</code> is empty.
It now uses the default <code>tcp</code> network so configs with only <code>Addr</code> round-trip correctly. (<a href="https://redirect.github.com/go-sql-driver/mysql/issues/1770">#1770</a>)</p>
</li>
<li>
<p>Fix typed-nil <code>json.RawMessage</code> with <code>interpolateParams=true</code> being interpolated as an empty string.
It is now interpolated as SQL <code>NULL</code>, matching server-side prepared statements. (<a href="https://redirect.github.com/go-sql-driver/mysql/issues/1782">#1782</a>)</p>
</li>
<li>
<p>Add MariaDB 11.8 and 12.3 to the test matrix. (<a href="https://redirect.github.com/go-sql-driver/mysql/issues/1774">#1774</a>)</p>
</li>
</ul>
</blockquote>
</details>
<details>
<summary>Commits</summary>
<ul>
<li><a href="https://github.com/go-sql-driver/mysql/commit/7ca26e801d130be8be84c1e265be71784f6f70c1"><code>7ca26e8</code></a> release v1.10.1 (<a href="https://redirect.github.com/go-sql-driver/mysql/issues/1801">#1801</a>)</li>
<li><a href="https://github.com/go-sql-driver/mysql/commit/87dcb95da72a8ffd525d41455a0f3ec2465b1d92"><code>87dcb95</code></a> doc: clarify timeTruncate units and when to use it (<a href="https://redirect.github.com/go-sql-driver/mysql/issues/1792">#1792</a>)</li>
<li><a href="https://github.com/go-sql-driver/mysql/commit/1d9c421d1abaed4aeaf0b5ab830de9b752189f1f"><code>1d9c421</code></a> codeql: remove custom workflow (<a href="https://redirect.github.com/go-sql-driver/mysql/issues/1799">#1799</a>)</li>
<li><a href="https://github.com/go-sql-driver/mysql/commit/532b8e566f23712db8f5b978103802aaa0b098c9"><code>532b8e5</code></a> Bump the all-dependencies group with 3 updates (<a href="https://redirect.github.com/go-sql-driver/mysql/issues/1796">#1796</a>)</li>
<li><a href="https://github.com/go-sql-driver/mysql/commit/fe209ccef7620ffe789efa17e7d2e8e05bc9e3c9"><code>fe209cc</code></a> Bump the all-dependencies group with 5 updates (<a href="https://redirect.github.com/go-sql-driver/mysql/issues/1795">#1795</a>)</li>
<li><a href="https://github.com/go-sql-driver/mysql/commit/03d76c7e07908e255ce62d126d07ede3f2365d86"><code>03d76c7</code></a> Bump the all-dependencies group with 3 updates (<a href="https://redirect.github.com/go-sql-driver/mysql/issues/1794">#1794</a>)</li>
<li><a href="https://github.com/go-sql-driver/mysql/commit/c426bd93799de0f0e094c8f0582872c529d0ed0a"><code>c426bd9</code></a> Bump the all-dependencies group across 1 directory with 5 updates (<a href="https://redirect.github.com/go-sql-driver/mysql/issues/1791">#1791</a>)</li>
<li><a href="https://github.com/go-sql-driver/mysql/commit/416cd99d463949ca51faf4f84d674de2fc1aa54b"><code>416cd99</code></a> Bump actions/setup-go from 6.5.0 to 7.0.0 in the all-dependencies group (<a href="https://redirect.github.com/go-sql-driver/mysql/issues/1783">#1783</a>)</li>
<li><a href="https://github.com/go-sql-driver/mysql/commit/b96d41506ad9d74622faf53364cb92ba9aea2e6c"><code>b96d415</code></a> Interpolate typed-nil json.RawMessage as NULL (<a href="https://redirect.github.com/go-sql-driver/mysql/issues/1782">#1782</a>)</li>
<li><a href="https://github.com/go-sql-driver/mysql/commit/dec193d8a1826fc147a6c0b678b8c7ff5fc36cb0"><code>dec193d</code></a> Bump the all-dependencies group with 3 updates (<a href="https://redirect.github.com/go-sql-driver/mysql/issues/1780">#1780</a>)</li>
<li>Additional commits viewable in <a href="https://github.com/go-sql-driver/mysql/compare/v1.10.0...v1.10.1">compare view</a></li>
</ul>
</details>
<br />

Updates `github.com/yuin/goldmark` from 1.8.5 to 1.8.6
<details>
<summary>Release notes</summary>
<p><em>Sourced from <a href="https://github.com/yuin/goldmark/releases">github.com/yuin/goldmark's releases</a>.</em></p>
<blockquote>
<h2>v1.8.6</h2>
<ul>
<li>fix(extension): fix <a href="https://redirect.github.com/yuin/goldmark/issues/571">#571</a></li>
<li>Merge pull request <a href="https://redirect.github.com/yuin/goldmark/issues/569">#569</a></li>
</ul>
</blockquote>
</details>
<details>
<summary>Commits</summary>
<ul>
<li><a href="https://github.com/yuin/goldmark/commit/e3e8a533aa19da2f296fcdb97b7674ae7d1d93a4"><code>e3e8a53</code></a> Merge pull request <a href="https://redirect.github.com/yuin/goldmark/issues/569">#569</a> from binggao1230/fix-urlescape-percent-hex-guard</li>
<li><a href="https://github.com/yuin/goldmark/commit/87012573fb5b188bf77d775152d0bcab42c19212"><code>8701257</code></a> Merge pull request <a href="https://redirect.github.com/yuin/goldmark/issues/570">#570</a> from BananaJeanss/patch-1</li>
<li><a href="https://github.com/yuin/goldmark/commit/c52d4b371dec17dbf2b5992c6b9f15f93f424fee"><code>c52d4b3</code></a> fix(extension): fix <a href="https://redirect.github.com/yuin/goldmark/issues/571">#571</a></li>
<li><a href="https://github.com/yuin/goldmark/commit/37b454c7fb6211b7593457eb7c63fb07c3078edf"><code>37b454c</code></a> Remove Go Report Card badge</li>
<li><a href="https://github.com/yuin/goldmark/commit/72f79b96fe319810dd95aa9e59a1212277d8419d"><code>72f79b9</code></a> fix: URLEscape dropped a truncated utf8 leading byte</li>
<li><a href="https://github.com/yuin/goldmark/commit/67a4ecf9a2ffaba9c678b0fec9914a9c377f2476"><code>67a4ecf</code></a> fix: URLEscape validated the same hex digit twice</li>
<li>See full diff in <a href="https://github.com/yuin/goldmark/compare/v1.8.5...v1.8.6">compare view</a></li>
</ul>
</details>
<br />

Updates `golang.org/x/crypto` from 0.55.0 to 0.56.0
<details>
<summary>Commits</summary>
<ul>
<li><a href="https://github.com/golang/crypto/commit/86efde54dc7069251a8b007026c500d28e4239ce"><code>86efde5</code></a> ssh: reject unexpected message types on established channels</li>
<li><a href="https://github.com/golang/crypto/commit/a6cdac60840750226b15617ac8858be44361b36b"><code>a6cdac6</code></a> ssh: drop traffic on undecided channels</li>
<li><a href="https://github.com/golang/crypto/commit/39dc44e69c280a6254fa09ce85477455efeaf6a2"><code>39dc44e</code></a> ssh: don't skip the source-address critical option in CheckCert</li>
<li><a href="https://github.com/golang/crypto/commit/afebf4cb4efb2b854282e03160da67120707f8f7"><code>afebf4c</code></a> x509roots/fallback/bundle: make subjectsEqual stricter on Go 1.27+</li>
<li><a href="https://github.com/golang/crypto/commit/89f4e9bb5b38861a69b1b26890a6833138d35ace"><code>89f4e9b</code></a> x509roots/fallback: update bundle</li>
<li><a href="https://github.com/golang/crypto/commit/71488c48c2dfecf900e52caa55f88ef4fef62d54"><code>71488c4</code></a> ssh/knownhosts: compare only public key portions for revocation</li>
<li><a href="https://github.com/golang/crypto/commit/82adefa711cb8d9a1f12c7ea91b491007d21819f"><code>82adefa</code></a> ssh: synchronize unexpected response test</li>
<li><a href="https://github.com/golang/crypto/commit/c757c9851f77c470645455f548046ae0ce87ef8d"><code>c757c98</code></a> all: upgrade go directive to at least 1.26.0 [generated]</li>
<li><a href="https://github.com/golang/crypto/commit/593c81af8aa6582d85a7faaeb996396f63d712a9"><code>593c81a</code></a> ssh: correctly ignore pre-banner lines</li>
<li><a href="https://github.com/golang/crypto/commit/46efc8bc62822d876c840e17017ed7071da3087c"><code>46efc8b</code></a> acme: add crypto.SignMessage test coverage</li>
<li>Additional commits viewable in <a href="https://github.com/golang/crypto/compare/v0.55.0...v0.56.0">compare view</a></li>
</ul>
</details>
<br />

Updates `modernc.org/sqlite` from 1.57.0 to 1.58.0
<details>
<summary>Changelog</summary>
<p><em>Sourced from <a href="https://gitlab.com/cznic/sqlite/blob/master/CHANGELOG.md">modernc.org/sqlite's changelog</a>.</em></p>
<blockquote>
<h1>Changelog</h1>
<p>Entries for v1.38.1 through v1.44.1 and for v1.49.1 were added on 2026-09-05, reconstructed from the git history and the merge requests they cite; they were missing at release time.</p>
<ul>
<li>
<p>2026-09-05 v1.59.0:</p>
<ul>
<li>Hand user-defined function and aggregate callbacks a pooled <code>*FunctionContext</code> instead of allocating a fresh one per call. After the <code>[]driver.Value</code> pooling of <a href="https://gitlab.com/cznic/sqlite/-/work_items/226">#226</a> this was the last driver-side heap allocation per invocation: one 16-byte object for every <code>Scalar</code>, <code>Step</code>, <code>WindowInverse</code>, <code>WindowValue</code> and <code>Final</code> call. The context now also carries the invocation's <code>sqlite3_context</code>, so accessor methods can be added to it later without touching the trampolines. Like the argument slice, it is valid only for the duration of the callback and must not be retained past its return; the documentation on <code>FunctionContext</code> and on the callbacks now says so. On the 1000-row, 3-argument noop scalar UDF benchmark this removes a further 1000 allocs/op (5756 to 4756, and 3756 to 2756 with <code>VolatileArgs</code>) and 16 KB/op; on the reporter's reproducer from <a href="https://gitlab.com/cznic/sqlite/-/work_items/226">#226</a> it removes about 12% of the remaining allocations (25.3M to 22.4M allocs/op, 553 MB to 505 MB per iteration).</li>
<li>Updates [GitLab issue <a href="https://gitlab.com/cznic/sqlite/-/work_items/226">#226</a>](<a href="https://gitlab.com/cznic/sqlite/-/issues/226">https://gitlab.com/cznic/sqlite/-/issues/226</a>). See [GitLab merge request <a href="https://gitlab.com/cznic/sqlite/-/work_items/137">#137</a>](<a href="https://gitlab.com/cznic/sqlite/-/merge_requests/137">https://gitlab.com/cznic/sqlite/-/merge_requests/137</a>).</li>
</ul>
</li>
<li>
<p>2026-09-01 v1.58.0:</p>
<ul>
<li>Upgrade to <a href="https://sqlite.org/releaselog/3_53_4.html">SQLite 3.53.4</a>. Upstream's own fix for the journal-rollback data-corruption bug is part of this release, so the local super-journal patch v1.56.0 introduced — and promised to drop once upstream shipped theirs — is dropped; recovery behavior is unchanged. This also bumps the pinned <code>modernc.org/libc</code> to v1.75.6; as always, downstream modules must pin the exact <code>modernc.org/libc</code> version this module's <code>go.mod</code> pins (see [GitLab issue <a href="https://gitlab.com/cznic/sqlite/-/work_items/177">#177</a>](<a href="https://gitlab.com/cznic/sqlite/-/issues/177">https://gitlab.com/cznic/sqlite/-/issues/177</a>)).</li>
<li>Add opt-in support for <strong>Linux Open File Description (OFD) locks</strong> on database files. A POSIX record lock is owned by the (process, inode) pair, so the kernel drops every lock the process holds on a database file whenever any descriptor of that file is closed: an <code>os.Open</code>/<code>Close</code> for a hash, a backup check or a metadata probe anywhere in the process — third-party libraries included — silently strips SQLite's transaction locks and leaves the file unprotected against other processes. With OFD locking enabled, the locks belong to the open file description that placed them and survive such a close. <strong>Off by default, and staying off until the mode has real-world mileage</strong>: without opting in, locking behavior is byte-for-byte that of previous releases. Enable it by setting <code>MODERNC_SQLITE_OFD_LOCK=1</code> in the environment the process starts with (any value but the empty string or one starting with <code>0</code>; read once, at library initialization), or from Go with the new <code>OFDLocking(true)</code>, which overrides the variable and must run before the first connection is opened; <code>OFDLockingEnabled</code> reports the mode in effect. The switch is deliberately <strong>process-wide rather than a DSN parameter</strong>: POSIX and OFD locks taken by one process are different owners to the kernel and genuinely conflict, so every connection to a database file inside one process must use the same kind, and a per-DSN knob would advertise a granularity the kernel does not offer (see the discussion in <a href="https://gitlab.com/cznic/sqlite/-/work_items/255">#255</a>). Because the two kinds do not release one another, the mode is frozen at the process's first lock attempt: later attempts to change it return the new <code>ErrOFDLockingTooLate</code>, while querying, and setting the value already in effect, keep working. On kernels older than 3.15, and on filesystems that reject OFD locks, the first lock attempt falls back to POSIX locks for good and <code>OFDLocking</code> returns the new <code>ErrOFDLockingUnavailable</code> from then on, which is also how <code>OFDLockingEnabled</code> turning false reports the fallback; the same error is returned on every platform but Linux, where the API exists but OFD locks do not. Two boundaries to note: the immunity covers the locks on the database file itself, while WAL's <code>-shm</code> coordination stays on POSIX locks; and code in the same process that takes fcntl record locks of its own on a database file — which used to never conflict with SQLite's, while quietly destroying them — now conflicts with them loudly instead. The C side — <code>F_OFD_SETLK</code> routing through a designated per-inode locking descriptor that preserves upstream's <code>unixInodeInfo</code> semantics (last-unlocker release, PENDING piggybacking, <code>unix-excl</code>), guarded to <code>__linux__</code> — ships in the transpiled sources via <a href="https://gitlab.com/cznic/libsqlite3/-/merge_requests/3">libsqlite3!3</a> and its follow-up hardening, with the OFD lock constants from <a href="https://gitlab.com/cznic/libc/-/merge_requests/33">libc!33</a>; the review rounds, the <code>/proc/locks</code> measurements behind the design, and the Tcl lock/WAL gate that runs both modes are recorded in [GitLab issue <a href="https://gitlab.com/cznic/sqlite/-/work_items/255">#255</a>](<a href="https://gitlab.com/cznic/sqlite/-/issues/255">https://gitlab.com/cznic/sqlite/-/issues/255</a>) and those merge requests.</li>
<li>Add the accompanying regression tests. The four OFD scenarios contributed in merge request <a href="https://gitlab.com/cznic/sqlite/-/work_items/136">#136</a> — lock survival across a rogue <code>os.Close</code>, the interleaved-readers lock lifecycle, the read-only-first designated-descriptor migration, and the failed-first-lock cleanup — run in a re-executed child process with <code>MODERNC_SQLITE_OFD_LOCK=1</code>, since the mode is process-wide and frozen at the first lock so the suite's own process cannot switch; a positive control asserts the variable really switched the mode on before each scenario runs, and the two scenarios whose invariants hold under both modes also run in the parent process's inherited mode. <code>TestOFDLockingSetter</code> exercises the Go call path end to end in a clean child — off by default, enabled before the first connection, the kernel-visible <code>OFDLCK</code> record in <code>/proc/locks</code> as the positive control, frozen after the first lock — and on every other platform the switch is asserted to report itself unavailable.</li>
<li>Resolves [GitLab issue <a href="https://gitlab.com/cznic/sqlite/-/work_items/255">#255</a>](<a href="https://gitlab.com/cznic/sqlite/-/issues/255">https://gitlab.com/cznic/sqlite/-/issues/255</a>). See [GitLab merge request <a href="https://gitlab.com/cznic/sqlite/-/work_items/136">#136</a>](<a href="https://gitlab.com/cznic/sqlite/-/merge_requests/136">https://gitlab.com/cznic/sqlite/-/merge_requests/136</a>), thanks Nathan Herring (<a href="https://gitlab.com/technosloth"><code>@​technosloth</code></a>), and thanks Gani Georgiev (<a href="https://gitlab.com/ganigeorgiev"><code>@​ganigeorgiev</code></a>) for pressing the opt-in default!</li>
</ul>
</li>
<li>
<p>2026-08-19 v1.57.0:</p>
<ul>
<li>Add an opt-in <code>_defensive</code> DSN query parameter that turns on SQLite's defensive mode for the connection, disabling the SQL-level features that let ordinary statements deliberately corrupt the database file. When <code>_defensive=1</code> (or any <code>strconv.ParseBool</code> true value) is supplied, the driver calls <code>sqlite3_db_config</code> with <code>SQLITE_DBCONFIG_DEFENSIVE</code> immediately after <code>sqlite3_open_v2</code> and before every other parameter is applied, so the PRAGMAs the driver itself runs, the <code>_pragma</code> list, and every statement the caller prepares are all subject to it. On such a connection <code>PRAGMA writable_schema=ON</code>, <code>PRAGMA journal_mode=OFF</code> and <code>PRAGMA schema_version=N</code> become silent no-ops, and writes to a virtual table's shadow tables (fts5's <code>_data</code>, <code>_idx</code> and so on) and to <code>sqlite_dbpage</code> fail with &quot;table ... may not be modified&quot;; reading those tables, ordinary use of the virtual tables that own them, and <code>VACUUM</code> are unaffected. The flag has no PRAGMA equivalent, so <code>sqlite3_db_config</code> — and therefore a DSN parameter — is the only way to reach it short of dropping to <code>modernc.org/sqlite/lib</code>. The value is parsed before <code>sqlite3_open_v2</code>, so an invalid one fails the connection without creating the database file, and the parameter must appear at most once: a repeated <code>_defensive</code> is an error rather than letting the first value silently win. Absence of the parameter, or <code>_defensive=0</code>, leaves SQLite's default behavior unchanged; existing DSNs continue to work byte-for-byte. Two limits are worth stating plainly, since the name invites more confidence than the flag earns. Defensive mode is a hardening measure, not a sandbox for hostile database files: it is one of several steps <a href="https://www.sqlite.org/security.html">SQLite recommends</a> for that purpose, and this build compiles with neither <code>SQLITE_TRUSTED_SCHEMA=0</code> nor <code>SQLITE_DQS=0</code> and exposes no authorizer. And it is a property of the connection, not of the database file — a second handle opened on the same file without the parameter is unrestricted.</li>
<li>Reject the one DSN combination defensive mode would otherwise swallow in silence. <code>_defensive=1</code> together with <code>_journal_mode=OFF</code> (or <code>_journal=OFF</code>) now fails the connection instead of opening one in which neither parameter was honoured: SQLite turns <code>PRAGMA journal_mode=OFF</code> into a no-op that still reports success, so the driver would have accepted the mode, executed it, and left the journal untouched without telling anyone. The check runs in the validation phase introduced in v1.55.0, before any statement executes, so a rejected DSN cannot leave the database half-configured. <code>_pragma</code> remains the exception it has always been: <code>_pragma=journal_mode(OFF)</code> alongside <code>_defensive=1</code> still runs and is still silently ignored by SQLite. Only DSNs using <code>_defensive</code> can be affected, and that parameter is new, so no DSN that opened before changes behavior.</li>
<li>See [GitHub pull request <a href="https://gitlab.com/cznic/sqlite/-/work_items/6">#6</a>](<a href="https://redirect.github.com/modernc-org/sqlite/pull/6">modernc-org/sqlite#6</a>), thanks wsman!</li>
<li>Ship the sqlite-vec license notice this module has been missing. <code>modernc.org/sqlite/vec</code> has bundled the transpiled <a href="https://github.com/asg017/sqlite-vec">sqlite-vec</a> sources since v1.47.0, but the module carried only its own BSD-3-Clause <code>LICENSE</code> and the public-domain SQLite notice. sqlite-vec is Copyright (c) 2024 Alex Garcia, dual-licensed Apache-2.0 OR MIT and used here under MIT, whose terms require the copyright and permission notice to accompany substantial portions of the software — which 2.8 MB of transpiled <code>vec/</code> plainly is. The notice now ships as <code>LICENSE-SQLITE_VEC</code> in the module root, byte-identical to the <code>LICENSE-MIT</code> in the upstream v0.1.9 archive and named after the file <code>modernc.org/libsqlite_vec</code> extracts it into. Attribution was never absent — <code>vec</code>'s package documentation has named the extension, pinned the version and linked upstream — but the license text itself was, and the omission was ours: <code>vendor_libs/main.go</code> copied the per-target transpiles and nothing else. It now copies the notice alongside them and fails the vendoring run if it cannot, so a <code>make vendor</code> can no longer quietly drop it. The <code>vec</code> package documentation gained a License section recording that the package is under a different license from the rest of this module.</li>
<li><strong>The SQLite notice is renamed from <code>SQLITE-LICENSE</code> to <code>LICENSE-SQLITE</code></strong>; update any direct links to it. Its contents are unchanged and SQLite remains public domain. The name now matches both the new <code>LICENSE-SQLITE_VEC</code> beside it and the <code>LICENSE-&lt;upstream&gt;</code> convention every other modernc.org repository follows, but it is more than cosmetic: <code>go mod vendor</code> selects the files it copies into a downstream <code>vendor/</code> tree by matching each name against a fixed list of prefixes — <code>LICENSE</code> among them — so a name merely <em>ending</em> in <code>LICENSE</code> was never propagated. Both bundled notices now travel with the code into vendored builds, which is where the MIT terms on <code>vec/</code> keep applying. No code changes; no behavior changes.</li>
<li>Let a caller-constructed <code>Driver</code> register its own functions, collations and virtual table modules. <code>Driver</code> has always held four categories of registration state, but only <code>RegisterConnectionHook</code> could put anything on a constructed one: functions and collations were reachable through the package-level API alone, and modules through the package-level driver only, which left the <code>modules</code> field written and read through that instance and so process-global state wearing a per-instance field. <code>Driver</code> now has <code>RegisterFunction</code>, <code>RegisterScalarFunction</code>, <code>RegisterDeterministicScalarFunction</code>, <code>RegisterCollationUtf8</code> and <code>RegisterModule</code>, plus <code>Must*</code> variants of the first four, each registering on that <code>Driver</code> alone; the methods are safe to call concurrently, and the zero <code>Driver</code> is ready to use as-is. <code>vtab.RegisterModule</code> also honours its <code>db</code> argument now: a non-nil <code>db</code> registers on the driver backing it when that driver implements the new <code>vtab.ModuleRegisterer</code>, while a nil <code>db</code> keeps targeting the driver this package registers as <code>sqlite</code>. One existing pattern changes behavior, narrowly and loudly: <code>vtab.RegisterModule(db, ...)</code> where <code>db</code> was opened on a caller-constructed <code>Driver</code> used to discard the <code>db</code> argument and land on the <code>sqlite</code> driver, reaching every connection in the process; it now lands on the constructed driver alone, so a <code>sql.Open(&quot;sqlite&quot;)</code> connection that used to resolve such a module gets <code>no such module</code> instead. The same pattern is also the one way an existing program could hold one module name on both a constructed <code>Driver</code> and the package-level one: there the first of the two registrations used to win and the second was refused as already registered, whereas now the package-level implementation wins on the constructed <code>Driver</code>'s connections regardless of the order they ran in. Reaching that case at all means the program ignored an error the older version returned. Two smaller deviations round out the list: <code>Driver.RegisterModule</code> reports no error for such a collision, and <code>vtab.RegisterModule</code> now validates its name and module arguments before the not-implemented check, so a call with an empty name that returned <code>vtab: RegisterModule not wired into engine</code> outside this driver returns <code>vtab: module name must be non-empty</code> instead. Everything else is additive against v1.56.0: the package-level registration functions target the same driver they always did, connections still receive every module registered through the package-level path whichever <code>Driver</code> opened them, and a <code>db</code> opened on the <code>sqlite</code> driver resolves to that same driver. The isolating change discussed in [GitLab issue <a href="https://gitlab.com/cznic/sqlite/-/work_items/254">#254</a>](<a href="https://gitlab.com/cznic/sqlite/-/issues/254">https://gitlab.com/cznic/sqlite/-/issues/254</a>) is deliberately not made here.</li>
<li>See [GitLab merge request <a href="https://gitlab.com/cznic/sqlite/-/work_items/135">#135</a>](<a href="https://gitlab.com/cznic/sqlite/-/merge_requests/135">https://gitlab.com/cznic/sqlite/-/merge_requests/135</a>), thanks Ian Chechin!</li>
<li>Promote <code>freebsd/386</code>, <code>freebsd/arm</code> and <code>netbsd/amd64</code> to fully supported platforms. All three are now listed in the package documentation's platform table, which had carried seventeen entries while this module shipped, cross-built and tested twenty. They arrived as <strong>experimental</strong> in v1.53.0 — <code>netbsd/amd64</code> reviving a port that had been broken for years, <code>freebsd/386</code> replacing a stale, effectively untested SQLite 3.41 transpile, and <code>freebsd/arm</code> entirely new — and were deliberately kept out of that table until they had accumulated real-world exposure, with promotion promised once &quot;a period of broader real-world testing … elapses without surprises&quot;. That period has elapsed: all three have been in the builder test matrix and in <code>make build_all_targets</code> since v1.53.0, all three pass the full test suite on this release's commit alongside the seventeen platforms already listed, and no open issue reports a defect in any of them. The two <code>netbsd/amd64</code> build failures filed before the revival, [GitLab issue <a href="https://gitlab.com/cznic/sqlite/-/work_items/202">#202</a>](<a href="https://gitlab.com/cznic/sqlite/-/issues/202">https://gitlab.com/cznic/sqlite/-/issues/202</a>) and [GitLab issue <a href="https://gitlab.com/cznic/sqlite/-/work_items/234">#234</a>](<a href="https://gitlab.com/cznic/sqlite/-/issues/234">https://gitlab.com/cznic/sqlite/-/issues/234</a>), no longer reproduce at this commit: <code>Xsqlite3_is_interrupted</code> is present in the sources that target selects, and the <code>mu.enter</code>/<code>mu.leave</code> symbols that broke the build are gone. Documentation only — the transpiled sources under <code>lib/</code> are byte-for-byte what v1.56.0 shipped, and nothing about how these targets behave changes.</li>
</ul>
</li>
<li>
<p>2026-08-03 v1.56.0:</p>
<ul>
<li>Re-vendor the transpiled SQLite sources, picking up <code>modernc.org/libsqlite3</code>'s fix for an upstream <strong>data-corruption bug in SQLite 3.53.3's journal rollback</strong>. The SQLite version is unchanged at <a href="https://sqlite.org/releaselog/3_53_3.html">3.53.3</a>; what changes is that the amalgamation is now patched before it is transpiled. 3.53.3 reworked <code>readSuperJournal()</code> to return the super-journal name through a <code>char**</code> out-parameter, and <code>pager_playback()</code> now tests that pointer where it used to test <code>zSuper[0]</code>. A crash during the commit of a multi-database (ATTACH) transaction can leave the super-journal name and its checksum zeroed while the name length and the trailing magic survive; the checksum is a plain byte sum, so an all-zero name still validates and <code>readSuperJournal()</code> hands back a non-NULL pointer to an empty string. <code>pager_playback()</code> then calls <code>sqlite3OsAccess(pVfs, &quot;&quot;, SQLITE_ACCESS_EXISTS)</code>, gets ENOENT, and deletes the hot journal without playing it back — leaving the database corrupted. This is not a transpilation artifact: a plain gcc build of the stock 3.53.3 amalgamation fails on the same bytes while 3.53.2 recovers them, and it is what has been making upstream's own <code>test/crash.test</code> fail intermittently, in roughly 2% of runs, on every platform. The patch restores the pre-3.53.3 behaviour of reporting a <code>(nul)</code> super-journal name and will be dropped once upstream ships its own fix. Every supported target carries it.</li>
<li>Two targets change beyond that patch. On <code>linux/s390x</code> the regenerated transpile allocates C bit-fields MSB-first, as the big-endian platform ABI requires, rather than LSB-first; this comes from <code>modernc.org/cc/v4</code> v4.29.1 and touches bit-field accesses throughout the SQLite core, s390x being this module's only big-endian target. On <code>linux/riscv64</code> the transpile was regenerated on a host running GCC 11.4.0 where the previous one used GCC 13.3.0, which drops a handful of unexported compiler-predefined macro constants (the <code>__FLT16_*</code> family, <code>__DBL_IS_IEC_60559__</code> and friends) and changes the <code>COMPILER=gcc-13.3.0</code> entry <code>PRAGMA compile_options</code> reports to <code>COMPILER=gcc-11.4.0</code>; no SQLite code generation differs. Every other target's generated code is byte-identical to v1.55.0 apart from the journal-rollback patch above.</li>
<li>Bump the pinned <code>modernc.org/libc</code> to v1.74.4, and the remaining dependencies to their current releases. v1.74.2 and v1.74.3 are retracted upstream — a <code>freeaddrinfo</code> lock leak that deadlocks name resolution — and v1.74.4 is the fix. As always, downstream modules must pin the exact <code>modernc.org/libc</code> version this module's <code>go.mod</code> pins (see [GitLab issue <a href="https://gitlab.com/cznic/sqlite/-/work_items/177">#177</a>](<a href="https://gitlab.com/cznic/sqlite/-/issues/177">https://gitlab.com/cznic/sqlite/-/issues/177</a>)).</li>
<li>Documentation sweep. <code>openbsd/amd64</code> and <code>openbsd/arm64</code> join the supported platforms table in the package documentation: both have been in the builder test matrix since January and are cross-built by <code>make build_all_targets</code>, but had never been listed. The <code>vfs</code> DSN query parameter — which names a VFS registered with SQLite, such as one returned by <code>vfs.New</code> — is now documented alongside the other DSN parameters on <code>Driver.Open</code>. The &quot;Debug and development versions&quot; section no longer describes a <code>GO_GENERATE</code> environment variable and a <code>go generate</code> that this repository has not had since <code>generator.go</code> moved to <code>modernc.org/libsqlite3</code>; it now points at that repository and <code>make vendor</code> instead, and the stale <code>//go:generate</code> directive naming the removed file is dropped with it. <code>modernc.org/sqlite/vec</code> and <code>modernc.org/sqlite/vfs</code> gained the package doc comments they were missing, so both finally carry a synopsis on pkg.go.dev. Documentation only; no behavior changes.</li>
<li>Add <code>NewConnector</code>, returning a <code>database/sql/driver.Connector</code> for use with <code>sql.OpenDB</code>. It opens the same connections <code>sql.Open(&quot;sqlite&quot;, dsn)</code> does, from the same registered driver, so every function, collation, connection hook and virtual table module registered through this package applies to them. It exists for callers that need to interpose on the physical connections <code>database/sql</code> opens — tracing, metrics, connection-scoped setup — which <code>sql.Open</code> gives no access to: such a caller can embed the returned <code>Connector</code>, override <code>Connect</code>, and pass its own wrapper to <code>sql.OpenDB</code>. Previously the only way to reach the registered driver was the <code>db, _ := sql.Open(&quot;sqlite&quot;, &quot;&quot;); drv := db.Driver(); db.Close()</code> idiom, which works only because <code>sql.Open</code> does not connect and this driver does not implement <code>driver.DriverContext</code>; and the only way to get a wrapper into a <code>*sql.DB</code> was <code>sql.Register</code>, which is process-global, panics on a name it has already seen, and cannot be undone, so a library had to invent a unique driver name per configuration. <code>sql.OpenDB</code> registers nothing. Constructing a <code>&amp;sqlite.Driver{}</code> is not an alternative — its fields are unexported, so it carries none of the registrations. <code>NewConnector</code> checks the DSN only as far as it can without opening a database — a query string that does not parse, and conflicting <code>vfs</code> parameters; everything else continues to be validated when the connection is opened, so an unknown parameter or an out-of-range value is reported by <code>Connect</code> rather than at construction. Nothing about the existing <code>sql.Open</code> path changes: <code>*Driver</code> deliberately still does not implement <code>driver.DriverContext</code>, so <code>sql.Open</code> remains lazy and DSN errors continue to surface where they always have. A runnable sample is in <code>examples/connector</code>. Resolves [GitLab issue <a href="https://gitlab.com/cznic/sqlite/-/work_items/253">#253</a>](<a href="https://gitlab.com/cznic/sqlite/-/issues/253">https://gitlab.com/cznic/sqlite/-/issues/253</a>), thanks Alessandro Segala (<a href="https://gitlab.com/ItalyPaleAle"><code>@​ItalyPaleAle</code></a>)!</li>
<li>Document that a caller-constructed <code>sqlite.Driver</code> is not the driver this package registers as <code>&quot;sqlite&quot;</code>. Its fields are unexported, so it starts with no functions, collations or connection hooks and the only way to give it any is its own <code>RegisterConnectionHook</code> method; the package-level <code>Register*</code> functions always apply to the registered driver. Connections such a <code>Driver</code> opens therefore run without the package-level functions and collations — and because a registered function silently replaces a SQLite built-in of the same name, a <code>Driver</code> you construct can evaluate <code>upper(x)</code>, <code>date(x)</code> and the like differently from one opened through <code>sql.Open</code>. Virtual table modules are the one exception: they are held process-globally and reach every <code>Driver</code>. Constructing one remains supported for the private-hook pattern — a driver registered under a name of its own with <code>sql.Register</code> so its connection hooks apply only to its own connections — and is otherwise best avoided in favour of <code>sql.Open</code> or <code>NewConnector</code>. Documentation only; no behavior changes.</li>
</ul>
</li>
<li>
<p>2026-07-20 v1.55.0:</p>
<ul>
<li>Add <code>github.com/mattn/go-sqlite3</code>-compatible shorthand DSN query parameters to ease migration from that driver: <code>_busy_timeout</code>/<code>_timeout</code>, <code>_foreign_keys</code>/<code>_fk</code>, <code>_journal_mode</code>/<code>_journal</code>, <code>_synchronous</code>/<code>_sync</code>, <code>_auto_vacuum</code>/<code>_vacuum</code>, and <code>_query_only</code>, each setting the correspondingly named PRAGMA. Values are validated against the same set <code>mattn/go-sqlite3</code> accepts (case-insensitive) and an unrecognized value fails the connection with an error, so a typo such as <code>_synchronous=fu1l</code> or <code>_foreign_keys=yes_please</code> is reported rather than silently downgrading durability or dropping foreign-key enforcement. The keys are applied in a fixed order independent of their order in the DSN — <code>_busy_timeout</code> and <code>_auto_vacuum</code> before any <code>_pragma</code> values (<code>auto_vacuum</code> must be set before the database is first written), the rest after, and <code>_query_only</code> last — and where a key and its alias are both supplied the alias wins, matching <code>mattn/go-sqlite3</code>; selection is by presence rather than by value, so supplying the alias empty (<code>_foreign_keys=on&amp;_fk=</code>) suppresses the PRAGMA rather than deferring to the primary key, again matching that driver. Behavior change to note: prior releases ignored these keys entirely, so a DSN carried over from a <code>mattn/go-sqlite3</code> setup changes in two ways. A recognized key that previously did nothing now takes effect — <code>_foreign_keys=on</code> begins enforcing constraints against data that may already violate them, <code>_journal_mode=wal</code> persistently converts the database file, and <code>_query_only=1</code> makes the connection read-only. And a value outside the accepted set now fails the connection with an error where the same DSN previously opened successfully — for example a duration-style <code>_busy_timeout=5s</code> or <code>_timeout=5000ms</code>, neither of which is the integer that key requires. Review such DSNs before upgrading. <code>_pragma</code> is unchanged and no pre-existing parameter changes meaning, though see the following entry for a change in when all of them are validated.</li>
<li>See [GitLab merge request <a href="https://gitlab.com/cznic/sqlite/-/work_items/134">#134</a>](<a href="https://gitlab.com/cznic/sqlite/-/merge_requests/134">https://gitlab.com/cznic/sqlite/-/merge_requests/134</a>), thanks Toni Spets (<a href="https://gitlab.com/beeper-hifi"><code>@​beeper-hifi</code></a>) and Ian Chechin!</li>
<li>Validate every DSN query parameter before applying any of them. Parameters were previously checked as each was reached, so a DSN whose later parameter was rejected had already executed the PRAGMAs ahead of it. Because <code>PRAGMA journal_mode</code> and <code>PRAGMA auto_vacuum</code> are persistent changes to the database file, a DSN such as <code>file:x.db?_journal_mode=wal&amp;_synchronous=bogus</code> failed the connection and yet left <code>x.db</code> converted to WAL. A failed <code>Open</code> now leaves the database as it found it. This covers the pre-existing <code>_txlock</code>, <code>_timezone</code>, <code>_time_format</code>, <code>_time_integer_format</code>, <code>_inttotime</code> and <code>_texttotime</code> parameters as well as the shorthand keys above: all of them were validated only after the <code>_pragma</code> list had already run, so the same DSN shape — a valid <code>_pragma=journal_mode=wal</code> alongside a misspelled <code>_txlock</code> — converted the file before reporting the error. Only the values accepted for each parameter are unchanged; a DSN that opened successfully before still opens, and one that failed still fails with the same error. <code>_pragma</code> remains the sole exception, since its values are executed verbatim and cannot be checked in advance: a malformed <code>_pragma</code> is still rejected by SQLite as it runs, after any earlier <code>_pragma</code> in the list has taken effect.</li>
</ul>
</li>
<li>
<p>2026-07-15 v1.54.0:</p>
<ul>
<li>Upgrade to <a href="https://sqlite.org/releaselog/3_53_3.html">SQLite 3.53.3</a>. This also bumps the pinned <code>modernc.org/libc</code> to v1.74.1; as always, downstream modules must pin the exact same <code>modernc.org/libc</code> version this module's <code>go.mod</code> pins (see [GitLab issue <a href="https://gitlab.com/cznic/sqlite/-/work_items/177">#177</a>](<a href="https://gitlab.com/cznic/sqlite/-/issues/177">https://gitlab.com/cznic/sqlite/-/issues/177</a>)).</li>
<li>Under the opt-in <code>_texttotime</code> DSN parameter, best-effort parse date-shaped TEXT values from columns SQLite reports with an empty declared type — aggregates and expressions over a date column (<code>MAX(d)</code>, <code>COALESCE(d, ...)</code>, <code>upper(d)</code>, <code>d || ''</code>), subqueries, and typeless real columns (<code>CREATE TABLE t(x)</code>) — into <code>time.Time</code>, instead of delivering them as a raw string that <code>Scan</code> cannot store into a <code>*time.Time</code>. The existing declared <code>DATE</code>/<code>DATETIME</code>/<code>TIME</code>/<code>TIMESTAMP</code> path is unchanged; this only adds the empty-decltype case. The conversion is strictly best-effort: a value that does not parse as a time falls through to the original string, so no <code>Scan</code> that worked before can newly fail. <code>ColumnTypeScanType</code> continues to report <code>string</code> for empty-decltype columns, since the declared type cannot prove the column is temporal. Without <code>_texttotime</code> the behavior is byte-for-byte unchanged. Resolves [GitLab issue <a href="https://gitlab.com/cznic/sqlite/-/work_items/248">#248</a>](<a href="https://gitlab.com/cznic/sqlite/-/issues/248">https://gitlab.com/cznic/sqlite/-/issues/248</a>).</li>
<li>See [GitLab merge request <a href="https://gitlab.com/cznic/sqlite/-/work_items/133">#133</a>](<a href="https://gitlab.com/cznic/sqlite/-/merge_requests/133">https://gitlab.com/cznic/sqlite/-/merge_requests/133</a>), thanks Ian Chechin!</li>
</ul>
</li>
<li>
<p>2026-06-21 v1.53.0:</p>
<ul>
<li>Add <strong>experimental</strong> <code>netbsd/amd64</code> support, resolving the long-standing build break in [GitLab issue <a href="https://gitlab.com/cznic/sqlite/-/work_items/246">#246</a>](<a href="https://gitlab.com/cznic/sqlite/-/issues/246">https://gitlab.com/cznic/sqlite/-/issues/246</a>). This target is intentionally <strong>not yet listed among the supported platforms</strong> in the package documentation: the port had been broken for years and is only now revived, and there is as yet no real-world experience running it under production workloads. Green CI is not the same as battle-tested — so while the full test suite (including the <code>pcache</code> and <code>vec</code> packages and the <code>-race</code> concurrency test) passes on NetBSD 10.1 / Go 1.26.3, and the entire upstream toolchain (<code>libc</code>, <code>cc</code>, <code>ccgo</code>, <code>libz</code>, <code>libtcl8.6</code>, <code>libsqlite3</code>, <code>libsqlite_vec</code>) is green on the NetBSD CI builder, the target is offered for evaluation only. If you run NetBSD, please exercise it with your own workloads and report back via <a href="https://gitlab.com/cznic/sqlite/-/work_items/246">#246</a>; the intent is to promote it to a fully supported platform after a period of broader real-world testing (on the order of a month) elapses without surprises.</li>
<li>Implementation notes: the previously shipped <code>lib/sqlite_netbsd_amd64.go</code> was a stale old-generator transpile that no longer compiled (the <code>mu.enter</code>/<code>mu.leave</code> break in <a href="https://gitlab.com/cznic/sqlite/-/work_items/246">#246</a>); it is replaced by a fresh new-generator transpile consistent with every other platform, and <code>modernc.org/sqlite/vec</code> (sqlite-vec) is vendored and auto-registers on netbsd. Correct operation requires the matching pinned <code>modernc.org/libc</code>, which carries two NetBSD-specific fixes found during this work: the <code>mmap(2)</code> <code>PAD</code>-argument ABI (without it, concurrent WAL access faults with SIGBUS in the WAL-index shared memory) and a working <code>abort(3)</code> (the prior stub left SQLite's crash-recovery <code>writecrash</code> test unable to terminate by signal). As usual, downstream modules must pin the exact <code>modernc.org/libc</code> version this module's <code>go.mod</code> pins.</li>
<li>See [GitLab merge request <a href="https://gitlab.com/cznic/sqlite/-/work_items/82">#82</a>](<a href="https://gitlab.com/cznic/sqlite/-/merge_requests/82">https://gitlab.com/cznic/sqlite/-/merge_requests/82</a>), thanks Leonardo Taccari (<a href="https://gitlab.com/iamleot"><code>@​iamleot</code></a>) and Thomas Klausner (@<em>wiz</em>)!</li>
<li>Add <strong>experimental</strong> <code>freebsd/386</code> and <code>freebsd/arm</code> support. As with the <code>netbsd/amd64</code> target above, these two 32-bit FreeBSD ports are intentionally <strong>not yet listed among the supported platforms</strong> in the package documentation: <code>freebsd/386</code> previously shipped a stale, effectively untested SQLite 3.41 transpile, and <code>freebsd/arm</code> is entirely new, so neither has real-world production mileage yet. Both are now freshly transpiled at SQLite 3.53.2 consistent with every other platform, build cleanly, and pass the full test suite (core, WAL/concurrency, and the <code>vec</code> package) on the FreeBSD CI builders; they are offered for evaluation only. If you run 32-bit FreeBSD, please exercise these targets with your own workloads and report back — the intent is to promote <code>freebsd/386</code>, <code>freebsd/arm</code>, and <code>netbsd/amd64</code> to fully supported platforms in a future release cycle, once a period of broader real-world testing elapses without surprises.</li>
<li>Implementation notes: correct operation on <code>freebsd/arm</code> requires the matching pinned <code>modernc.org/libc</code> (v1.73.4), which fixes the per-arch <code>mmap(2)</code> <code>off_t</code> encoding for 32-bit FreeBSD; without it the WAL shared-memory mapping faults with SIGBUS under concurrent access, the same class of bug found on the netbsd port. As usual, downstream modules must pin the exact <code>modernc.org/libc</code> version this module's <code>go.mod</code> pins.</li>
<li>See [GitLab merge request <a href="https://gitlab.com/cznic/sqlite/-/work_items/119">#119</a>](<a href="https://gitlab.com/cznic/sqlite/-/merge_requests/119">https://gitlab.com/cznic/sqlite/-/merge_requests/119</a>), thanks Olivier Cochard-Labbé (<a href="https://gitlab.com/ocochard"><code>@​ocochard</code></a>)!</li>
<li>Add a Go-facing wrapper for <code>SQLITE_CONFIG_PCACHE2</code>. <code>PageCache</code> is the factory and <code>Cache</code> the per-database instance, both idiomatic Go interfaces; <code>Page</code> exposes the raw <code>Buf</code> and <code>Extra</code> pointers that SQLite reads through the C pcache contract. <code>RegisterPageCache</code> and <code>MustRegisterPageCache</code> install the module process-globally before the first <code>sql.Open</code>; subsequent Open calls are gated through a one-shot <code>Xsqlite3_config(SQLITE_CONFIG_PCACHE2)</code> so a too-late Register returns <code>ErrPageCacheTooLate</code> rather than silently falling through to the built-in pcache1. The binding owns the <code>sqlite3_pcache_page</code> stub and re-consults the implementation on every Fetch, reusing the stub only when the returned <code>Page</code> value is unchanged, which keeps a bounded/evicting purgeable cache safe by construction.</li>
</ul>
</li>
</ul>
<!-- raw HTML omitted -->
</blockquote>
<p>... (truncated)</p>
</details>
<details>
<summary>Commits</summary>
<ul>
<li><a href="https://gitlab.com/cznic/sqlite/commit/722282f38b49191a4e24569eeac960bc033bd8f0"><code>722282f</code></a> CHANGELOG.md: document the OFD locking opt-in and the SQLite 3.53.4 upgrade</li>
<li><a href="https://gitlab.com/cznic/sqlite/commit/5dcac5fbafc8194fd069f61ede3c7efbd482a2ff"><code>5dcac5f</code></a> sqlite: add the opt-in OFDLocking switch to Linux OFD locks</li>
<li><a href="https://gitlab.com/cznic/sqlite/commit/51d267714fcb4ebb2ca0969c3d31815c18fd82fb"><code>51d2677</code></a> Merge branch 'ofd-lock-test'</li>
<li><a href="https://gitlab.com/cznic/sqlite/commit/3f99e260f63ff2de76a94976e3d976ee75a8a4d1"><code>3f99e26</code></a> update dependencies, make vendor</li>
<li><a href="https://gitlab.com/cznic/sqlite/commit/9159fa5ff00bd00f72e6893b71682b3348fa853d"><code>9159fa5</code></a> test: add Linux OFD lock regression tests</li>
<li><a href="https://gitlab.com/cznic/sqlite/commit/2acd716d384a147b8daf1d91507f6346d409deff"><code>2acd716</code></a> test: add Linux OFD lock persistence test across os.Close</li>
<li><a href="https://gitlab.com/cznic/sqlite/commit/bd9dcb65646988cc78aa56effa9a69fd04893478"><code>bd9dcb6</code></a> add Readme Headline...</li>
<li><a href="https://gitlab.com/cznic/sqlite/commit/93f0742ee384d5dbba5e6cd7d49afd0e9604160c"><code>93f0742</code></a> add Readme Headline</li>
<li>See full diff in <a href="https://gitlab.com/cznic/sqlite/compare/v1.57.0...v1.58.0">compare view</a></li>
</ul>
</details>
<br />


Dependabot will resolve any conflicts with this PR as long as you don't alter it yourself. You can also trigger a rebase manually by commenting `@dependabot rebase`.

[//]: # (dependabot-automerge-start)
[//]: # (dependabot-automerge-end)

---

<details>
<summary>Dependabot commands and options</summary>
<br />

You can trigger Dependabot actions by commenting on this PR:
- `@dependabot rebase` will rebase this PR
- `@dependabot recreate` will recreate this PR, overwriting any edits that have been made to it
- `@dependabot show <dependency name> ignore conditions` will show all of the ignore conditions of the specified dependency
- `@dependabot ignore <dependency name> major version` will close this group update PR and stop Dependabot creating any more for the specific dependency's major version (unless you unignore this specific dependency's major version or upgrade to it yourself)
- `@dependabot ignore <dependency name> minor version` will close this group update PR and stop Dependabot creating any more for the specific dependency's minor version (unless you unignore this specific dependency's minor version or upgrade to it yourself)
- `@dependabot ignore <dependency name>` will close this group update PR and stop Dependabot creating any more for the specific dependency (unless you unignore this specific dependency or upgrade to i...

_Description has been truncated_

<!-- catalog-pr-audit -->
Dependency qualification (2026-09-08)

Local commit `3a79fc6` has the same complete Git tree as current PR head `9a642d9`.
Both combine the dependency update with main at `565a4fcd`.

The focused race suite passes 307 test events and six packages.
It covers credentials, cloud chains, SQLite, Markdown parsing, S3 blob operations, and catalog integration.
The initial Valkey contract skip passes in a separate run against a disposable Valkey server.

The AWS tests use the real secret-source factory and SDK against local TLS fixtures.
They cover environment credentials, shared files, precedence, web identity, missing credentials, and denied reads.
These test overlays remain local qualification evidence and do not appear in attached CI.

A SQLite file written with the previous dependencies survives migration and integrity checks under the new dependencies.
MySQL migration, read/write, and transaction rollback contracts pass against separate disposable databases.
The combined MySQL suite exposes the same fixture cleanup failure on both dependency versions.
Its reset deletes the migration ledger but retains application tables, so the next test repeats an ALTER TABLE.
CSP15 owns that existing test-isolation defect before shared-backend qualification.

Module verification and module tidiness pass.
Goldmark serves the Markdown link parser in this repository, which the focused suite covers.
The remaining merge gate is the required CI for the current head.
This dependency merge grants no released-pair or shared-backend production qualification.
