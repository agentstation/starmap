
Dependency qualification (2026-09-08)

Local commit `3a79fc6` has the same complete Git tree as current PR head `9a642d9`.
Both combine the dependency update with main at `565a4fcd`.

The focused race suite passes 307 test events and six packages.
It covers credentials, cloud chains, SQLite, Markdown parsing, S3 blob operations, and catalog integration.
The initial Valkey contract skip passes in a separate run against a disposable Valkey server.

The AWS tests use the real secret-source factory and SDK against local TLS fixtures.
They cover environment credentials, shared files, precedence, web identity, missing credentials, and denied reads.
These test overlays remain local qualification evidence and do not appear in attached CI.

A SQLite file written with the previous dependencies survives migration and integrity checks under the new dependencies.
MySQL migration, read/write, and transaction rollback contracts pass against separate disposable databases.
The combined MySQL suite exposes the same fixture cleanup failure on both dependency versions.
Its reset deletes the migration ledger but retains application tables, so the next test repeats an ALTER TABLE.
CSP15 owns that existing test-isolation defect before shared-backend qualification.

Module verification and module tidiness pass.
Goldmark serves the Markdown link parser in this repository, which the focused suite covers.
The remaining merge gate is the required CI for the current head.
This dependency merge grants no released-pair or shared-backend production qualification.
