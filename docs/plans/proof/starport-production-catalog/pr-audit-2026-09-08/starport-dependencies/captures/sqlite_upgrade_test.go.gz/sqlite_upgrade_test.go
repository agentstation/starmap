package sqlstore

import (
 "os"
 "testing"
)

func TestSQLiteDependencyUpgrade(t *testing.T) {
 path := os.Getenv("CSP_SQLITE_UPGRADE_FILE")
 if path == "" { t.Fatal("fixture path is required") }
 db, err := Open(Config{Type: TypeSQLite, SQLite: SQLiteConfig{Path:path}})
 if err != nil { t.Fatal(err) }
 defer db.Close()
 if err := db.Migrate(t.Context()); err != nil { t.Fatal(err) }
 if os.Getenv("CSP_SQLITE_UPGRADE_MODE") == "write" {
  if _, err := db.ExecContext(t.Context(), "INSERT INTO sqlstore_meta (name,value) VALUES ('upgrade-fixture','preserved-value')"); err != nil { t.Fatal(err) }
  return
 }
 var value string
 if err := db.QueryRowContext(t.Context(), "SELECT value FROM sqlstore_meta WHERE name='upgrade-fixture'").Scan(&value); err != nil { t.Fatal(err) }
 if value != "preserved-value" { t.Fatalf("upgrade value=%q",value) }
 if err := db.Migrate(t.Context()); err != nil { t.Fatal(err) }
 if err := db.QueryRowContext(t.Context(), "PRAGMA integrity_check").Scan(&value); err != nil { t.Fatal(err) }
 if value != "ok" { t.Fatalf("integrity=%q",value) }
}
