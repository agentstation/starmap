import { Button } from "@/components/ui/button";
export function DependencyLintProbe({ value }: { value: string }) {
  return <>
    <svg fill="#123456" />
    <Button className="bg-[#123456] p-[13px] unknown-dependency-probe">Static</Button>
    <Button className={"text-" + value} style={{ color: "red" }}>Dynamic</Button>
  </>;
}
