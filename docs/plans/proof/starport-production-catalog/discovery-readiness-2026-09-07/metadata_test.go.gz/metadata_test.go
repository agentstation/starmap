package audit

import . "github.com/agentstation/starmap/pkg/catalogs"

import "testing"

// TestEnrichMergePreservesManualModelWithoutPricingOrLimits requires valid model membership
// to survive enrichment when optional commercial metadata is absent.
func TestEnrichMergePreservesManualModelWithoutPricingOrLimits(t *testing.T) {
	destination := NewEmpty()
	if err := destination.SetProvider(Provider{ID: "manual", Name: "Manual"}); err != nil {
		t.Fatalf("SetProvider destination: %v", err)
	}

	manualModel := Model{
		ID:          "operator-model",
		ModelRef:    "operator/operator-model",
		Name:        "Operator Model",
		Description: "hand-authored fallback metadata",
	}
	source := NewEmpty()
	if err := source.SetAuthor(Author{ID: "operator", Name: "Operator"}); err != nil {
		t.Fatalf("SetAuthor source: %v", err)
	}
	if err := source.SetAuthorModel("operator", Model{
		ID: "operator-model", Name: "Operator Model",
		Description: "hand-authored fallback metadata",
		Authors:     []Author{{ID: "operator", Name: "Operator"}},
	}); err != nil {
		t.Fatalf("SetAuthorModel source: %v", err)
	}
	if err := source.SetProvider(Provider{
		ID:   "manual",
		Name: "Manual",
		Models: map[string]*Model{
			manualModel.ID: &manualModel,
		},
	}); err != nil {
		t.Fatalf("SetProvider source: %v", err)
	}
	sourceCatalog, err := source.Build()
	if err != nil {
		t.Fatalf("Build source: %v", err)
	}

	if err := destination.MergeWith(sourceCatalog, WithStrategy(MergeEnrichEmpty)); err != nil {
		t.Fatalf("MergeWith: %v", err)
	}
	provider, err := destination.Provider("manual")
	if err != nil {
		t.Fatalf("Provider: %v", err)
	}
	model, exists := provider.Models[manualModel.ID]
	if !exists || model.ModelRef != manualModel.ModelRef || model.Description != manualModel.Description {
		t.Fatal("enrichment dropped a linked model without pricing or limits")
	}
	if _, err := destination.Build(); err != nil {
		t.Fatalf("merged model does not satisfy canonical identity: %v", err)
	}
}

