package proxy

import (
 "testing"
 "github.com/agentstation/starmap"
 "github.com/agentstation/starmap/pkg/catalogs"
 runtimecatalog "github.com/agentstation/starport/internal/catalog"
 "github.com/agentstation/starport/internal/providers"
 providerauth "github.com/agentstation/starport/internal/providers/auth"
 "github.com/agentstation/starport/internal/providers/connectors"
 "github.com/stretchr/testify/require"
)

func auditDiscovery(t *testing.T) (*runtimecatalog.ControlPlane, *proxy, *catalogDiscoveryRuntime) {
 t.Helper()
 client, err := starmap.New(); require.NoError(t, err)
 plane, err := runtimecatalog.Open(client); require.NoError(t, err)
 transports, err := connectors.ProductionTransportRegistry(); require.NoError(t, err)
 auth, err := providerauth.ProductionRegistry(); require.NoError(t, err)
 activations, err := providers.Activate(client.Catalog(), transports, auth, nil); require.NoError(t, err)
 adapters := make([]runtimecatalog.AdapterAvailability, 0, len(activations))
 for _, activation := range activations {
  require.Nil(t, activation.Configuration.CredentialSource)
  adapters = append(adapters, runtimecatalog.AdapterAvailability{ProviderID: activation.ProviderID, Registered: true, Operations: activation.Operations, EndpointTypes: activation.EndpointTypes})
 }
 require.NoError(t, plane.ReplaceAdapters(adapters))
 runtime := &catalogDiscoveryRuntime{snapshot: plane.Current()}
 return plane, &proxy{registry: catalogDiscoveryRegistry{runtime: runtime}}, runtime
}

func TestAuditNoKeysDoNotRemoveCatalogOrStructuralRoutes(t *testing.T) {
 plane, service, runtime := auditDiscovery(t)
 models, err := service.ListModels(t.Context()); require.NoError(t, err); require.NotEmpty(t, models.Data)
 providerList, err := service.ListProviders(t.Context()); require.NoError(t, err); require.NotEmpty(t, providerList.Providers)
 t.Logf("without operator material: %d definitions, %d providers, %d structural routes",len(models.Data),len(providerList.Providers),len(plane.Current().Routes()))
 original := plane.Current()
 require.NoError(t, plane.ReplaceAdapters(nil)); runtime.snapshot = plane.Current()
 after, err := service.ListModels(t.Context()); require.NoError(t, err); require.Empty(t, after.Data)
 require.Equal(t, original.GenerationID(), plane.Current().GenerationID())
 require.NotEqual(t, original.AvailabilityRevision(), plane.Current().AvailabilityRevision())
}

func TestAuditDiscoveryCachesFollowAvailability(t *testing.T) {
 plane, upstream, runtime := auditDiscovery(t)
 source := &cacheRuntimeSource{snapshot: plane.Current()}
 service := &cachedService{service: upstream, runtime: source, cacheManager: newMockCacheManager(), cacheConfig: CacheConfig{EnableModelCache: true, EnableProviderCache: true}}
 models, err := service.ListModels(t.Context()); require.NoError(t, err); require.NotEmpty(t, models.Data)
 providerList, err := service.ListProviders(t.Context()); require.NoError(t, err); require.NotEmpty(t, providerList.Providers)
 modelID := ""
 for _, route := range plane.Current().Routes() {
  if _, found := route.Endpoint(catalogs.ProviderOperationChatCompletions); found { modelID = string(route.DefinitionID); break }
 }
 require.NotEmpty(t, modelID)
 endpoints, err := service.GetModelEndpoints(t.Context(),modelID); require.NoError(t,err);require.NotEmpty(t,endpoints.Endpoints)
 before := plane.Current()
 require.NoError(t,plane.ReplaceAdapters(nil));source.snapshot=plane.Current();runtime.snapshot=plane.Current()
 require.Equal(t,before.GenerationID(),plane.Current().GenerationID());require.NotEqual(t,before.AvailabilityRevision(),plane.Current().AvailabilityRevision())
 rawModels, err := upstream.ListModels(t.Context());require.NoError(t,err);require.Empty(t,rawModels.Data)
 rawProviders, err := upstream.ListProviders(t.Context());require.NoError(t,err);require.Empty(t,rawProviders.Providers)
 rawEndpoints, err := upstream.GetModelEndpoints(t.Context(),modelID);require.NoError(t,err);require.Empty(t,rawEndpoints.Endpoints)
 t.Run("models",func(t *testing.T){value,err:=service.ListModels(t.Context());require.NoError(t,err);require.Empty(t,value.Data,"cached models survived adapter removal")})
 t.Run("providers",func(t *testing.T){value,err:=service.ListProviders(t.Context());require.NoError(t,err);require.Empty(t,value.Providers,"cached providers survived adapter removal")})
 t.Run("endpoints",func(t *testing.T){value,err:=service.GetModelEndpoints(t.Context(),modelID);require.NoError(t,err);require.Empty(t,value.Endpoints,"cached endpoints survived adapter removal")})
}
