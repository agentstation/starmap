package main

import (
 "encoding/json"
 "os"
 "github.com/agentstation/starmap/pkg/catalogs"
)

func baseline() catalogs.Model {
 return catalogs.Model{ID:"example", Pricing:&catalogs.ModelPricing{Currency:"USD", Tokens:&catalogs.ModelTokenPricing{Input:&catalogs.ModelTokenCost{Per1M:1}, Output:&catalogs.ModelTokenCost{Per1M:4}}}}
}

func main() {
 mixed := catalogs.MergeModels(baseline(),catalogs.Model{ID:"example", Pricing:&catalogs.ModelPricing{Currency:"EUR",Tokens:&catalogs.ModelTokenPricing{Input:&catalogs.ModelTokenCost{Per1M:2}}}})
 zero := catalogs.MergeModels(baseline(),catalogs.Model{ID:"example", Pricing:&catalogs.ModelPricing{Currency:"USD",Tokens:&catalogs.ModelTokenPricing{Input:&catalogs.ModelTokenCost{Per1M:0}}}})
 if err:=json.NewEncoder(os.Stdout).Encode(map[string]any{"partial_record":mixed.Pricing,"explicit_zero_fresh_baseline":zero.Pricing});err!=nil {os.Exit(1)}
}
