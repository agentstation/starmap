package catalogs

import (
	"encoding/json"
	"strings"
	"testing"

	"github.com/goccy/go-yaml"
)

func TestNestedOptionalNullRoundTripProbe(t *testing.T) {
	cases := []struct{ name, input, path string }{
		{"knowledge_cutoff", `{"metadata":{"knowledge_cutoff":null}}`, "metadata.knowledge_cutoff"},
		{"lineage_parent", `{"lineage":{"parent":null}}`, "lineage.parent"},
		{"generation_max_tokens", `{"generation":{"max_tokens":null}}`, "generation.max_tokens"},
		{"pricing_input", `{"pricing":{"currency":"USD","tokens":{"input":null}}}`, "pricing.tokens.input"},
		{"pricing_amount", `{"pricing":{"currency":"USD","tokens":{"input":{"per_1m_tokens":null}}}}`, "pricing.tokens.input.per_1m_tokens"},
	}
	for _, tc := range cases {
		for _, format := range []string{"json", "yaml"} {
			t.Run(tc.name+"/"+format, func(t *testing.T) {
				var model Model
				if err := json.Unmarshal([]byte(tc.input), &model); err != nil {
					t.Fatal(err)
				}
				var data []byte
				var err error
				var got map[string]any
				if format == "json" {
					data, err = json.Marshal(model)
					if err == nil {
						err = json.Unmarshal(data, &got)
					}
				} else {
					data, err = yaml.Marshal(model)
					if err == nil {
						err = yaml.Unmarshal(data, &got)
					}
				}
				if err != nil {
					t.Fatal(err)
				}
				path := tc.path
				if format == "yaml" {
					path = strings.ReplaceAll(path, "per_1m_tokens", "per_1m")
				}
				var value any = got
				for part := range strings.SplitSeq(path, ".") {
					object, ok := value.(map[string]any)
					if !ok {
						t.Fatalf("%s has no object before %s: %s", path, part, data)
					}
					value, ok = object[part]
					if !ok {
						t.Fatalf("explicit null disappeared at %s: %s", path, data)
					}
				}
				if value != nil {
					t.Fatalf("explicit null changed at %s to %#v: %s", path, value, data)
				}
			})
		}
	}
}

func TestKnownZeroTokenPriceJSONProbe(t *testing.T) {
	var model Model
	if err := json.Unmarshal([]byte(`{"pricing":{"currency":"USD","tokens":{"input":{"per_token":0,"per_1m_tokens":0}}}}`), &model); err != nil {
		t.Fatal(err)
	}
	data, err := json.Marshal(model)
	if err != nil {
		t.Fatal(err)
	}
	var decoded map[string]any
	if err := json.Unmarshal(data, &decoded); err != nil {
		t.Fatal(err)
	}
	input := decoded["pricing"].(map[string]any)["tokens"].(map[string]any)["input"].(map[string]any)
	if input["per_token"] != float64(0) || input["per_1m_tokens"] != float64(0) {
		t.Fatalf("known zero changed: %s", data)
	}
}
