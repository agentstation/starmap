Catalog generation parameters and range bounds can lose the distinction between omitted, unknown, and known zero values during serialization. This change preserves those states through JSON, YAML, reconciliation, and runtime restart. Generated OpenAPI properties now accept the same null states as the codecs.

The change also adds runtime tests for metadata-only membership and complete pricing authority. Thirty named acceptance checks cover field authority and presence. Eight other CSP3 subcases remain unverified.

Validation:

- The production changes pass all 39 verification stages, including 80 ordinary packages and 80 race packages.
- The final acceptance registry passes 30 named checks, with 712 test pass events across 30 package runs.
- The two additional runtime tests pass six events on Go 1.25.12. The registry verifier passes 73 Python tests.
- Ago and lint report zero findings. The documentation check passes without GOFLAGS. The final prose check passes 1,250 files.

The full verifier inherited an unsupported gomarkdoc flag from GOFLAGS despite its zero exit. A separate documentation check without GOFLAGS passes. CSP3 stays incomplete until all assigned acceptance checks pass against merged code.
