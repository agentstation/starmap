package runtime

import (
	"testing"
	"time"

	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/catalogs/storage"
	"github.com/agentstation/starmap/pkg/sources"
)

func TestPartialFeatureRecoveryKeepsContributingReceipt(t *testing.T) {
	store := storage.NewMemory()
	connected, _, at := providerResetRuntime(t, store)
	observe := func(partial bool) sources.Observation {
		when := at
		feature := catalogs.ModelFeatureTools
		if !partial {
			when = at.Add(time.Minute)
			feature = catalogs.ModelFeatureStreaming
		}
		seed := manualProviderObservation(t, 200, when)
		builder, err := catalogs.NewBuilderFrom(seed.Catalog)
		if err != nil {
			t.Fatal(err)
		}
		provider, err := builder.Provider("provider")
		if err != nil {
			t.Fatal(err)
		}
		provider.Models["model"].Features = &catalogs.ModelFeatures{}
		provider.Models["model"].Features.SetSupport(feature, true)
		if err := builder.SetProvider(provider); err != nil {
			t.Fatal(err)
		}
		catalog, err := catalogs.NewObservationCatalog(builder)
		if err != nil {
			t.Fatal(err)
		}
		metadata := sources.ObservationMetadata{ObservedAt: when, Revision: sources.Revision{Kind: sources.RevisionKindContentDigest}, Completeness: sources.ObservationCompletenessComplete, Status: sources.ObservationStatusSucceeded}
		if partial {
			metadata.Completeness, metadata.Status = sources.ObservationCompletenessPartial, sources.ObservationStatusDegraded
			metadata.Issues = []sources.ObservationIssue{{Scope: sources.ObservationIssueScopeRecord, Code: sources.ObservationIssueCodeInvalidRecord, Subject: "provider/invalid", Message: "A source record is invalid."}}
		}
		observation, err := sources.NewObservation(sources.ProvidersID, catalog, metadata)
		if err != nil {
			t.Fatal(err)
		}
		return observation
	}
	prior := observe(true)
	if _, err := connected.PublishObservations(t.Context(), prior); err != nil {
		t.Fatal(err)
	}
	current := observe(false)
	if _, err := connected.PublishObservations(t.Context(), current); err != nil {
		t.Fatal(err)
	}
	provider, err := connected.State().Catalog.Provider("provider")
	if err != nil {
		t.Fatal(err)
	}
	for _, feature := range []catalogs.ModelFeature{catalogs.ModelFeatureTools, catalogs.ModelFeatureStreaming} {
		value, presence := provider.Models["model"].Features.Support(feature)
		if !value || presence != catalogs.ValueKnown {
			t.Errorf("feature %s = %t/%v, want known true", feature, value, presence)
		}
	}
	generation, err := store.Current(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	found := false
	for _, link := range generation.Manifest.SourceObservations {
		found = found || link.ObservationID == prior.ID
	}
	if !found || !generation.Manifest.Degraded {
		t.Fatalf("partial tools evidence still contributes: receipt=%t degraded=%t", found, generation.Manifest.Degraded)
	}
}
