package runtime

import (
	"errors"
	"testing"
	"time"

	"github.com/agentstation/starmap"
	"github.com/agentstation/starmap/pkg/catalogs/storage"
	pkgerrors "github.com/agentstation/starmap/pkg/errors"
)

func TestStartupWithoutInputsRefusesWithdrawnProviderBinding(t *testing.T) {
	layer := scopedProviderLayer(t, "private-binding", "1", time.Date(2026, 9, 8, 0, 0, 0, 0, time.UTC))
	store := storage.NewMemory()
	first := openTestRuntime(t, WithCatalogSource("embedded"), WithClientOptions(starmap.WithCatalogStore(store)), WithProviderBindings(*layer.Receipt.ProviderBinding))
	if _, err := first.publishProviders(t.Context(), []ProviderLayer{layer}, first.lease.epoch()); err != nil {
		t.Fatal(err)
	}
	if _, err := first.State().Catalog.Provider("provider"); err != nil {
		t.Fatal("fixture did not publish private provider")
	}
	if err := first.Close(); err != nil {
		t.Fatal(err)
	}
	next, err := Open(t.Context(), WithCatalogSource("embedded"), WithClientOptions(starmap.WithCatalogStore(store)), WithAcquisitionEnabled(false), WithSourcePollInterval(0))
	if next != nil {
		_ = next.Close()
	}
	var conflict *pkgerrors.ConflictError
	if !errors.As(err, &conflict) {
		t.Fatalf("Open error=%v, want typed refusal when scoped state has no current declaration or retained inputs", err)
	}
}
