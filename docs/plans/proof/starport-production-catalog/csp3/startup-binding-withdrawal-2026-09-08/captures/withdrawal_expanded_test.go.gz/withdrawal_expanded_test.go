package runtime

import (
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/agentstation/starmap"
	"github.com/agentstation/starmap/pkg/catalogs/storage"
	pkgerrors "github.com/agentstation/starmap/pkg/errors"
	"github.com/agentstation/starmap/server"
)

func TestStartupWithoutInputsRefusesWithdrawnProviderBinding(t *testing.T) {
	store, _ := acceptedScopedStartupStore(t)
	before, err := store.Current(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	next, err := Open(t.Context(), WithStateDirectory(""), WithCatalogSource("embedded"), WithClientOptions(starmap.WithCatalogStore(store)), WithAcquisitionEnabled(false), WithSourcePollInterval(0))
	if next != nil {
		if _, providerErr := next.State().Catalog.Provider("provider"); providerErr == nil {
			t.Error("withdrawn private provider remains available")
		}
		_ = next.Close()
	}
	var conflict *pkgerrors.ConflictError
	if !errors.As(err, &conflict) || next != nil {
		t.Fatalf("Open error=%v, want typed refusal without a runtime", err)
	}
	after, err := store.Current(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	if before.Manifest.GenerationID != after.Manifest.GenerationID || before.Manifest.Payload.Checksum != after.Manifest.Payload.Checksum {
		t.Fatal("refusal changed accepted stored state")
	}
}

func TestStartupRemovedBindingAlignsClientWithRetainedInputs(t *testing.T) {
	store, directory := acceptedScopedStartupStore(t)
	next := openTestRuntime(t, WithStateDirectory(directory), WithCatalogSource("embedded"), WithClientOptions(starmap.WithCatalogStore(store)))
	if _, err := next.State().Catalog.Provider("provider"); err == nil {
		t.Error("withdrawn provider remains in runtime")
	}
	if _, err := next.Client().CurrentCatalogState().Catalog.Provider("provider"); err == nil {
		t.Error("withdrawn provider remains in client")
	}
	retained, err := store.Current(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	if retained.Manifest.GenerationID != next.State().GenerationID || retained.Manifest.Payload.Checksum != next.State().PayloadChecksum {
		t.Error("stored current differs from permitted runtime")
	}
	srv, err := server.New(next.Client(), server.DefaultConfig(), server.WithRuntime(next))
	if err != nil {
		t.Fatal(err)
	}
	response := httptest.NewRecorder()
	srv.Handler().ServeHTTP(response, httptest.NewRequest(http.MethodGet, "/api/v1/providers/provider", nil))
	if response.Code != http.StatusNotFound {
		t.Errorf("HTTP status=%d, want 404 for withdrawn provider", response.Code)
	}
}

func TestStartupExplicitEmptyBindingsDropsStoredScopeWithoutInputs(t *testing.T) {
	store, _ := acceptedScopedStartupStore(t)
	next := openTestRuntime(t, WithStateDirectory(""), WithCatalogSource("embedded"), WithClientOptions(starmap.WithCatalogStore(store)), WithProviderBindings())
	if _, err := next.State().Catalog.Provider("provider"); err == nil {
		t.Fatal("explicit empty policy kept withdrawn provider")
	}
	if next.State().PayloadChecksum != next.Client().CurrentCatalogState().PayloadChecksum {
		t.Fatal("client differs from runtime")
	}
}

func TestStartupUnscopedStoreOnlyCatalogRemainsAvailable(t *testing.T) {
	store := storage.NewMemory()
	options := []Option{WithStateDirectory(""), WithCatalogSource("embedded"), WithClientOptions(starmap.WithCatalogStore(store))}
	first := openTestRuntime(t, options...)
	layer := testProviderLayer(t, "provider", "model", "Model", time.Date(2026, 9, 8, 0, 0, 0, 0, time.UTC))
	if _, err := first.publishProviders(t.Context(), []ProviderLayer{layer}, first.lease.epoch()); err != nil {
		t.Fatal(err)
	}
	accepted := first.State()
	if err := first.Close(); err != nil {
		t.Fatal(err)
	}
	next := openTestRuntime(t, options...)
	if _, err := next.State().Catalog.Provider("provider"); err != nil {
		t.Fatal("permitted unscoped catalog disappeared")
	}
	if next.State().GenerationID != accepted.GenerationID || next.State().PayloadChecksum != accepted.PayloadChecksum {
		t.Fatal("permitted accepted state changed")
	}
}

func acceptedScopedStartupStore(t *testing.T) (*storage.Memory, string) {
	t.Helper()
	layer := scopedProviderLayer(t, "private-binding", "1", time.Date(2026, 9, 8, 0, 0, 0, 0, time.UTC))
	store := storage.NewMemory()
	directory := privateRuntimeDirectory(t)
	first := openTestRuntime(t, WithStateDirectory(directory), WithCatalogSource("embedded"), WithClientOptions(starmap.WithCatalogStore(store)), WithProviderBindings(*layer.Receipt.ProviderBinding))
	if _, err := first.publishProviders(t.Context(), []ProviderLayer{layer}, first.lease.epoch()); err != nil {
		t.Fatal(err)
	}
	if _, err := first.State().Catalog.Provider("provider"); err != nil {
		t.Fatal("fixture did not publish private provider")
	}
	if err := first.Close(); err != nil {
		t.Fatal(err)
	}
	return store, directory
}
