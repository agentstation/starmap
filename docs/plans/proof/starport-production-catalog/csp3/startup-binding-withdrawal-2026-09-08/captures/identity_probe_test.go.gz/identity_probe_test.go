package runtime

import (
	"github.com/agentstation/starmap"
	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/catalogs/storage"
	"testing"
)

// This probe tests a proposed recovery decision, not a production admission API.
func TestLegacyIdentityAloneProvesStartupAdmission(t *testing.T) {
	store, err := storage.NewFilesystem("/tmp/starmap-csp3-legacy/retained-fixture/catalog")
	if err != nil {
		t.Fatal(err)
	}
	client, err := starmap.NewContext(t.Context(), starmap.WithCatalogStore(store))
	if err != nil {
		t.Fatal(err)
	}
	accepted, err := client.CurrentGeneration(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	retained, err := newLayerStore("/tmp/starmap-csp3-legacy/retained-fixture/state")
	if err != nil {
		t.Fatal(err)
	}
	history, err := retained.loadManualHistory(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	baseline := client.EmbeddedCatalogState()
	checksum, err := effectiveEvidenceChecksum(accepted.Manifest.Payload.Checksum, starmap.CandidateEvidence{SourceObservations: accepted.Manifest.SourceObservations, ReviewCandidates: accepted.Manifest.ReviewCandidates})
	if err != nil {
		t.Fatal(err)
	}
	identity := func(base starmap.CatalogState, inputs *manualBatch, policy *providerBindingPolicy) string {
		t.Helper()
		digest, err := observationResetChecksum(checksum, inputs)
		if err != nil {
			t.Fatal(err)
		}
		if policy != nil {
			result, err := policy.generationID(base.GenerationID, digest)
			if err != nil {
				t.Fatal(err)
			}
			return result
		}
		return deriveEffectiveGenerationID(base.GenerationID, digest)
	}
	t.Run("unchanged input matches", func(t *testing.T) {
		if got := identity(baseline, history, nil); got != accepted.Manifest.GenerationID {
			t.Fatalf("identity %s differs from accepted %s", got, accepted.Manifest.GenerationID)
		}
	})
	t.Run("changed binding policy invalidates", func(t *testing.T) {
		if identity(baseline, history, &providerBindingPolicy{}) == accepted.Manifest.GenerationID {
			t.Fatal("changed binding policy retained admission")
		}
	})
	t.Run("changed baseline generation invalidates", func(t *testing.T) {
		changed := baseline
		changed.GenerationID += ".replacement"
		if identity(changed, history, nil) == accepted.Manifest.GenerationID {
			t.Fatal("changed baseline generation retained admission")
		}
	})
	t.Run("changed baseline bytes invalidate", func(t *testing.T) {
		changed := baseline
		changed.PayloadChecksum = catalogs.DescribeCatalogPayload([]byte("changed baseline")).Checksum
		if identity(changed, history, nil) == accepted.Manifest.GenerationID {
			t.Fatal("identity-only recovery cannot detect changed baseline bytes")
		}
	})
	t.Run("missing original history invalidates", func(t *testing.T) {
		if identity(baseline, nil, nil) == accepted.Manifest.GenerationID {
			t.Fatal("identity-only recovery cannot detect missing original history")
		}
	})
}
