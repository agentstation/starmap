package acquisition

import (
	"os"
	"path/filepath"
	"strings"
	"testing"

	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/sources"
	pkgsync "github.com/agentstation/starmap/pkg/sync"
	"github.com/agentstation/starmap/runtime"
)

func TestAuditRealPinnedGitSourceAcquisition(t *testing.T) {
	home := t.TempDir()
	t.Setenv("HOME", home)
	t.Setenv("GIT_CONFIG_NOSYSTEM", "1")
	t.Setenv("GIT_CONFIG_GLOBAL", os.DevNull)
	t.Setenv("GIT_TERMINAL_PROMPT", "0")
	t.Setenv("GIT_ALLOW_PROTOCOL", "file")
	t.Setenv("GIT_CONFIG_COUNT", "1")
	t.Setenv("GIT_CONFIG_KEY_0", "url."+"/tmp/starmap-real-git-ingestion-2026-09-09/remote"+".insteadOf")
	t.Setenv("GIT_CONFIG_VALUE_0", "https://github.com/sst/models.dev.git")
	t.Setenv("BUN_INSTALL_CACHE_DIR", filepath.Join(home, "bun-cache"))
	commits := []string{"f8da724a1775e4a586fd693de3ed7f0cbaa0e296", "d46d308cdfa8a20841a0eea17a04ce681a0db531"}
	acquirer, err := NewSourceAcquirer(pkgsync.WithSources(sources.ModelsDevGitID), pkgsync.WithModelsDevGitCommit(commits[0]), pkgsync.WithSourcesDir(filepath.Join(home, "sources")), pkgsync.WithSkipDepPrompts(true))
	if err != nil {
		t.Fatal(err)
	}
	var previous string
	for index, commit := range commits {
		observations, err := acquirer.AcquireSources(t.Context(), runtime.SourceAcquisitionRequest{Current: acquisitionTestCatalog(t), Providers: []catalogs.ProviderID{"openai"}, ModelsDevGitCommit: &commit})
		if err != nil {
			t.Fatal(err)
		}
		if len(observations) != 1 {
			t.Fatalf("observations = %d", len(observations))
		}
		observation := observations[0]
		if observation.SourceID != sources.ModelsDevGitID || observation.Revision.Kind != sources.RevisionKindGitCommit || observation.Revision.Value != commit || observation.Revision.InputName != "bun.lock" || observation.Revision.InputChecksum == "" {
			t.Fatalf("unexpected revision: %+v", observation.Revision)
		}
		if observation.Status != sources.ObservationStatusSucceeded || observation.Completeness != sources.ObservationCompletenessComplete {
			t.Fatalf("source health: %s/%s", observation.Status, observation.Completeness)
		}
		if _, err := observation.Receipt(); err != nil {
			t.Fatal(err)
		}
		provider, err := observation.Catalog.Provider("openai")
		if err != nil {
			t.Fatal(err)
		}
		model := provider.Models["gpt-image-2"]
		want := []string{"Real Git fixture revision 1.", "Real Git fixture revision 2."}[index]
		if model == nil || !strings.HasPrefix(model.Description, want) {
			t.Fatalf("changed Git model not ingested: %+v", model)
		}
		if observation.ID == "" || observation.ID == previous {
			t.Fatal("changed Git source retained the previous receipt")
		}
		previous = observation.ID
	}
}
