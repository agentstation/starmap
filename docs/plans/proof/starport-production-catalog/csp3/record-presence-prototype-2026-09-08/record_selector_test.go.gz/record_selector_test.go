package reconciler

import (
	"testing"

	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/catalogs/authority"
	"github.com/agentstation/starmap/pkg/sources"
)

func TestOptionalRecordUnknownSurvivesSelection(t *testing.T) {
	for _, record := range catalogs.PublishedModelRecords() {
		t.Run(string(record), func(t *testing.T) {
			policies := authority.New()
			engine := newMerger(policies, NewAuthorityStrategy(policies), nil)
			unknown := &catalogs.Model{ID: "model", Name: "Model"}
			if !unknown.SetRecordUnknown(record) {
				t.Fatal("unsupported record")
			}
			models, _, err := engine.Models(map[sources.ID][]*catalogs.Model{
				sources.ModelsDevHTTPID: {unknown},
				sources.LocalCatalogID:  {{ID: "model", Name: "Model"}},
			})
			if err != nil {
				t.Fatal(err)
			}
			if len(models) != 1 {
				t.Fatalf("models=%d, want one", len(models))
			}
			if state := models[0].RecordPresence(record); state != catalogs.ValueUnknown {
				t.Fatalf("record presence=%v, want unknown", state)
			}
		})
	}
}
