package app

import (
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"net/url"
	"os"
	"path/filepath"
	"sync/atomic"
	"testing"
	"time"

	"github.com/agentstation/starmap/internal/constants"
	"github.com/agentstation/starmap/internal/server/operations"
	testcatalog "github.com/agentstation/starmap/internal/test/catalog"
	"github.com/agentstation/starmap/pkg/catalogs"
	catalogconfig "github.com/agentstation/starmap/pkg/catalogs/config"
	"github.com/agentstation/starmap/pkg/catalogs/storage"
	"github.com/agentstation/starmap/pkg/sources"
	"github.com/agentstation/starmap/server"
)

func TestHTTPRefreshIngestsProviderAndLocalEvidence(t *testing.T) {
	clearCatalogEnvironment(t)
	t.Setenv("STARMAP_HOME", t.TempDir())
	var limit atomic.Int64
	var partial atomic.Bool
	var failed atomic.Bool
	var calls atomic.Int32
	limit.Store(131072)
	api := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		if failed.Load() {
			http.Error(w, "fixture unavailable", http.StatusServiceUnavailable)
			return
		}
		if r.URL.Path != "/models" {
			t.Errorf("unexpected catalog path %s", r.URL.Path)
		}
		records := []map[string]any{{"id": "known", "object": "model", "name": "API name", "context_window": limit.Load()}}
		if partial.Load() {
			records = append(records, map[string]any{"object": "model"})
		}
		w.Header().Set("Content-Type", "application/json")
		if err := json.NewEncoder(w).Encode(map[string]any{"object": "list", "data": records}); err != nil {
			t.Error(err)
		}
	}))
	defer api.Close()
	workspace := catalogs.NewEmpty()
	if err := workspace.SetAuthor(catalogs.Author{ID: "acme", Name: "Acme"}); err != nil {
		t.Fatal(err)
	}
	if err := workspace.SetAuthorModel("acme", catalogs.Model{ID: "known", Name: "Known", Authors: []catalogs.Author{{ID: "acme", Name: "Acme"}}}); err != nil {
		t.Fatal(err)
	}
	credentials := testcatalog.APIKeyCredentials("ACME_API_KEY", "Authorization", catalogs.ProviderCredentialSchemeBearer)
	provider := catalogs.Provider{ID: "acme", Name: "Acme", Credentials: credentials, Catalog: &catalogs.ProviderCatalog{Endpoint: catalogs.ProviderEndpoint{Type: catalogs.EndpointTypeOpenAI, URL: api.URL + "/models", ProtocolOptions: testcatalog.OpenAIProtocolOptions(), FieldMappings: []catalogs.FieldMapping{{From: "context_window", To: "limits.context_window"}}}}, Models: map[string]*catalogs.Model{"known": {ID: "known", ModelRef: "acme/known", Name: "Reviewed offering"}}}
	if err := workspace.SetProvider(provider); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(t.TempDir(), "workspace")
	if err := workspace.SaveTo(path); err != nil {
		t.Fatal(err)
	}
	baselinePath := filepath.Join(t.TempDir(), "baseline.json")
	payload, err := catalogs.EncodeCatalogPayload(workspace)
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(baselinePath, payload, constants.SecureFilePermissions); err != nil {
		t.Fatal(err)
	}
	open := func() *App {
		application, err := New("test", "test", "test", "test", WithConfig(&Config{Quiet: true, CatalogPath: path, CatalogValues: map[string]string{catalogconfig.Source: "file", catalogconfig.SourceURL: baselinePath, catalogconfig.SourceStartupPolicy: "require_source", catalogconfig.AcquisitionEnabled: "false", catalogconfig.SourcePollInterval: "0s"}}))
		if err != nil {
			t.Fatal(err)
		}
		application.credentialResolver = sources.ProviderCredentialResolverFunc(func(_ context.Context, p *catalogs.Provider) (sources.ProviderCredentialMaterial, error) {
			return testcatalog.APIKeyMaterial(p.Credentials, "fixture-key"), nil
		})
		t.Cleanup(func() {
			if err := application.Shutdown(context.Background()); err != nil {
				t.Error(err)
			}
		})
		return application
	}
	application := open()
	connectedServer, err := application.Runtime(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	syncer, err := application.CatalogAcquisition(connectedServer.Client())
	if err != nil {
		t.Fatal(err)
	}
	srv, err := server.New(connectedServer.Client(), server.Config{PathPrefix: "/api/v1"}, server.WithRuntime(connectedServer), server.WithSyncer(syncer))
	if err != nil {
		t.Fatal(err)
	}
	if err := srv.Start(); err != nil {
		t.Fatal(err)
	}
	httpServer := httptest.NewServer(srv.Handler())
	closeServer := func() {
		httpServer.Close()
		ctx, cancel := context.WithTimeout(context.Background(), 5*time.Second)
		defer cancel()
		if err := srv.Shutdown(ctx); err != nil {
			t.Error(err)
		}
	}
	t.Cleanup(closeServer)
	client := httpServer.Client()
	client.Timeout = 2 * time.Minute
	readStatus := func(method, target string, expected int) operations.Status {
		t.Helper()
		request, err := http.NewRequestWithContext(t.Context(), method, httpServer.URL+target, nil)
		if err != nil {
			t.Fatal(err)
		}
		response, err := client.Do(request)
		if err != nil {
			t.Fatal(err)
		}
		defer response.Body.Close()
		if response.StatusCode != expected {
			t.Fatalf("%s %s: status %d, want %d", method, target, response.StatusCode, expected)
		}
		var envelope struct {
			Data operations.Status `json:"data"`
		}
		if err := json.NewDecoder(response.Body).Decode(&envelope); err != nil {
			t.Fatal(err)
		}
		return envelope.Data
	}
	runOperation := func(source string, fresh bool) operations.Status {
		t.Helper()
		values := url.Values{"provider": {"acme"}, "source": {source}}
		if fresh {
			values.Set("fresh", "true")
		}
		state := readStatus(http.MethodPost, "/api/v1/update?"+values.Encode(), http.StatusAccepted)
		if state.ID == "" {
			t.Fatal("operation ID is missing")
		}
		ctx, cancel := context.WithTimeout(t.Context(), 2*time.Minute)
		defer cancel()
		ticker := time.NewTicker(10 * time.Millisecond)
		defer ticker.Stop()
		for !state.State.Terminal() {
			select {
			case <-ctx.Done():
				t.Fatalf("operation %s timed out: %v", state.ID, ctx.Err())
			case <-ticker.C:
				state = readStatus(http.MethodGet, "/api/v1/updates/"+state.ID, http.StatusOK)
			}
		}
		return state
	}
	run := func(source string) {
		t.Helper()
		if state := runOperation(source, false); state.State != operations.StateSucceeded {
			t.Fatalf("operation failed: %+v", state)
		}
	}
	assertModel := func(want int64, description string) {
		t.Helper()
		connected, err := application.Runtime(t.Context())
		if err != nil {
			t.Fatal(err)
		}
		provider, err := connected.State().Catalog.Provider("acme")
		if err != nil {
			t.Fatal(err)
		}
		model := provider.Models["known"]
		if model == nil || model.Limits == nil || model.Limits.ContextWindow != want || model.Description != description {
			t.Fatalf("catalog model=%+v; want context %d and description %q", model, want, description)
		}
	}
	run(string(sources.LocalCatalogID))
	run(string(sources.ProvidersID))
	assertModel(131072, "")
	authored, err := catalogs.New(catalogs.WithPath(path))
	if err != nil {
		t.Fatal(err)
	}
	edited, err := authored.Provider("acme")
	if err != nil {
		t.Fatal(err)
	}
	edited.Models["known"].Description = "Operator fixture"
	if err := authored.SetProvider(edited); err != nil {
		t.Fatal(err)
	}
	if err := authored.SaveTo(path); err != nil {
		t.Fatal(err)
	}
	before := calls.Load()
	run(string(sources.LocalCatalogID))
	if calls.Load() != before {
		t.Fatal("local refresh contacted the provider")
	}
	assertModel(131072, "Operator fixture")
	limit.Store(262144)
	partial.Store(true)
	run(string(sources.ProvidersID))
	assertModel(262144, "Operator fixture")
	storePath, err := application.catalogStatePath()
	if err != nil {
		t.Fatal(err)
	}
	store, err := storage.NewFilesystem(storePath)
	if err != nil {
		t.Fatal(err)
	}
	accepted, err := store.Current(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	if !accepted.Manifest.Degraded {
		t.Fatal("partial provider reply was reported as healthy")
	}
	connected, err := application.Runtime(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	receipts := connected.State().Catalog.Provenance().FindModelField("acme", "known", "limits.context_window")
	if len(receipts) != 1 {
		t.Fatalf("limit receipts=%+v", receipts)
	}
	bound := false
	for _, link := range accepted.Manifest.SourceObservations {
		if string(link.Source) == string(sources.ProvidersID) && link.ObservationID == receipts[0].ObservationID && link.Status == sources.ObservationStatusDegraded && link.Completeness == sources.ObservationCompletenessPartial {
			bound = true
		}
	}
	if !bound {
		t.Fatal("partial value has no matching immutable source receipt")
	}
	failed.Store(true)
	if state := runOperation(string(sources.ProvidersID), true); state.State != operations.StateFailed {
		t.Fatalf("fresh provider failure state=%+v", state)
	}
	retained, err := store.Current(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	if retained.Manifest.GenerationID != accepted.Manifest.GenerationID {
		t.Fatal("failed acquisition replaced the accepted generation")
	}
	closeServer()
	if err := application.Shutdown(context.Background()); err != nil {
		t.Fatal(err)
	}
	application = open()
	assertModel(262144, "Operator fixture")
	restarted, err := store.Current(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	if restarted.Manifest.GenerationID != accepted.Manifest.GenerationID || restarted.Manifest.Payload.Checksum != accepted.Manifest.Payload.Checksum || !restarted.Manifest.Degraded {
		t.Fatal("restart changed accepted data or partial-evidence health")
	}
}
