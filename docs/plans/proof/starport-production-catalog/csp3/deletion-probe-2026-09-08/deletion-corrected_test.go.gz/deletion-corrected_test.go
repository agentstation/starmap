package runtime

import (
	"github.com/agentstation/starmap"
	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/sources"
	"testing"
	"time"
)

func TestCSP3EmptyObservationScope(t *testing.T) {
	for _, tc := range []struct {
		name                                 string
		public, partial, bound, wantOffering bool
	}{
		{"complete-public", true, false, true, false},
		{"partial-public", true, true, true, true},
		{"complete-account", false, false, true, true},
		{"complete-unbound", false, false, false, true},
	} {
		t.Run(tc.name, func(t *testing.T) {
			base, err := catalogs.DecodeCatalogPayload(testCatalogPayload(t, "provider", "model", "Baseline"))
			if err != nil {
				t.Fatal(err)
			}
			builder, err := catalogs.NewBuilderFrom(base)
			if err != nil {
				t.Fatal(err)
			}
			provider, err := builder.Provider("provider")
			if err != nil {
				t.Fatal(err)
			}
			clear(provider.Models)
			if err := builder.SetProvider(provider); err != nil {
				t.Fatal(err)
			}
			empty, err := builder.Build()
			if err != nil {
				t.Fatal(err)
			}
			binding := sources.ProviderAcquisitionBinding{SchemaVersion: 1, ID: "fixture", Revision: "1", ProviderID: "provider", Public: tc.public, Region: "global", APISurface: "models.list", CredentialRole: sources.ProviderBindingCatalogAcquisition, CredentialProfileID: "catalog"}
			if !tc.public {
				binding.AccountID = "account"
			}
			metadata := sources.ObservationMetadata{ObservedAt: time.Date(2026, 9, 8, 0, 0, 0, 0, time.UTC), Revision: sources.Revision{Kind: sources.RevisionKindContentDigest}, Completeness: sources.ObservationCompletenessComplete, Status: sources.ObservationStatusSucceeded}
			if tc.bound {
				metadata.ProviderBinding = &binding
			}
			if tc.partial {
				metadata.Completeness = sources.ObservationCompletenessPartial
				metadata.Status = sources.ObservationStatusDegraded
				metadata.Issues = []sources.ObservationIssue{{Scope: sources.ObservationIssueScopeRecord, Code: sources.ObservationIssueCodeInvalidRecord, Subject: "provider/model"}}
			}
			observation, err := sources.NewObservation(sources.ProvidersID, empty, metadata)
			if err != nil {
				t.Fatal(err)
			}
			layer, err := NewProviderLayer("provider", observation)
			if err != nil {
				t.Fatal(err)
			}
			layers := layerSet{}
			if tc.bound {
				layers.providerBindings = &providerBindingPolicy{bindings: map[string]sources.ProviderAcquisitionBinding{binding.ID: binding}}
			}
			layers.setProvider(layer)
			state, err := layers.build(t.Context(), starmap.CatalogState{Catalog: base, GenerationID: "baseline", GeneratedAt: metadata.ObservedAt.Add(-time.Hour)})
			if err != nil {
				t.Fatal(err)
			}
			actual, err := state.Catalog.Provider("provider")
			if err != nil {
				t.Fatal(err)
			}
			_, present := actual.Models["model"]
			if present != tc.wantOffering {
				t.Fatalf("offering membership = %t, want %t after %s empty observation", present, tc.wantOffering, tc.name)
			}
		})
	}
}
