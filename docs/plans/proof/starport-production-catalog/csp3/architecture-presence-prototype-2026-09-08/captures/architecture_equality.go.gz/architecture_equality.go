package catalogs

// Equal compares architecture facts and Boolean presence states.
func (a ModelArchitecture) Equal(other ModelArchitecture) bool {
	return equalPresenceJSON(a, other)
}
