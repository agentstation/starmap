package runtime

import (
	"encoding/json"
	"os"
	"path/filepath"
	"testing"
	"time"

	"github.com/agentstation/starmap"
	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/catalogs/storage"
	"github.com/agentstation/starmap/pkg/sources"
)

func TestArchitectureOldWriterNewReader(t *testing.T) {
	root := os.Getenv("STARMAP_ARCHITECTURE_UPGRADE_DIR")
	stage := os.Getenv("STARMAP_ARCHITECTURE_UPGRADE_STAGE")
	if root == "" || (stage != "write" && stage != "read") {
		t.Fatal("explicit upgrade directory and stage are required")
	}
	for _, flag := range []bool{false, true} {
		name := "false"
		if flag {
			name = "true"
		}
		t.Run(name, func(t *testing.T) {
			dir := filepath.Join(root, name)
			for _, p := range []string{dir, filepath.Join(dir, "store"), filepath.Join(dir, "state")} {
				if err := os.MkdirAll(p, 0700); err != nil {
					t.Fatal(err)
				}
			}
			at := time.Date(2026, 9, 8, 0, 0, 0, 0, time.UTC)
			payloadFile := filepath.Join(dir, "baseline.json")
			var payload []byte
			var err error
			if stage == "write" {
				payload, err = catalogs.EncodeCatalogPayload(manualProviderObservation(t, 0, at).Catalog)
				if err == nil {
					err = os.WriteFile(payloadFile, payload, 0600)
				}
			} else {
				payload, err = os.ReadFile(payloadFile)
			}
			if err != nil {
				t.Fatal(err)
			}
			source := newStubSource("architecture-upgrade")
			source.replies = []SourceRead{testSourceRead(t, "upgrade-baseline", payload, at), testSourceRead(t, "upgrade-refresh", payload, at.Add(time.Hour))}
			store, err := storage.NewFilesystem(filepath.Join(dir, "store"))
			if err != nil {
				t.Fatal(err)
			}
			connected := openTestRuntime(t, WithSource(source), WithStateDirectory(filepath.Join(dir, "state")), WithClientOptions(starmap.WithCatalogStore(store)))
			if stage == "write" {
				if _, err := connected.RefreshSource(t.Context()); err != nil {
					t.Fatal(err)
				}
				builder, err := catalogs.NewBuilderFrom(manualProviderObservation(t, 0, at).Catalog)
				if err != nil {
					t.Fatal(err)
				}
				provider, err := builder.Provider("provider")
				if err != nil {
					t.Fatal(err)
				}
				provider.Models["model"].Metadata = &catalogs.ModelMetadata{Architecture: &catalogs.ModelArchitecture{ParameterCount: "7B", Quantized: flag, FineTuned: flag}}
				if err := builder.SetProvider(provider); err != nil {
					t.Fatal(err)
				}
				catalog, err := catalogs.NewObservationCatalog(builder)
				if err != nil {
					t.Fatal(err)
				}
				observation, err := sources.NewObservation(sources.ProvidersID, catalog, sources.ObservationMetadata{ObservedAt: at.Add(time.Minute), Revision: sources.Revision{Kind: sources.RevisionKindContentDigest}, Completeness: sources.ObservationCompletenessComplete, Status: sources.ObservationStatusSucceeded})
				if err != nil {
					t.Fatal(err)
				}
				if _, err := connected.PublishObservations(t.Context(), observation); err != nil {
					t.Fatal(err)
				}
				generation, err := store.Current(t.Context())
				if err != nil {
					t.Fatal(err)
				}
				record := map[string]string{"generation": generation.Manifest.GenerationID, "observation": observation.ID, "checksum": observation.EvidenceChecksum}
				data, err := json.Marshal(record)
				if err != nil {
					t.Fatal(err)
				}
				if err := os.WriteFile(filepath.Join(dir, "expected.json"), data, 0600); err != nil {
					t.Fatal(err)
				}
			} else {
				data, err := os.ReadFile(filepath.Join(dir, "expected.json"))
				if err != nil {
					t.Fatal(err)
				}
				var expected map[string]string
				if err := json.Unmarshal(data, &expected); err != nil {
					t.Fatal(err)
				}
				check := func(sameGeneration bool) {
					t.Helper()
					generation, err := store.Current(t.Context())
					if err != nil {
						t.Fatal(err)
					}
					if sameGeneration && generation.Manifest.GenerationID != expected["generation"] {
						t.Fatal("startup replaced the accepted generation")
					}
					found := false
					for _, link := range generation.Manifest.SourceObservations {
						if link.ObservationID == expected["observation"] {
							found = true
							if link.EvidenceChecksum != expected["checksum"] {
								t.Fatal("original observation checksum changed")
							}
						}
					}
					if !found {
						t.Fatal("original observation link is missing")
					}
				}
				check(true)
				if _, err := connected.RefreshSource(t.Context()); err != nil {
					t.Fatal(err)
				}
				check(false)
			}
			if err := connected.Close(); err != nil {
				t.Fatal(err)
			}
		})
	}
}
