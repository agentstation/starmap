package catalogs

import (
	"encoding/json"
	"github.com/goccy/go-yaml"
)

// MarshalJSON preserves missing, unknown, and known architecture claims.
func (a ModelArchitecture) MarshalJSON() ([]byte, error) {
	type plain ModelArchitecture
	data, err := json.Marshal(plain(a))
	if err != nil {
		return nil, err
	}
	var fields map[string]json.RawMessage
	if err := json.Unmarshal(data, &fields); err != nil {
		return nil, err
	}
	_, quantized := a.QuantizedValue()
	_, fineTuned := a.FineTunedValue()
	for key, state := range map[string]ValuePresence{"quantized": quantized, "fine_tuned": fineTuned} {
		switch state {
		case ValueMissing:
			delete(fields, key)
		case ValueUnknown:
			fields[key] = json.RawMessage("null")
		}
	}
	return json.Marshal(fields)
}

// UnmarshalJSON restores architecture claim presence.
func (a *ModelArchitecture) UnmarshalJSON(data []byte) error {
	type plain ModelArchitecture
	var decoded plain
	if err := json.Unmarshal(data, &decoded); err != nil {
		return err
	}
	var fields map[string]json.RawMessage
	if err := json.Unmarshal(data, &fields); err != nil {
		return err
	}
	*a = ModelArchitecture(decoded)
	for key, state := range map[string]*ValuePresence{"quantized": &a.quantizedPresence, "fine_tuned": &a.fineTunedPresence} {
		if value, present := fields[key]; present {
			*state = ValueKnown
			if isJSONNull(value) {
				*state = ValueUnknown
			}
		}
	}
	return nil
}

// MarshalYAML preserves architecture claim presence in the authoring workspace.
func (a ModelArchitecture) MarshalYAML() (any, error) {
	entries := yaml.MapSlice{}
	if a.ParameterCount != "" {
		entries = append(entries, yaml.MapItem{Key: "parameter_count", Value: a.ParameterCount})
	}
	if a.Type != "" {
		entries = append(entries, yaml.MapItem{Key: "type", Value: a.Type})
	}
	if a.Tokenizer != "" {
		entries = append(entries, yaml.MapItem{Key: "tokenizer", Value: a.Tokenizer})
	}
	if a.Quantization != "" {
		entries = append(entries, yaml.MapItem{Key: "quantization", Value: a.Quantization})
	}
	for _, key := range []string{"quantized", "fine_tuned"} {
		value, state := a.QuantizedValue()
		if key == "fine_tuned" {
			value, state = a.FineTunedValue()
		}
		switch state {
		case ValueKnown:
			entries = append(entries, yaml.MapItem{Key: key, Value: value})
		case ValueUnknown:
			entries = append(entries, yaml.MapItem{Key: key, Value: nil})
		}
	}
	if a.BaseModel != nil {
		entries = append(entries, yaml.MapItem{Key: "base_model", Value: a.BaseModel})
	}
	return entries, nil
}

// UnmarshalYAML restores architecture claim presence from an authoring record.
func (a *ModelArchitecture) UnmarshalYAML(unmarshal func(any) error) error {
	type plain ModelArchitecture
	var decoded plain
	if err := unmarshal(&decoded); err != nil {
		return err
	}
	var fields map[string]any
	if err := unmarshal(&fields); err != nil {
		return err
	}
	*a = ModelArchitecture(decoded)
	for key, state := range map[string]*ValuePresence{"quantized": &a.quantizedPresence, "fine_tuned": &a.fineTunedPresence} {
		if value, present := fields[key]; present {
			*state = ValueKnown
			if value == nil {
				*state = ValueUnknown
			}
		}
	}
	return nil
}
