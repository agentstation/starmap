// Package reconciler provides catalog synchronization and reconciliation capabilities.
// It handles merging data from multiple sources, detecting changes, and applying
// updates while respecting data authorities and merge strategies.
package reconciler

import (
	"context"
	"maps"
	"strings"
	"time"

	"github.com/rs/zerolog"

	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/catalogs/authority"
	"github.com/agentstation/starmap/pkg/catalogs/evidence"
	"github.com/agentstation/starmap/pkg/differ"
	"github.com/agentstation/starmap/pkg/errors"
	"github.com/agentstation/starmap/pkg/logging"
	"github.com/agentstation/starmap/pkg/provenance"
	"github.com/agentstation/starmap/pkg/sources"
)

// Reconciler combines data from multiple sources into a canonical catalog.
// It is concrete because this package has one reconciliation engine. The narrow
// authority.Reader and Source interfaces accept extensions.
type Reconciler struct {
	strategy               *AuthorityStrategy
	authorities            authority.Reader
	provenance             *provenance.Tracker
	tracking               bool
	baseline               *catalogs.Catalog // Baseline catalog for comparison
	changeTime             time.Time
	projectedEvidence      func(catalogs.ProviderID, provenance.Entry) bool
	providerSelection      providerObservationSelection
	baselineProviderSource sources.ID
}

// New creates a new Reconciler with options.
func New(opts ...Option) (*Reconciler, error) {
	// Create options with defaults
	options, err := newOptions(opts...)
	if err != nil {
		return nil, err
	}

	// Create reconciler from options
	r := &Reconciler{
		strategy:               NewAuthorityStrategy(options.authorities),
		authorities:            options.authorities,
		provenance:             provenance.NewTracker(options.tracking),
		tracking:               options.tracking,
		baseline:               options.baseline,
		changeTime:             options.changeTime,
		projectedEvidence:      options.projectedEvidence,
		providerSelection:      options.providerSelection,
		baselineProviderSource: options.baselineProviderSource,
	}

	return r, nil
}

// reconcileContext holds shared state for reconciliation.
type reconcileContext struct {
	collector *collector
	filter    *filter
	merger    *merger
	logger    *zerolog.Logger
	startTime time.Time
	baseline  *catalogs.Catalog // Baseline for comparison
}

// modelResult holds reconciled models and provenance.
type modelResult struct {
	models     []*catalogs.Model
	provenance provenance.Map
	apiCount   int // Count from primary source
}

// Sources reconciles observations in discrete steps.
func (r *Reconciler) Sources(ctx context.Context, primary sources.ID, srcs []sources.Observation) (*Result, error) {
	// Step 1: Initialize context and validate
	rctx, err := r.initialize(ctx, primary, srcs)
	if err != nil {
		return nil, err
	}

	// Step 2: Collect and merge providers
	providers, err := r.reconcileProviders(rctx)
	if err != nil {
		return nil, err
	}

	// Step 3: Filter providers by primary source
	// Convert to values for filtering
	providerValues := make([]catalogs.Provider, len(providers))
	for i, p := range providers {
		if p != nil {
			providerValues[i] = *p
		}
	}
	filteredValues := rctx.filter.filterProviders(providerValues)
	// Convert back to pointers
	providers = make([]*catalogs.Provider, len(filteredValues))
	for i, p := range filteredValues {
		providers[i] = &p
	}
	rctx.logger.Info().
		Int("provider_count", len(providers)).
		Msg("Filtered providers by primary source")

	// Step 4: Reconcile models for each provider
	modelResults, err := r.reconcileAllModels(rctx, providers)
	if err != nil {
		return nil, err
	}

	if err := rctx.merger.validateLegacyRecovery(); err != nil {
		return nil, err
	}

	// Step 5: Build catalog with providers and models
	catalog, reviewCandidates, err := r.catalog(rctx, providers, modelResults)
	if err != nil {
		return nil, err
	}
	for _, issue := range reviewCandidates {
		rctx.logger.Warn().
			Str("issue_code", string(issue.Code)).
			Str("provider_id", issue.ProviderID).
			Str("provider_model_id", issue.ProviderModelID).
			Msg(issue.Reason)
	}

	// Step 6: Compute changeset if we have a base catalog
	changeset := r.changeset(rctx, catalog)

	// Step 7: Build and return result
	return r.result(rctx, catalog, changeset, modelResults, reviewCandidates), nil
}

// initialize sets up reconciliation context.
func (r *Reconciler) initialize(ctx context.Context, primary sources.ID, srcs []sources.Observation) (*reconcileContext, error) {
	if ctx == nil {
		return nil, &errors.ValidationError{Field: "reconciliation.context", Message: "is required"}
	}
	if err := ctx.Err(); err != nil {
		return nil, err
	}
	logger := logging.FromContext(ctx)
	if err := r.providerSelection.validate(ctx, srcs); err != nil {
		return nil, err
	}
	srcs, scoped, err := orderScopedObservations(ctx, srcs, r.providerSelection)
	if err != nil {
		return nil, err
	}

	// Create collector
	collector := newCollector(srcs, primary)
	collector.scoped = scoped
	collector.providerSelection = r.providerSelection
	if err := collector.restrictProviderCollection(r.baselineProviderSource, r.baseline); err != nil {
		return nil, err
	}

	// Validate and get primary catalog if specified
	var primaryCatalog *catalogs.Catalog
	if primary != "" {
		primaryCatalog = collector.primaryCatalog()
		if (primary == sources.ProvidersID && scoped != nil) || (isModelsDevSource(primary) && len(r.providerSelection) > 0) {
			primaryCatalog, err = selectedPrimaryCatalog(primary, srcs, r.providerSelection)
			if err != nil {
				return nil, err
			}
		}
		if primaryCatalog == nil {
			return nil, &errors.ValidationError{
				Field:   "primary",
				Value:   string(primary),
				Message: "specified primary source not found in sources list or has no catalog",
			}
		}
		logger.Debug().
			Str("primary_source", string(primary)).
			Msg("Using primary catalog for filtering")
	}

	merger := r.createMerger()
	merger.setObservations(srcs)
	merger.scoped = scoped

	// Create context
	return &reconcileContext{
		collector: collector,
		filter:    newFilter(primary, primaryCatalog),
		merger:    merger,
		logger:    logger,
		startTime: time.Now(),
		baseline:  r.baseline,
	}, nil
}

// reconcileProviders merges providers from all sources.
func (r *Reconciler) reconcileProviders(rctx *reconcileContext) ([]*catalogs.Provider, error) {
	// Collect providers from all sources
	providerSources := rctx.filter.providerSources(rctx.collector.collectProviders())

	// Merge providers using configured strategy
	return rctx.merger.Providers(providerSources)
}

// reconcileAllModels processes models for all providers.
func (r *Reconciler) reconcileAllModels(rctx *reconcileContext, providers []*catalogs.Provider) (map[catalogs.ProviderID]modelResult, error) {
	results := make(map[catalogs.ProviderID]modelResult)

	for _, provider := range providers {
		rctx.logger.Debug().
			Str("provider", string(provider.ID)).
			Msg("Reconciling models for provider")

		result, err := r.reconcileProviderModels(rctx, provider)
		if err != nil {
			// Log error but continue with other providers
			rctx.logger.Error().
				Err(err).
				Str("provider", string(provider.ID)).
				Msg("Failed to reconcile provider models")
			continue
		}

		results[provider.ID] = result
	}

	return results, nil
}

// reconcileProviderModels merges models for a single provider.
func (r *Reconciler) reconcileProviderModels(rctx *reconcileContext, provider *catalogs.Provider) (modelResult, error) {
	// Collect models for this provider from all sources
	primaryCatalog := rctx.filter.primaryCatalog
	if primaryCatalog == nil {
		primaryCatalog = rctx.collector.primaryCatalog()
	}

	modelSources := rctx.collector.collectModelsForProvider(
		provider,
		primaryCatalog,
	)

	// Track API count from primary source
	apiCount := 0
	if rctx.collector.primary != "" {
		if models, exists := modelSources[rctx.collector.primary]; exists {
			identities := make(map[string]bool, len(models))
			for _, model := range models {
				if model != nil {
					identities[model.ID] = true
				}
			}
			apiCount = len(identities)
		}
	}

	// Merge models using configured strategy
	models, prov, err := rctx.merger.ModelsForProvider(provider.ID, modelSources)
	if err != nil {
		return modelResult{}, err
	}

	return modelResult{
		models:     models,
		provenance: prov,
		apiCount:   apiCount,
	}, nil
}

// catalog creates the final catalog with providers and models.
func (r *Reconciler) catalog(
	rctx *reconcileContext,
	providers []*catalogs.Provider,
	modelResults map[catalogs.ProviderID]modelResult,
) (*catalogs.Builder, []evidence.ReviewCandidate, error) {
	var catalog *catalogs.Builder
	var err error

	// Start with baseline catalog if available to preserve existing providers
	if r.baseline != nil {
		catalog, err = catalogs.NewBuilderFrom(r.baseline)
		if err != nil {
			return nil, nil, errors.WrapResource("copy", "baseline catalog", "", err)
		}
	} else {
		catalog = catalogs.NewEmpty()
	}
	if err := reconcileAuthoredCorpus(catalog, r.baseline, rctx.collector); err != nil {
		return nil, nil, err
	}
	// Add/update providers with their reconciled models
	for i := range providers {
		provider := providers[i]

		// Add models if we have results for this provider
		if result, ok := modelResults[provider.ID]; ok && len(result.models) > 0 {
			provider.Models = providerModelMap(result.models)
		}

		// Set provider in catalog (this will overwrite existing provider)
		if err := catalog.SetProvider(*provider); err != nil {
			return nil, nil, errors.WrapResource("set", "provider", string(provider.ID), err)
		}
	}

	reviewCandidates, err := quarantineUnresolvedProviderOfferings(catalog, r.baseline, rctx.collector)
	if err != nil {
		return nil, nil, err
	}
	return catalog, reviewCandidates, nil
}

// changeset calculates differences between baseline and new catalog.
func (r *Reconciler) changeset(rctx *reconcileContext, catalog *catalogs.Builder) *differ.Changeset {
	// Use provided baseline if available, otherwise fall back to first source
	var baseCatalog *catalogs.Catalog
	if rctx.baseline != nil {
		baseCatalog = rctx.baseline
		rctx.logger.Debug().Msg("Using provided baseline catalog for comparison")
	} else {
		// Fall back to first source catalog for backward compatibility
		baseCatalog = rctx.collector.baseCatalog()
		if baseCatalog == nil {
			return nil
		}
		rctx.logger.Debug().Msg("No baseline provided, using first source catalog")
	}

	return differ.New().Catalogs(baseCatalog, catalog)
}

// result creates the final result.
func (r *Reconciler) result(
	rctx *reconcileContext,
	catalog *catalogs.Builder,
	changeset *differ.Changeset,
	modelResults map[catalogs.ProviderID]modelResult,
	reviewCandidates []evidence.ReviewCandidate,
) *Result {
	result := NewResult()

	// Set core data
	result.Catalog = catalog
	result.Changeset = changeset
	result.ReviewCandidates = append(
		result.ReviewCandidates,
		reviewCandidates...,
	)

	// Combine all provenance data (models only). Scope merge-local provenance
	// keys by provider so shared model IDs from different providers cannot
	// overwrite one another in the flat result map.
	for providerID, mr := range modelResults {
		maps.Copy(result.Provenance, providerScopedProvenance(providerID, mr.provenance))
	}

	// Replace evidence for fields observed during this reconciliation while
	// retaining exact evidence for baseline-only providers/models. Source
	// absence is not lifecycle evidence and therefore cannot erase the
	// last-known-good value or its provenance.
	if r.provenance != nil {
		combined := catalog.Provenance().Map()
		for key, entries := range r.provenance.Map() {
			combined[key] = entries
		}
		removeQuarantinedModelProvenance(combined, reviewCandidates)
		catalog.SetProvenance(combined)
	}

	for _, provider := range catalog.Providers().List() {
		if provider.Models != nil {
			for modelID := range provider.Models {
				result.ModelProviderMap[modelID] = provider.ID
			}
		}
	}

	// Track API counts from modelResults
	for providerID, mr := range modelResults {
		if mr.apiCount > 0 {
			result.ProviderAPICounts[providerID] = mr.apiCount
		}
	}

	// Set metadata
	result.Metadata.Sources = rctx.collector.sourceTypes()
	// Calculate statistics
	result.Metadata.Stats = r.calcStats(catalog, modelResults)
	result.Metadata.Stats.ResourcesSkipped = len(reviewCandidates)

	// Finalize result
	result.Finalize()

	return result
}

func providerScopedProvenance(providerID catalogs.ProviderID, source provenance.Map) provenance.Map {
	scoped := make(provenance.Map, len(source))
	prefix := "models."
	scopedPrefix := "models." + string(providerID) + "."
	for key, entries := range source {
		if rest, ok := strings.CutPrefix(key, prefix); ok && providerID != "" {
			scoped[scopedPrefix+rest] = entries
			continue
		}
		scoped[key] = entries
	}
	return scoped
}

// createMerger creates a merger based on configuration.
func (r *Reconciler) createMerger() *merger {
	var result *merger
	if r.tracking && r.provenance != nil {
		result = newMergerWithProvenance(r.authorities, r.strategy, r.provenance, r.baseline)
	} else {
		result = newMerger(r.authorities, r.strategy, r.baseline)
	}
	result.changeAt = r.changeTime
	result.projectedEvidence = r.projectedEvidence
	return result
}

// calcStats computes statistics from the catalog.
func (r *Reconciler) calcStats(catalog catalogs.Reader, modelResults map[catalogs.ProviderID]modelResult) ResultStatistics {
	var stats ResultStatistics

	// Count providers
	providers := catalog.Providers().List()
	stats.ProvidersProcessed = len(providers)

	// Count models
	for _, result := range modelResults {
		stats.ModelsProcessed += len(result.models)
	}

	return stats
}
