package reconciler

import (
	"errors"
	"testing"
	"time"

	"github.com/agentstation/starmap/pkg/catalogs"
	pkgerrors "github.com/agentstation/starmap/pkg/errors"
	"github.com/agentstation/starmap/pkg/sources"
)

func TestLegacyRecoveryRequiresIndependentEvidence(t *testing.T) {
	for _, scenario := range []struct {
		name                        string
		original, edited, synthetic bool
	}{
		{name: "unresolved"}, {name: "original", original: true}, {name: "edited", edited: true}, {name: "synthetic-working-copy", synthetic: true},
	} {
		t.Run(scenario.name, func(t *testing.T) {
			input := sourceIdentityCatalog(t, "", catalogs.Model{ID: "shared", Name: "Shared", Metadata: &catalogs.ModelMetadata{Tags: []catalogs.ModelTag{"chat"}}, Extensions: catalogs.SourceExtensions{"source": {Fields: map[string]any{"fact": true}}}})
			original := sourceIdentityObservation(t, sources.ProvidersID, input, time.Date(2026, 9, 8, 0, 0, 0, 0, time.UTC))
			generated := sourceIdentityReconcile(t, sources.ProvidersID, original)
			catalog := aggregateOnlyCompositeCatalog(t, snapshotForTest(t, generated.Catalog))
			if scenario.edited {
				builder, err := catalogs.NewBuilderFrom(catalog)
				if err != nil {
					t.Fatal(err)
				}
				provider, err := builder.Provider("provider-a")
				if err != nil {
					t.Fatal(err)
				}
				provider.Models["shared"].Metadata.Tags = []catalogs.ModelTag{"code"}
				provider.Models["shared"].Extensions["source"].Fields["fact"] = false
				if err := builder.SetProvider(provider); err != nil {
					t.Fatal(err)
				}
				catalog, err = builder.Build()
				if err != nil {
					t.Fatal(err)
				}
			}
			local := sourceIdentityObservation(t, sources.LocalCatalogID, catalog, original.ObservedAt.Add(time.Minute))
			inputs := []sources.Observation{local}
			if scenario.original {
				inputs = append(inputs, original)
			}
			if scenario.synthetic {
				inputs = append(inputs, sources.Observation{SourceID: sources.EmbeddedCatalogID, Catalog: catalog})
			}
			reconciler, err := New(WithBaseline(catalog))
			if err != nil {
				t.Fatal(err)
			}
			result, err := reconciler.Sources(t.Context(), sources.LocalCatalogID, inputs)
			if !scenario.original && !scenario.edited {
				var validation *pkgerrors.ValidationError
				if !errors.As(err, &validation) || validation.Field != "reconciliation.legacy_provenance" || result != nil {
					t.Fatalf("result present=%t error=%v, want typed legacy refusal", result != nil, err)
				}
				return
			}
			if err != nil {
				t.Fatal(err)
			}
			fields := []string{`metadata.tags["chat"]`, `extensions["source"].fields["fact"]`}
			want := original.ID
			if scenario.edited {
				fields[0] = `metadata.tags["code"]`
				want = local.ID
			}
			for _, field := range fields {
				entries := result.Catalog.Provenance().FindModelField("provider-a", "shared", field)
				if len(entries) != 1 || entries[0].ObservationID != want {
					t.Errorf("%s entries=%+v, want receipt %s", field, entries, want)
				}
			}
		})
	}
}
