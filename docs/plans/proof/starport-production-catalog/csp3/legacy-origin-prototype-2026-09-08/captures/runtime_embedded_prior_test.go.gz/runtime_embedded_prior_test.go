package runtime

import (
	stderrors "errors"
	pkgerrors "github.com/agentstation/starmap/pkg/errors"
	"github.com/agentstation/starmap/pkg/provenance"
	"testing"
	"time"

	"github.com/agentstation/starmap"
	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/catalogs/storage"
	"github.com/agentstation/starmap/pkg/sources"
)

func TestLegacyEmbeddedBaselineAllowsExplicitObservation(t *testing.T) {
	store := storage.NewMemory()
	opts := []Option{WithCatalogSource("embedded"), WithStateDirectory(privateRuntimeDirectory(t)), WithClientOptions(starmap.WithCatalogStore(store))}
	connected := openTestRuntime(t, opts...)
	before := connected.State()
	provider, err := before.Catalog.Provider("openai")
	if err != nil {
		t.Fatal(err)
	}
	known := provider.Models["gpt-4o-mini"]
	if known == nil {
		t.Fatal("compiled baseline lacks the selected offering")
	}
	provider.Models = map[string]*catalogs.Model{"gpt-4o-mini": {ID: known.ID, ModelRef: known.ModelRef, Name: known.Name, Limits: &catalogs.ModelLimits{ContextWindow: 8192}}}
	builder := catalogs.NewEmpty()
	if err := builder.SetProvider(provider); err != nil {
		t.Fatal(err)
	}
	input, err := catalogs.NewObservationCatalog(builder)
	if err != nil {
		t.Fatal(err)
	}
	observed, err := sources.NewObservation(sources.ProvidersID, input, sources.ObservationMetadata{ObservedAt: time.Date(2026, 9, 8, 0, 0, 0, 0, time.UTC), Revision: sources.Revision{Kind: sources.RevisionKindContentDigest}, Completeness: sources.ObservationCompletenessComplete, Status: sources.ObservationStatusSucceeded, Records: sources.ObservationRecordCounts{Accepted: 1}})
	if err != nil {
		t.Fatal(err)
	}
	updated, err := connected.PublishObservations(t.Context(), observed)
	if err != nil {
		t.Fatal(err)
	}
	if updated.Catalog.Providers().Len() < before.Catalog.Providers().Len() {
		t.Fatal("explicit observation removed baseline providers")
	}
	provider, err = updated.Catalog.Provider("openai")
	if err != nil {
		t.Fatal(err)
	}
	if provider.Models["gpt-4o-mini"] == nil || provider.Models["gpt-4o-mini"].Limits.ContextWindow != 8192 {
		t.Fatal("explicit observation did not survive baseline recovery")
	}
	if err := connected.Close(); err != nil {
		t.Fatal(err)
	}
	reopened := openTestRuntime(t, opts...)
	if reopened.State().PayloadChecksum != updated.PayloadChecksum {
		t.Fatal("reopen changed the accepted catalog")
	}
}

func TestLegacyCandidateRefusalPreservesAcceptedState(t *testing.T) {
	store := storage.NewMemory()
	opts := []Option{WithCatalogSource("embedded"), WithStateDirectory(privateRuntimeDirectory(t)), WithClientOptions(starmap.WithCatalogStore(store))}
	connected := openTestRuntime(t, opts...)
	before := connected.State()
	provider, err := before.Catalog.Provider("openai")
	if err != nil {
		t.Fatal(err)
	}
	known := provider.Models["gpt-4o-mini"]
	if known == nil {
		t.Fatal("compiled baseline lacks the selected offering")
	}
	model := &catalogs.Model{ID: known.ID, ModelRef: known.ModelRef, Name: known.Name, Extensions: catalogs.SourceExtensions{"private": {Fields: map[string]any{"sentinel": true}}}}
	provider.Models = map[string]*catalogs.Model{known.ID: model}
	builder := catalogs.NewEmpty()
	if err := builder.SetProvider(provider); err != nil {
		t.Fatal(err)
	}
	input, err := catalogs.NewObservationCatalog(builder)
	if err != nil {
		t.Fatal(err)
	}
	at := time.Date(2026, 9, 8, 0, 0, 0, 0, time.UTC)
	metadata := sources.ObservationMetadata{ObservedAt: at, Revision: sources.Revision{Kind: sources.RevisionKindContentDigest}, Completeness: sources.ObservationCompletenessComplete, Status: sources.ObservationStatusSucceeded, Records: sources.ObservationRecordCounts{Accepted: 1}}
	original, err := sources.NewObservation(sources.ProvidersID, input, metadata)
	if err != nil {
		t.Fatal(err)
	}
	entry := provenance.Entry{Source: original.SourceID, Field: "extensions", Value: model.Extensions, Timestamp: at, ObservationID: original.ID, ObservedAt: at, Revision: original.Revision, EvidenceChecksum: original.EvidenceChecksum}
	builder.SetProvenance(provenance.Map{"model:" + provenance.ModelResourceID("openai", known.ID) + ":extensions": {entry}})
	legacy, err := catalogs.NewObservationCatalog(builder)
	if err != nil {
		t.Fatal(err)
	}
	metadata.ObservedAt = at.Add(time.Minute)
	local, err := sources.NewObservation(sources.LocalCatalogID, legacy, metadata)
	if err != nil {
		t.Fatal(err)
	}
	_, err = connected.PublishObservations(t.Context(), local)
	var validation *pkgerrors.ValidationError
	if !stderrors.As(err, &validation) || validation.Field != "reconciliation.legacy_provenance" {
		t.Fatalf("error=%v, want typed legacy refusal", err)
	}
	after := connected.State()
	if after.GenerationID != before.GenerationID || after.PayloadChecksum != before.PayloadChecksum || after.Sequence != before.Sequence {
		t.Fatal("refused legacy candidate changed accepted state")
	}
	if connected.layers.manual != nil {
		t.Fatal("refused candidate changed original observation history")
	}
	pending, err := connected.store.loadInputPublication()
	if err != nil || pending != nil {
		t.Fatalf("refused candidate left a publication record: %v", err)
	}
	if err := connected.Close(); err != nil {
		t.Fatal(err)
	}
	reopened := openTestRuntime(t, opts...)
	if reopened.State().PayloadChecksum != before.PayloadChecksum {
		t.Fatal("refused candidate changed the catalog after restart")
	}
}
