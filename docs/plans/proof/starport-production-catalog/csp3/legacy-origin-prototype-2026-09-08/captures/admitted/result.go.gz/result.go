package reconciler

import (
	"fmt"
	"time"

	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/catalogs/evidence"
	"github.com/agentstation/starmap/pkg/differ"
	"github.com/agentstation/starmap/pkg/provenance"
	"github.com/agentstation/starmap/pkg/sources"
)

// Result represents the outcome of a reconciliation operation.
type Result struct {
	// ProjectionBaseline identifies independent baseline evidence used for legacy recovery.
	ProjectionBaseline *catalogs.SourceObservationLink
	// Core data
	Catalog        *catalogs.Builder
	Changeset      *differ.Changeset
	AppliedChanges *differ.Changeset

	// Tracking maps
	ProviderAPICounts map[catalogs.ProviderID]int
	ModelProviderMap  map[string]catalogs.ProviderID

	// Metadata
	Metadata ResultMetadata

	// Provenance tracking
	Provenance provenance.Map

	// Issues
	Errors           []error
	Warnings         []string
	ReviewCandidates []evidence.ReviewCandidate
}

// ResultMetadata contains metadata about the reconciliation process.
type ResultMetadata struct {
	// StartTime when reconciliation started
	StartTime time.Time

	// EndTime when reconciliation completed
	EndTime time.Time

	Duration time.Duration

	Sources []sources.ID

	// DryRun indicates if this was a dry-run
	DryRun bool

	// Statistics about the reconciliation
	Stats ResultStatistics
}

// ResultStatistics contains statistics about the reconciliation.
type ResultStatistics struct {
	ModelsProcessed    int
	ProvidersProcessed int
	ConflictsResolved  int
	ResourcesSkipped   int
	TotalTimeMs        int64
}

// IsSuccess returns true if the reconciliation was successful.
func (r *Result) IsSuccess() bool {
	return len(r.Errors) == 0
}

// HasChanges reports whether reconciliation detected changes.
func (r *Result) HasChanges() bool {
	return r.Changeset != nil && r.Changeset.HasChanges()
}

// WasApplied reports whether reconciliation applied changes.
func (r *Result) WasApplied() bool {
	return r.AppliedChanges != nil && r.AppliedChanges.HasChanges()
}

// Summary returns a human-readable summary of the result.
func (r *Result) Summary() string {
	if !r.IsSuccess() {
		return fmt.Sprintf("Reconciliation failed with %d errors", len(r.Errors))
	}

	if r.Metadata.DryRun {
		if r.HasChanges() {
			return fmt.Sprintf("Dry run completed. %s", r.Changeset.String())
		}
		return "Dry run completed. No changes detected."
	}

	if r.WasApplied() {
		return fmt.Sprintf("Reconciliation successful. %s", r.AppliedChanges.String())
	}

	if r.HasChanges() {
		return "Reconciliation completed. Changes detected but not applied."
	}

	return "Reconciliation completed. No changes detected."
}

// NewResult creates a new result with defaults.
func NewResult() *Result {
	return &Result{
		ProviderAPICounts: make(map[catalogs.ProviderID]int),
		ModelProviderMap:  make(map[string]catalogs.ProviderID),
		Provenance:        make(provenance.Map),
		Errors:            []error{},
		Warnings:          []string{},
		ReviewCandidates:  []evidence.ReviewCandidate{},
		Metadata: ResultMetadata{
			StartTime: time.Now(),
			Sources:   []sources.ID{},
		},
	}
}

// Finalize calculates duration and marks completion.
func (r *Result) Finalize() {
	r.Metadata.EndTime = time.Now()
	r.Metadata.Duration = r.Metadata.EndTime.Sub(r.Metadata.StartTime)
	r.Metadata.Stats.TotalTimeMs = r.Metadata.Duration.Milliseconds()
}
