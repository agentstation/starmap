package runtime

import (
	"testing"
	"time"

	"github.com/agentstation/starmap"
	"github.com/agentstation/starmap/pkg/catalogs/storage"
)

func TestLegacyEmbeddedBaselineAllowsExplicitObservation(t *testing.T) {
	store := storage.NewMemory()
	opts := []Option{WithCatalogSource("embedded"), WithStateDirectory(privateRuntimeDirectory(t)), WithClientOptions(starmap.WithCatalogStore(store))}
	connected := openTestRuntime(t, opts...)
	before := connected.State()
	observed := manualProviderObservation(t, 8192, time.Date(2026, 9, 8, 0, 0, 0, 0, time.UTC))
	updated, err := connected.PublishObservations(t.Context(), observed)
	if err != nil {
		t.Fatal(err)
	}
	if updated.Catalog.Providers().Len() < before.Catalog.Providers().Len() {
		t.Fatal("explicit observation removed baseline providers")
	}
	provider, err := updated.Catalog.Provider("provider")
	if err != nil {
		t.Fatal(err)
	}
	if provider.Models["model"] == nil || provider.Models["model"].Limits.ContextWindow != 8192 {
		t.Fatal("explicit observation did not survive baseline recovery")
	}
	if err := connected.Close(); err != nil {
		t.Fatal(err)
	}
	reopened := openTestRuntime(t, opts...)
	if reopened.State().PayloadChecksum != updated.PayloadChecksum {
		t.Fatal("reopen changed the accepted catalog")
	}
}
