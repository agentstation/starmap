package runtime

import (
	"encoding/json"
	"github.com/agentstation/starmap"
	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/catalogs/storage"
	"github.com/agentstation/starmap/pkg/provenance"
	"github.com/agentstation/starmap/pkg/sources"
	"os"
	"path/filepath"
	"testing"
	"time"
)

func TestWriteAcceptedLegacyUpgradeFixture(t *testing.T) {
	directory := os.Getenv("CSP3_LEGACY_FIXTURE")
	if directory == "" {
		t.Fatal("fixture directory is required")
	}
	if err := os.MkdirAll(filepath.Join(directory, "catalog"), 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.MkdirAll(filepath.Join(directory, "state"), 0700); err != nil {
		t.Fatal(err)
	}
	store, err := storage.NewFilesystem(filepath.Join(directory, "catalog"))
	if err != nil {
		t.Fatal(err)
	}
	source := newStubSource("legacy-upgrade-baseline")
	published := time.Date(2026, 9, 8, 0, 0, 0, 0, time.UTC)
	seed := manualProviderObservation(t, 0, published).Catalog
	payload, err := catalogs.EncodeCatalogPayload(seed)
	if err != nil {
		t.Fatal(err)
	}
	source.replies = []SourceRead{testSourceRead(t, "legacy-upgrade-baseline", payload, published)}
	opts := []Option{WithSource(source), WithStateDirectory(filepath.Join(directory, "state")), WithClientOptions(starmap.WithCatalogStore(store))}
	connected := openTestRuntime(t, opts...)
	if _, err := connected.RefreshSource(t.Context()); err != nil {
		t.Fatal(err)
	}
	before := connected.State()
	provider, err := before.Catalog.Provider("provider")
	if err != nil {
		t.Fatal(err)
	}
	known := provider.Models["model"]
	if known == nil {
		t.Fatal("compiled baseline lacks the selected offering")
	}
	model := &catalogs.Model{ID: known.ID, ModelRef: known.ModelRef, Name: known.Name, Extensions: catalogs.SourceExtensions{"private": {Fields: map[string]any{"sentinel": true}}}}
	provider.Models = map[string]*catalogs.Model{known.ID: model}
	builder := catalogs.NewEmpty()
	if err := builder.SetProvider(provider); err != nil {
		t.Fatal(err)
	}
	input, err := catalogs.NewObservationCatalog(builder)
	if err != nil {
		t.Fatal(err)
	}
	at := time.Date(2026, 9, 8, 0, 0, 0, 0, time.UTC)
	metadata := sources.ObservationMetadata{ObservedAt: at, Revision: sources.Revision{Kind: sources.RevisionKindContentDigest}, Completeness: sources.ObservationCompletenessComplete, Status: sources.ObservationStatusSucceeded, Records: sources.ObservationRecordCounts{Accepted: 1}}
	original, err := sources.NewObservation(sources.ProvidersID, input, metadata)
	if err != nil {
		t.Fatal(err)
	}
	entry := provenance.Entry{Source: original.SourceID, Field: "extensions", Value: model.Extensions, Timestamp: at, ObservationID: original.ID, ObservedAt: at, Revision: original.Revision, EvidenceChecksum: original.EvidenceChecksum}
	builder.SetProvenance(provenance.Map{"model:" + provenance.ModelResourceID("provider", known.ID) + ":extensions": {entry}})
	legacy, err := catalogs.NewObservationCatalog(builder)
	if err != nil {
		t.Fatal(err)
	}
	metadata.ObservedAt = at.Add(time.Minute)
	local, err := sources.NewObservation(sources.LocalCatalogID, legacy, metadata)
	if err != nil {
		t.Fatal(err)
	}
	accepted, err := connected.PublishObservations(t.Context(), local)
	if err != nil {
		t.Fatal(err)
	}
	data, err := json.Marshal(map[string]string{"generation_id": accepted.GenerationID, "payload_checksum": accepted.PayloadChecksum})
	if err != nil {
		t.Fatal(err)
	}
	if err := os.WriteFile(filepath.Join(directory, "accepted.json"), data, 0600); err != nil {
		t.Fatal(err)
	}
	if err := connected.Close(); err != nil {
		t.Fatal(err)
	}
}

func TestOpenAcceptedLegacyUpgradeFixture(t *testing.T) {
	directory := os.Getenv("CSP3_LEGACY_FIXTURE")
	if directory == "" {
		t.Fatal("fixture directory is required")
	}
	data, err := os.ReadFile(filepath.Join(directory, "accepted.json"))
	if err != nil {
		t.Fatal(err)
	}
	var expected map[string]string
	if err := json.Unmarshal(data, &expected); err != nil {
		t.Fatal(err)
	}
	store, err := storage.NewFilesystem(filepath.Join(directory, "catalog"))
	if err != nil {
		t.Fatal(err)
	}
	connected := openTestRuntime(t, WithSource(newStubSource("legacy-upgrade-baseline")), WithStateDirectory(filepath.Join(directory, "state")), WithClientOptions(starmap.WithCatalogStore(store)))
	if connected.State().GenerationID != expected["generation_id"] || connected.State().PayloadChecksum != expected["payload_checksum"] {
		t.Fatal("legacy upgrade did not preserve accepted catalog state")
	}
}
