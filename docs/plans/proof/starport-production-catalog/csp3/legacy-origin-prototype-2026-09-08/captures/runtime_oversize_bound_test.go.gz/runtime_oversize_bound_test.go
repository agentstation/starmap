package runtime

import (
	stderrors "errors"
	"github.com/agentstation/starmap"
	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/catalogs/storage"
	pkgerrors "github.com/agentstation/starmap/pkg/errors"
	"github.com/agentstation/starmap/pkg/provenance"
	"github.com/agentstation/starmap/pkg/sources"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"
)

func TestOversizedPublicationPreservesAcceptedState(t *testing.T) {
	directory := os.Getenv("CSP3_LEGACY_FIXTURE")
	if directory == "" {
		t.Fatal("fixture directory is required")
	}
	if err := os.MkdirAll(filepath.Join(directory, "catalog"), 0700); err != nil {
		t.Fatal(err)
	}
	if err := os.MkdirAll(filepath.Join(directory, "state"), 0700); err != nil {
		t.Fatal(err)
	}
	store, err := storage.NewFilesystem(filepath.Join(directory, "catalog"))
	if err != nil {
		t.Fatal(err)
	}
	opts := []Option{WithCatalogSource("embedded"), WithStateDirectory(filepath.Join(directory, "state")), WithClientOptions(starmap.WithCatalogStore(store))}
	connected := openTestRuntime(t, opts...)
	before := connected.State()
	provider, err := before.Catalog.Provider("openai")
	if err != nil {
		t.Fatal(err)
	}
	known := provider.Models["gpt-4o-mini"]
	if known == nil {
		t.Fatal("compiled baseline lacks the selected offering")
	}
	model := &catalogs.Model{ID: known.ID, ModelRef: known.ModelRef, Name: known.Name, Extensions: catalogs.SourceExtensions{"private": {Fields: map[string]any{"sentinel": strings.Repeat("x", 4<<20)}}}}
	provider.Models = map[string]*catalogs.Model{known.ID: model}
	builder := catalogs.NewEmpty()
	if err := builder.SetProvider(provider); err != nil {
		t.Fatal(err)
	}
	input, err := catalogs.NewObservationCatalog(builder)
	if err != nil {
		t.Fatal(err)
	}
	at := time.Date(2026, 9, 8, 0, 0, 0, 0, time.UTC)
	metadata := sources.ObservationMetadata{ObservedAt: at, Revision: sources.Revision{Kind: sources.RevisionKindContentDigest}, Completeness: sources.ObservationCompletenessComplete, Status: sources.ObservationStatusSucceeded, Records: sources.ObservationRecordCounts{Accepted: 1}}
	original, err := sources.NewObservation(sources.ProvidersID, input, metadata)
	if err != nil {
		t.Fatal(err)
	}
	entry := provenance.Entry{Source: original.SourceID, Field: "extensions", Value: model.Extensions, Timestamp: at, ObservationID: original.ID, ObservedAt: at, Revision: original.Revision, EvidenceChecksum: original.EvidenceChecksum}
	builder.SetProvenance(provenance.Map{"model:" + provenance.ModelResourceID("openai", known.ID) + ":extensions": {entry}})
	legacy, err := catalogs.NewObservationCatalog(builder)
	if err != nil {
		t.Fatal(err)
	}
	metadata.ObservedAt = at.Add(time.Minute)
	local, err := sources.NewObservation(sources.LocalCatalogID, legacy, metadata)
	if err != nil {
		t.Fatal(err)
	}
	_, err = connected.PublishObservations(t.Context(), local)
	var validation *pkgerrors.ValidationError
	if !stderrors.As(err, &validation) || validation.Field != "payload" {
		t.Fatalf("error=%v, want payload refusal", err)
	}
	after := connected.State()
	if after.GenerationID != before.GenerationID || after.PayloadChecksum != before.PayloadChecksum || after.Sequence != before.Sequence {
		t.Fatal("oversized candidate changed accepted state")
	}
	if connected.layers.manual != nil {
		t.Fatal("oversized candidate changed retained observations")
	}
	pending, err := connected.store.loadInputPublication()
	if err != nil || pending != nil {
		t.Fatalf("oversized candidate left publication state: %v", err)
	}
	if err := connected.Close(); err != nil {
		t.Fatal(err)
	}
	reopened := openTestRuntime(t, opts...)
	if reopened.State().PayloadChecksum != before.PayloadChecksum {
		t.Fatal("oversized candidate changed catalog after restart")
	}
}
