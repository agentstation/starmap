package runtime

import (
	"github.com/agentstation/starmap"
	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/catalogs/storage"
	"github.com/agentstation/starmap/pkg/sources"
	"testing"
	"time"
)

func TestAuthorshipRecoveryRetainsContributingReceiptProbe(t *testing.T) {
	compositeRecoveryProbe(t, "authors")
}

func compositeRecoveryProbe(t *testing.T, surface string) {
	at := time.Date(2026, 9, 8, 0, 0, 0, 0, time.UTC)
	seed := manualProviderObservation(t, 0, at).Catalog
	payload, err := catalogs.EncodeCatalogPayload(seed)
	if err != nil {
		t.Fatal(err)
	}
	source := newStubSource("metadata-recovery")
	source.replies = []SourceRead{testSourceRead(t, "metadata-baseline", payload, at)}
	store := storage.NewMemory()
	connected := openTestRuntime(t, WithSource(source), WithStateDirectory(privateRuntimeDirectory(t)), WithClientOptions(starmap.WithCatalogStore(store)))
	if _, err := connected.RefreshSource(t.Context()); err != nil {
		t.Fatal(err)
	}
	observe := func(partial bool) sources.Observation {
		builder, err := catalogs.NewBuilderFrom(seed)
		if err != nil {
			t.Fatal(err)
		}
		provider, err := builder.Provider("provider")
		if err != nil {
			t.Fatal(err)
		}
		model := provider.Models["model"]
		switch surface {
		case "authors":
			first := catalogs.Author{ID: "first-author", Name: "First Author"}
			second := catalogs.Author{ID: "second-author", Name: "Second Author"}
			if err := builder.SetAuthor(first); err != nil {
				t.Fatal(err)
			}
			if err := builder.SetAuthor(second); err != nil {
				t.Fatal(err)
			}
			model.Authors = []catalogs.Author{second}
			if partial {
				model.Authors = []catalogs.Author{first}
			}

		case "metadata":
			metadata := &catalogs.ModelMetadata{}
			if partial {
				metadata.SetOpenWeights(true)
			} else {
				metadata.Tags = []catalogs.ModelTag{"chat"}
			}
			model.Metadata = metadata
		case "mode":
			key := "prior"
			if !partial {
				key = "current"
			}
			model.Modes = map[string]catalogs.ModelMode{"fast": {Provider: &catalogs.ModelProviderMode{Headers: map[string]string{key: "present"}}}}
		case "extension":
			key := "prior"
			if !partial {
				key = "current"
			}
			model.Extensions = catalogs.SourceExtensions{"models.dev": {Fields: map[string]any{key: true}}}
		}
		if err := builder.SetProvider(provider); err != nil {
			t.Fatal(err)
		}
		catalog, err := catalogs.NewObservationCatalog(builder)
		if err != nil {
			t.Fatal(err)
		}
		receipt := sources.ObservationMetadata{ObservedAt: at.Add(2 * time.Minute), Revision: sources.Revision{Kind: sources.RevisionKindContentDigest}, Completeness: sources.ObservationCompletenessComplete, Status: sources.ObservationStatusSucceeded}
		if partial {
			receipt.ObservedAt = at.Add(time.Minute)
			receipt.Completeness, receipt.Status = sources.ObservationCompletenessPartial, sources.ObservationStatusDegraded
			receipt.Issues = []sources.ObservationIssue{{Scope: sources.ObservationIssueScopeRecord, Code: sources.ObservationIssueCodeInvalidRecord, Subject: "provider/invalid", Message: "A source record is invalid."}}
		}
		result, err := sources.NewObservation(sources.ProvidersID, catalog, receipt)
		if err != nil {
			t.Fatal(err)
		}
		return result
	}
	prior, current := observe(true), observe(false)
	for _, observation := range []sources.Observation{prior, current} {
		if _, err := connected.PublishObservations(t.Context(), observation); err != nil {
			t.Fatal(err)
		}
	}
	provider, err := connected.State().Catalog.Provider("provider")
	if err != nil {
		t.Fatal(err)
	}
	model := provider.Models["model"]
	foundAuthor := false
	for _, author := range model.Authors {
		foundAuthor = foundAuthor || author.ID == "first-author"
	}
	if !foundAuthor {
		t.Error("retained authorship disappeared")
	}
	generation, err := store.Current(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	found := false
	for _, receipt := range generation.Manifest.SourceObservations {
		found = found || receipt.ObservationID == prior.ID
	}
	if !found || !generation.Manifest.Degraded {
		t.Errorf("retained contribution receipt=%t degraded=%t, want both true", found, generation.Manifest.Degraded)
	}
}
