package catalogs

import (
	"encoding/json"
	"testing"
)

func TestArchitectureFlagPresenceProbe(t *testing.T) {
	for _, field := range []string{"quantized", "fine_tuned"} {
		for _, value := range []string{"missing", "null", "false", "true"} {
			t.Run(field+"/"+value, func(t *testing.T) {
				input := "{}"
				if value != "missing" {
					input = `{"` + field + `":` + value + `}`
				}
				var architecture ModelArchitecture
				if err := json.Unmarshal([]byte(input), &architecture); err != nil {
					t.Fatal(err)
				}
				encoded, err := json.Marshal(architecture)
				if err != nil {
					t.Fatal(err)
				}
				var fields map[string]json.RawMessage
				if err := json.Unmarshal(encoded, &fields); err != nil {
					t.Fatal(err)
				}
				got, present := fields[field]
				if value == "missing" {
					if present {
						t.Errorf("missing flag became %s", got)
					}
				} else if !present || string(got) != value {
					t.Errorf("flag=%s/%t, want %s", got, present, value)
				}
			})
		}
	}
}
