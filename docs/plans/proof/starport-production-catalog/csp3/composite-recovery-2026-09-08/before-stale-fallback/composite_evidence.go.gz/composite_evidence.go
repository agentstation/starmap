package reconciler

import (
	"maps"
	"slices"
	"strconv"

	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/catalogs/authority"
	"github.com/agentstation/starmap/pkg/provenance"
	"github.com/agentstation/starmap/pkg/sources"
)

// selectModelContribution selects one independently merged field and its receipt.
// A present nil is an explicit value, distinct from an omitted field.
func (merger *merger) selectModelContribution(identity modelIdentity, policy authority.Policy, models map[sources.ID]*catalogs.Model, history *map[string]provenance.Field, path string, get func(*catalogs.Model) (any, bool), set func(any)) sources.ID {
	field := policy
	field.EvidencePath = policy.Evidence() + path
	selected := merger.modelSourcesForValue(identity.providerID, identity.modelID, field, models, func(model *catalogs.Model) any {
		if model == nil {
			return nil
		}
		value, present := get(model)
		if !present {
			return nil
		}
		if value == nil {
			var explicitNull *string
			return explicitNull
		}
		return value
	})
	for _, source := range policy.SourceOrder {
		model := selected[source]
		if model == nil {
			continue
		}
		value, present := get(model)
		if !present {
			continue
		}
		set(value)
		merger.recordModelHistory(identity, history, field, source, value, "selected composite field by authority with its original receipt")
		return source
	}
	return ""
}

func compositeMapKey(value string) string { return "[" + strconv.Quote(value) + "]" }

func (merger *merger) mergeModeContributions(identity modelIdentity, target *catalogs.Model, policy authority.Policy, models map[sources.ID]*catalogs.Model, history *map[string]provenance.Field) {
	names := make(map[string]struct{})
	for _, model := range models {
		if model == nil {
			continue
		}
		for name := range model.Modes {
			names[name] = struct{}{}
		}
	}
	result := make(map[string]catalogs.ModelMode, len(names))
	for _, name := range slices.Sorted(maps.Keys(names)) {
		mode := catalogs.ModelMode{}
		path := compositeMapKey(name)
		selected := merger.selectModelContribution(identity, policy, models, history, path+".present", func(model *catalogs.Model) (any, bool) {
			_, present := model.Modes[name]
			return true, present
		}, func(any) {})
		present := selected != ""
		merger.selectModelContribution(identity, policy, models, history, path+".provider.present", func(model *catalogs.Model) (any, bool) {
			return true, model.Modes[name].Provider != nil
		}, func(any) { present = true; mode.Provider = &catalogs.ModelProviderMode{} })
		merger.selectModelContribution(identity, policy, models, history, path+".pricing", func(model *catalogs.Model) (any, bool) {
			price := model.Modes[name].Pricing
			return price, price != nil
		}, func(value any) { present = true; mode.Pricing = copyModelPricing(value.(*catalogs.ModelPricing)) })
		for _, body := range []bool{false, true} {
			keys := make(map[string]struct{})
			for _, model := range models {
				if model == nil || model.Modes[name].Provider == nil {
					continue
				}
				provider := model.Modes[name].Provider
				if body {
					for key := range provider.Body {
						keys[key] = struct{}{}
					}
				} else {
					for key := range provider.Headers {
						keys[key] = struct{}{}
					}
				}
			}
			part := ".provider.headers"
			if body {
				part = ".provider.body"
			}
			for _, key := range slices.Sorted(maps.Keys(keys)) {
				merger.selectModelContribution(identity, policy, models, history, path+part+compositeMapKey(key), func(model *catalogs.Model) (any, bool) {
					provider := model.Modes[name].Provider
					if provider == nil {
						return nil, false
					}
					if body {
						value, present := provider.Body[key]
						return value, present
					}
					value, present := provider.Headers[key]
					return value, present
				}, func(value any) {
					present = true
					if mode.Provider == nil {
						mode.Provider = &catalogs.ModelProviderMode{}
					}
					if body {
						if mode.Provider.Body == nil {
							mode.Provider.Body = make(map[string]any)
						}
						mode.Provider.Body[key] = catalogs.SourceExtension{Fields: map[string]any{key: value}}.Copy().Fields[key]
					} else {
						if mode.Provider.Headers == nil {
							mode.Provider.Headers = make(map[string]string)
						}
						mode.Provider.Headers[key] = value.(string)
					}
				})
			}
		}
		if present {
			result[name] = mode
		}
	}
	target.Modes = result
}

func (merger *merger) mergeExtensionContributions(identity modelIdentity, target *catalogs.Model, policy authority.Policy, models map[sources.ID]*catalogs.Model, history *map[string]provenance.Field) {
	keys := make(map[string]map[string]struct{})
	for _, model := range models {
		if model == nil {
			continue
		}
		for namespace, extension := range model.Extensions {
			if keys[namespace] == nil {
				keys[namespace] = make(map[string]struct{})
			}
			for key := range extension.Fields {
				keys[namespace][key] = struct{}{}
			}
		}
	}
	if len(keys) == 0 {
		return
	}
	result := make(catalogs.SourceExtensions, len(keys))
	if models[sources.LocalCatalogID] == nil {
		if baseline := merger.baselineModel(identity.providerID, identity.modelID); baseline != nil {
			for namespace, extension := range baseline.Extensions.Copy() {
				result[namespace] = extension
			}
		}
	}
	for _, namespace := range slices.Sorted(maps.Keys(keys)) {
		selected := merger.selectModelContribution(identity, policy, models, history, compositeMapKey(namespace)+".present", func(model *catalogs.Model) (any, bool) {
			_, present := model.Extensions[namespace]
			return true, present
		}, func(any) {})
		present := selected != ""
		extension := result[namespace]
		if extension.Fields == nil {
			extension.Fields = make(map[string]any)
		}
		for _, key := range slices.Sorted(maps.Keys(keys[namespace])) {
			merger.selectModelContribution(identity, policy, models, history, compositeMapKey(namespace)+".fields"+compositeMapKey(key), func(model *catalogs.Model) (any, bool) {
				value, present := model.Extensions[namespace].Fields[key]
				return value, present
			}, func(value any) {
				present = true
				extension.Fields[key] = catalogs.SourceExtension{Fields: map[string]any{key: value}}.Copy().Fields[key]
			})
		}
		if present {
			result[namespace] = extension
		} else {
			delete(result, namespace)
		}
	}
	target.Extensions = catalogs.NormalizeSourceExtensions(result)
}
