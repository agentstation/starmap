package reconciler

import (
	"testing"

	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/catalogs/authority"
	"github.com/agentstation/starmap/pkg/sources"
)

func TestCompositeContributionsPreserveEmptyRecordsAndCallerOwnership(t *testing.T) {
	policy := authority.New()
	merger := newMerger(policy, NewAuthorityStrategy(policy), nil)
	parent := "base"
	original := &catalogs.Model{ID: "model", Name: "Model", Metadata: &catalogs.ModelMetadata{Architecture: &catalogs.ModelArchitecture{}}, Modes: map[string]catalogs.ModelMode{"fast": {Provider: &catalogs.ModelProviderMode{}}}}
	models, _, err := merger.Models(map[sources.ID][]*catalogs.Model{sources.ProvidersID: {original}})
	if err != nil {
		t.Fatal(err)
	}
	if len(models) != 1 || models[0].Metadata.Architecture == nil || models[0].Modes["fast"].Provider == nil {
		t.Fatal("reconciliation lost a present empty record")
	}
	original.Metadata.Architecture.BaseModel = &parent
	original.Modes["fast"].Provider.Body = map[string]any{"nested": map[string]any{"value": "original"}}
	original.Extensions = catalogs.SourceExtensions{"source": {Fields: map[string]any{"nested": map[string]any{"value": "original"}}}}
	models, _, err = merger.Models(map[sources.ID][]*catalogs.Model{sources.ProvidersID: {original}})
	if err != nil {
		t.Fatal(err)
	}
	*models[0].Metadata.Architecture.BaseModel = "changed"
	models[0].Modes["fast"].Provider.Body["nested"].(map[string]any)["value"] = "changed"
	models[0].Extensions["source"].Fields["nested"].(map[string]any)["value"] = "changed"
	if parent != "base" || original.Modes["fast"].Provider.Body["nested"].(map[string]any)["value"] != "original" || original.Extensions["source"].Fields["nested"].(map[string]any)["value"] != "original" {
		t.Fatal("reconciliation returned mutable source aliases")
	}
}
