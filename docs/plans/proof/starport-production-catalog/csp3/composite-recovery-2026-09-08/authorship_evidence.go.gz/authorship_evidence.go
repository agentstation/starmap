package reconciler

import (
	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/catalogs/authority"
	"github.com/agentstation/starmap/pkg/provenance"
	"github.com/agentstation/starmap/pkg/sources"
)

// mergeAuthorshipContributions records each author membership independently.
func (merger *merger) mergeAuthorshipContributions(identity modelIdentity, target *catalogs.Model, policy authority.Policy, models map[sources.ID]*catalogs.Model, history *map[string]provenance.Field) {
	ids := make([]catalogs.AuthorID, 0)
	seen := make(map[catalogs.AuthorID]bool)
	for _, source := range policy.SourceOrder {
		if model := models[source]; model != nil {
			for _, author := range model.Authors {
				if !seen[author.ID] {
					ids = append(ids, author.ID)
					seen[author.ID] = true
				}
			}
		}
	}
	var baseline *catalogs.Model
	if models[sources.LocalCatalogID] == nil {
		baseline = merger.baselineModel(identity.providerID, identity.modelID)
		if baseline != nil {
			for _, author := range baseline.Authors {
				if !seen[author.ID] {
					ids = append(ids, author.ID)
					seen[author.ID] = true
				}
			}
		}
	}
	result := make([]catalogs.Author, 0, len(ids))
	for _, id := range ids {
		source := merger.selectModelContribution(identity, policy, models, history, compositeMapKey(string(id))+".present", func(model *catalogs.Model) (any, bool) {
			_, present := modelAuthor(model, id)
			return true, present
		}, func(any) {})
		author, present := modelAuthor(baseline, id)
		if source != "" {
			author, present = modelAuthor(models[source], id)
			if !present {
				author, present = modelAuthor(models[sources.LocalCatalogID], id)
			}
		}
		if present {
			result = append(result, author)
		}
	}
	target.Authors = catalogs.DeepCopyModel(catalogs.Model{Authors: result}).Authors
	merger.recordCompositeSummary(history, policy, target.Authors)
}

func modelAuthor(model *catalogs.Model, id catalogs.AuthorID) (catalogs.Author, bool) {
	if model != nil {
		for _, author := range model.Authors {
			if author.ID == id {
				return author, true
			}
		}
	}
	return catalogs.Author{}, false
}
