package reconciler

import (
	"github.com/agentstation/starmap/pkg/provenance"
	"strconv"
	"strings"
	"testing"
	"time"

	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/catalogs/authority"
	"github.com/agentstation/starmap/pkg/sources"
)

func TestCompositeContributionsPreserveEmptyRecordsAndCallerOwnership(t *testing.T) {
	policy := authority.New()
	merger := newMerger(policy, NewAuthorityStrategy(policy), nil)
	parent := "base"
	original := &catalogs.Model{ID: "model", Name: "Model", Metadata: &catalogs.ModelMetadata{Architecture: &catalogs.ModelArchitecture{}}, Modes: map[string]catalogs.ModelMode{"fast": {Provider: &catalogs.ModelProviderMode{}}}}
	models, _, err := merger.Models(map[sources.ID][]*catalogs.Model{sources.ProvidersID: {original}})
	if err != nil {
		t.Fatal(err)
	}
	if len(models) != 1 || models[0].Metadata.Architecture == nil || models[0].Modes["fast"].Provider == nil {
		t.Fatal("reconciliation lost a present empty record")
	}
	original.Metadata.Architecture.BaseModel = &parent
	original.Modes["fast"].Provider.Body = map[string]any{"nested": map[string]any{"value": "original"}}
	original.Extensions = catalogs.SourceExtensions{"source": {Fields: map[string]any{"nested": map[string]any{"value": "original"}}}}
	models, _, err = merger.Models(map[sources.ID][]*catalogs.Model{sources.ProvidersID: {original}})
	if err != nil {
		t.Fatal(err)
	}
	*models[0].Metadata.Architecture.BaseModel = "changed"
	models[0].Modes["fast"].Provider.Body["nested"].(map[string]any)["value"] = "changed"
	models[0].Extensions["source"].Fields["nested"].(map[string]any)["value"] = "changed"
	if parent != "base" || original.Modes["fast"].Provider.Body["nested"].(map[string]any)["value"] != "original" || original.Extensions["source"].Fields["nested"].(map[string]any)["value"] != "original" {
		t.Fatal("reconciliation returned mutable source aliases")
	}
}

func TestCompositeProjectionPolicyRejectsCarriedFactsAndAllowsEdits(t *testing.T) {
	for _, edited := range []bool{false, true} {
		t.Run(strconv.FormatBool(edited), func(t *testing.T) {
			metadata := &catalogs.ModelMetadata{Architecture: &catalogs.ModelArchitecture{}}
			metadata.SetOpenWeights(true)
			input := sourceIdentityCatalog(t, "", catalogs.Model{ID: "shared", Name: "Shared", Metadata: metadata, Modes: map[string]catalogs.ModelMode{"fast": {Provider: &catalogs.ModelProviderMode{Headers: map[string]string{"value": "original"}}}}, Extensions: catalogs.SourceExtensions{"source": {Fields: map[string]any{"value": "original"}}}})
			original := sourceIdentityObservation(t, sources.ProvidersID, input, time.Date(2026, 9, 8, 0, 0, 0, 0, time.UTC))
			generated := sourceIdentityReconcile(t, sources.ProvidersID, original)
			local := snapshotForTest(t, generated.Catalog)
			if edited {
				builder, err := catalogs.NewBuilderFrom(local)
				if err != nil {
					t.Fatal(err)
				}
				provider, err := builder.Provider("provider-a")
				if err != nil {
					t.Fatal(err)
				}
				model := provider.Models["shared"]
				model.Metadata.SetOpenWeights(false)
				model.Modes["fast"].Provider.Headers["value"] = "edited"
				model.Extensions["source"].Fields["value"] = "edited"
				if err := builder.SetProvider(provider); err != nil {
					t.Fatal(err)
				}
				local, err = builder.Build()
				if err != nil {
					t.Fatal(err)
				}
			}
			observation := sourceIdentityObservation(t, sources.LocalCatalogID, local, original.ObservedAt.Add(time.Minute))
			reconcile, err := New(WithBaseline(local), WithProjectedEvidencePolicy(func(_ catalogs.ProviderID, entry provenance.Entry) bool {
				composite := strings.HasPrefix(entry.Field, "metadata") || strings.HasPrefix(entry.Field, "modes") || strings.HasPrefix(entry.Field, "extensions")
				return !composite || entry.ObservationID != original.ID
			}))
			if err != nil {
				t.Fatal(err)
			}
			result, err := reconcile.Sources(t.Context(), sources.LocalCatalogID, []sources.Observation{observation})
			if err != nil {
				t.Fatal(err)
			}
			provider, err := result.Catalog.Provider("provider-a")
			if err != nil {
				t.Fatal(err)
			}
			model := provider.Models["shared"]
			if !edited {
				if model.Metadata != nil || len(model.Modes) != 0 || len(model.Extensions) != 0 {
					t.Fatalf("rejected composite facts survived: metadata=%+v modes=%+v extensions=%+v", model.Metadata, model.Modes, model.Extensions)
				}
				return
			}
			open, presence := model.Metadata.OpenWeightsValue()
			if open || presence != catalogs.ValueKnown || model.Modes["fast"].Provider.Headers["value"] != "edited" || model.Extensions["source"].Fields["value"] != "edited" {
				t.Fatal("projection policy discarded an explicit operator edit")
			}
		})
	}
}

func TestCompositeStaleFallbackPreservesAcceptedBaseline(t *testing.T) {
	at := time.Date(2026, 9, 8, 0, 0, 0, 0, time.UTC)
	baselineModel := catalogs.Model{ID: "shared", Name: "Shared", Metadata: &catalogs.ModelMetadata{}, Modes: map[string]catalogs.ModelMode{"fast": {Provider: &catalogs.ModelProviderMode{Headers: map[string]string{"value": "accepted"}}}}, Extensions: catalogs.SourceExtensions{"source": {Fields: map[string]any{"value": "accepted"}}}}
	baselineModel.Metadata.SetOpenWeights(false)
	baseline := sourceIdentityCatalog(t, "", baselineModel)
	candidateModel := catalogs.DeepCopyModel(baselineModel)
	candidateModel.Metadata.SetOpenWeights(true)
	candidateModel.Modes["fast"].Provider.Headers["value"] = "stale"
	candidateModel.Extensions["source"].Fields["value"] = "stale"
	candidate := sourceIdentityCatalog(t, "", candidateModel)
	observation, err := sources.NewObservation(sources.ProvidersID, candidate, sources.ObservationMetadata{ObservedAt: at, Revision: sources.Revision{Kind: sources.RevisionKindContentDigest}, Completeness: sources.ObservationCompletenessPartial, Status: sources.ObservationStatusDegraded, Issues: []sources.ObservationIssue{{Scope: sources.ObservationIssueScopeStaleFallback, Code: sources.ObservationIssueCodeStaleFallback, Message: "A source returned stale fallback data."}}})
	if err != nil {
		t.Fatal(err)
	}
	result, err := ReconcileObservations(t.Context(), baseline, []sources.Observation{observation})
	if err != nil {
		t.Fatal(err)
	}
	provider, err := result.Catalog.Provider("provider-a")
	if err != nil {
		t.Fatal(err)
	}
	model := provider.Models["shared"]
	open, presence := model.Metadata.OpenWeightsValue()
	if open || presence != catalogs.ValueKnown {
		t.Error("stale metadata replaced the accepted baseline")
	}
	mode, exists := model.Modes["fast"]
	if !exists || mode.Provider == nil || mode.Provider.Headers["value"] != "accepted" {
		t.Error("stale mode data erased or replaced the accepted baseline")
	}
	if model.Extensions["source"].Fields["value"] != "accepted" {
		t.Error("stale extensions erased or replaced the accepted baseline")
	}
	for _, field := range []string{"metadata", "modes", "extensions"} {
		for _, entry := range result.Catalog.Provenance().FindModelField("provider-a", "shared", field) {
			if entry.ObservationID == observation.ID {
				t.Errorf("%s summary claimed rejected stale evidence", field)
			}
		}
	}
}
