package reconciler

import (
	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/catalogs/authority"
	"github.com/agentstation/starmap/pkg/sources"
	"testing"
)

func TestUnknownDescriptionWithoutFallbackProbe(t *testing.T) {
	policy := authority.New()
	merger := newMerger(policy, NewAuthorityStrategy(policy), nil)
	model := &catalogs.Model{ID: "model", Name: "Model"}
	model.SetDescriptionUnknown()
	merged, _, err := merger.Models(map[sources.ID][]*catalogs.Model{sources.ProvidersID: {model}})
	if err != nil {
		t.Fatal(err)
	}
	if len(merged) != 1 {
		t.Fatalf("merged models=%d, want one", len(merged))
	}
	_, presence := merged[0].DescriptionValue()
	if presence != catalogs.ValueUnknown {
		t.Errorf("description presence=%v, want unknown", presence)
	}
}
