package runtime

import (
	"github.com/agentstation/starmap"
	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/catalogs/storage"
	"github.com/agentstation/starmap/pkg/sources"
	"testing"
	"time"
)

func TestMetadataRecoveryRetainsContributingReceiptProbe(t *testing.T) {
	at := time.Date(2026, 9, 8, 0, 0, 0, 0, time.UTC)
	seed := manualProviderObservation(t, 0, at).Catalog
	payload, err := catalogs.EncodeCatalogPayload(seed)
	if err != nil {
		t.Fatal(err)
	}
	source := newStubSource("metadata-recovery")
	source.replies = []SourceRead{testSourceRead(t, "metadata-baseline", payload, at)}
	store := storage.NewMemory()
	connected := openTestRuntime(t, WithSource(source), WithStateDirectory(privateRuntimeDirectory(t)), WithClientOptions(starmap.WithCatalogStore(store)))
	if _, err := connected.RefreshSource(t.Context()); err != nil {
		t.Fatal(err)
	}
	observe := func(partial bool) sources.Observation {
		builder, err := catalogs.NewBuilderFrom(seed)
		if err != nil {
			t.Fatal(err)
		}
		provider, err := builder.Provider("provider")
		if err != nil {
			t.Fatal(err)
		}
		metadata := &catalogs.ModelMetadata{}
		if partial {
			metadata.SetOpenWeights(true)
		} else {
			metadata.Tags = []catalogs.ModelTag{"chat"}
		}
		provider.Models["model"].Metadata = metadata
		if err := builder.SetProvider(provider); err != nil {
			t.Fatal(err)
		}
		catalog, err := catalogs.NewObservationCatalog(builder)
		if err != nil {
			t.Fatal(err)
		}
		receipt := sources.ObservationMetadata{ObservedAt: at.Add(2 * time.Minute), Revision: sources.Revision{Kind: sources.RevisionKindContentDigest}, Completeness: sources.ObservationCompletenessComplete, Status: sources.ObservationStatusSucceeded}
		if partial {
			receipt.ObservedAt = at.Add(time.Minute)
			receipt.Completeness, receipt.Status = sources.ObservationCompletenessPartial, sources.ObservationStatusDegraded
			receipt.Issues = []sources.ObservationIssue{{Scope: sources.ObservationIssueScopeRecord, Code: sources.ObservationIssueCodeInvalidRecord, Subject: "provider/invalid", Message: "A source record is invalid."}}
		}
		result, err := sources.NewObservation(sources.ProvidersID, catalog, receipt)
		if err != nil {
			t.Fatal(err)
		}
		return result
	}
	prior, current := observe(true), observe(false)
	for _, observation := range []sources.Observation{prior, current} {
		if _, err := connected.PublishObservations(t.Context(), observation); err != nil {
			t.Fatal(err)
		}
	}
	provider, err := connected.State().Catalog.Provider("provider")
	if err != nil {
		t.Fatal(err)
	}
	open, presence := provider.Models["model"].Metadata.OpenWeightsValue()
	if !open || presence != catalogs.ValueKnown {
		t.Errorf("retained open weights = %t/%v, want true/known", open, presence)
	}
	generation, err := store.Current(t.Context())
	if err != nil {
		t.Fatal(err)
	}
	found := false
	for _, receipt := range generation.Manifest.SourceObservations {
		found = found || receipt.ObservationID == prior.ID
	}
	if !found || !generation.Manifest.Degraded {
		t.Errorf("retained metadata receipt=%t degraded=%t, want both true", found, generation.Manifest.Degraded)
	}
}
