package catalogs

import (
	"encoding/json"
	"testing"
)

func TestOptionalModelRecordsPreserveExplicitNullProbe(t *testing.T) {
	for _, field := range []string{"description", "pricing", "limits", "features", "metadata", "lineage", "attachments", "generation", "reasoning", "reasoning_tokens", "verbosity", "tools", "response", "deprecated_at", "retires_at"} {
		t.Run(field, func(t *testing.T) {
			var model Model
			if err := json.Unmarshal([]byte(`{"id":"model","name":"Model","`+field+`":null}`), &model); err != nil {
				t.Fatal(err)
			}
			encoded, err := json.Marshal(model)
			if err != nil {
				t.Fatal(err)
			}
			var fields map[string]json.RawMessage
			if err := json.Unmarshal(encoded, &fields); err != nil {
				t.Fatal(err)
			}
			value, exists := fields[field]
			if !exists || string(value) != "null" {
				t.Errorf("explicit null lost: present=%t value=%s", exists, value)
			}
		})
	}
}
