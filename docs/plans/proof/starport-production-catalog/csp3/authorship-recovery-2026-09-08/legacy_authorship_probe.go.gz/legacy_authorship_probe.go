package reconciler

import (
	"github.com/agentstation/starmap/pkg/catalogs"
	"github.com/agentstation/starmap/pkg/provenance"
	"github.com/agentstation/starmap/pkg/sources"
	"strings"
	"testing"
	"time"
)

func TestLegacyAggregateAuthorshipCannotBypassProjectionPolicyProbe(t *testing.T) {
	at := time.Date(2026, 9, 8, 0, 0, 0, 0, time.UTC)
	original := sourceIdentityObservation(t, sources.ProvidersID, authorshipCatalog(t, catalogs.Author{ID: "first-author", Name: "First"}), at)
	generated := sourceIdentityReconcile(t, sources.ProvidersID, original)
	builder, err := catalogs.NewBuilderFrom(snapshotForTest(t, generated.Catalog))
	if err != nil {
		t.Fatal(err)
	}
	evidence := builder.Provenance().Map()
	for key, entries := range evidence {
		if len(entries) > 0 && strings.HasPrefix(entries[0].Field, "Authors[") {
			delete(evidence, key)
		}
	}
	builder.SetProvenance(evidence)
	legacy, err := builder.Build()
	if err != nil {
		t.Fatal(err)
	}
	if len(legacy.Provenance().FindModelField("provider-a", "shared", "Authors")) == 0 {
		t.Fatal("fixture lost the legacy aggregate receipt")
	}
	local := sourceIdentityObservation(t, sources.LocalCatalogID, legacy, at.Add(time.Minute))
	reconcile, err := New(WithBaseline(legacy), WithProjectedEvidencePolicy(func(_ catalogs.ProviderID, entry provenance.Entry) bool {
		return !strings.HasPrefix(entry.Field, "Authors") || entry.ObservationID != original.ID
	}))
	if err != nil {
		t.Fatal(err)
	}
	result, err := reconcile.Sources(t.Context(), sources.LocalCatalogID, []sources.Observation{local})
	if err != nil {
		t.Fatal(err)
	}
	provider, err := result.Catalog.Provider("provider-a")
	if err != nil {
		t.Fatal(err)
	}
	if len(provider.Models["shared"].Authors) != 0 {
		t.Error("legacy aggregate membership bypassed the projection policy")
	}
}
