#!/usr/bin/env python3
"""Check the complete race package roster and failure propagation."""

import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
MODULE = "example.test/catalog"
RUNTIME = MODULE + "/runtime"
ROSTER = [MODULE, RUNTIME, MODULE + "/runtime/source", MODULE + "/internal/catalog", MODULE + "/runtime/status"]


class RaceVerifierTests(unittest.TestCase):
    def run_verifier(self, roster=ROSTER, failure=""):
        with tempfile.TemporaryDirectory() as directory:
            temporary = Path(directory)
            executable = temporary / "go"
            executable.write_text(
                f"#!{sys.executable}\n"
                "import json, os, sys\n"
                "args = sys.argv[1:]\n"
                "failure = os.environ.get('RACE_FIXTURE_FAILURE', '')\n"
                "if args == ['list', '-m']:\n"
                "    print('example.test/catalog')\n"
                "elif args == ['list', '-race', './...']:\n"
                "    if failure == 'discovery': sys.exit(11)\n"
                "    print(os.environ['RACE_FIXTURE_ROSTER'])\n"
                "elif args and args[0] == 'test':\n"
                "    with open(os.environ['RACE_FIXTURE_LOG'], 'a') as output:\n"
                "        output.write(json.dumps({'args': args, 'cgo': os.environ.get('CGO_ENABLED')}) + '\\n')\n"
                "    runtime = 'example.test/catalog/runtime' in args\n"
                "    if runtime and failure == 'runtime': sys.exit(17)\n"
                "    if not runtime and failure == 'other': sys.exit(23)\n"
                "else:\n"
                "    sys.exit(31)\n"
            )
            executable.chmod(0o755)
            log = temporary / "calls.jsonl"
            env = dict(os.environ, PATH=str(temporary) + os.pathsep + os.environ['PATH'],
                       RACE_FIXTURE_ROSTER="\n".join(roster), RACE_FIXTURE_LOG=str(log),
                       RACE_FIXTURE_FAILURE=failure, CGO_ENABLED="0")
            result = subprocess.run(['bash', str(ROOT / 'scripts/verify-race-tests.sh')],
                                    env=env, capture_output=True, text=True, timeout=10, check=False)
            calls = [json.loads(line) for line in log.read_text().splitlines()] if log.exists() else []
            return result, calls

    def test_complete_roster_runs_once_with_runtime_first(self):
        result, calls = self.run_verifier()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertEqual(len(calls), 2)
        self.assertEqual(calls[0]['args'], ['test', RUNTIME, '-race', '-short', '-timeout=20m', '-p=2'])
        self.assertEqual(calls[1]['args'], ['test', *[p for p in ROSTER if p != RUNTIME], '-race', '-short', '-timeout=20m', '-p=2'])
        self.assertTrue(all(call['cgo'] == '1' for call in calls))

    def test_runtime_failure_stops_before_other_packages(self):
        result, calls = self.run_verifier(failure='runtime')
        self.assertEqual(result.returncode, 17)
        self.assertEqual(len(calls), 1)

    def test_other_package_failure_propagates(self):
        result, calls = self.run_verifier(failure='other')
        self.assertEqual(result.returncode, 23)
        self.assertEqual(len(calls), 2)

    def test_discovery_failure_runs_no_tests(self):
        result, calls = self.run_verifier(failure='discovery')
        self.assertEqual(result.returncode, 11)
        self.assertEqual(calls, [])

    def test_missing_or_duplicate_runtime_refuses(self):
        for roster in [[MODULE], [MODULE, RUNTIME, RUNTIME], [RUNTIME], []]:
            with self.subTest(roster=roster):
                result, calls = self.run_verifier(roster)
                self.assertNotEqual(result.returncode, 0)
                self.assertEqual(calls, [])

    def test_main_verifier_runs_roster_tests_and_race_runner(self):
        script = (ROOT / 'scripts/verify.sh').read_text()
        self.assertIn('run python3 ./scripts/test_race_verifier.py', script)
        self.assertIn('run ./scripts/verify-race-tests.sh', script)


if __name__ == '__main__':
    unittest.main()
