#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
cd "$ROOT"
export CGO_ENABLED=1

module="$(go list -m)"
roster="$(go list -race ./...)"
runtime_package="$module/runtime"
runtime_count=0
other_packages=()
while IFS= read -r package; do
  if [[ "$package" == "$runtime_package" ]]; then
    runtime_count=$((runtime_count + 1))
  elif [[ -n "$package" ]]; then
    other_packages+=("$package")
  fi
done <<< "$roster"

if [[ "$runtime_count" != 1 || "${#other_packages[@]}" == 0 ]]; then
  printf 'Race package discovery must contain runtime once and the remaining packages.\n' >&2
  exit 1
fi

# Keep the complete runtime package separate from other test processes.
# Both stages preserve the race detector and the package deadline.
printf '\n==> runtime race tests\n'
go test "$runtime_package" -race -short -timeout=20m -p=2
printf '\n==> remaining package race tests\n'
go test "${other_packages[@]}" -race -short -timeout=20m -p=2
