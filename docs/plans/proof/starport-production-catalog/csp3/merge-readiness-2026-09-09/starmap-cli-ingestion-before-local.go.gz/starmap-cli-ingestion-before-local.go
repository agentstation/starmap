package app

import (
	"context"
	"encoding/json"
	"io"
	"net/http"
	"net/http/httptest"
	"path/filepath"
	"sync/atomic"
	"testing"

	testcatalog "github.com/agentstation/starmap/internal/test/catalog"
	"github.com/agentstation/starmap/pkg/catalogs"
	catalogconfig "github.com/agentstation/starmap/pkg/catalogs/config"
	"github.com/agentstation/starmap/pkg/sources"
)

func TestCLIRefreshIngestsProviderAndLocalEvidence(t *testing.T) {
	clearCatalogEnvironment(t)
	t.Setenv("STARMAP_HOME", t.TempDir())
	var limit atomic.Int64
	var partial atomic.Bool
	var calls atomic.Int32
	limit.Store(131072)
	api := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		calls.Add(1)
		if r.URL.Path != "/models" {
			t.Errorf("unexpected catalog path %s", r.URL.Path)
		}
		records := []map[string]any{{"id": "known", "object": "model", "name": "API name", "context_window": limit.Load()}}
		if partial.Load() {
			records = append(records, map[string]any{"object": "model"})
		}
		w.Header().Set("Content-Type", "application/json")
		if err := json.NewEncoder(w).Encode(map[string]any{"object": "list", "data": records}); err != nil {
			t.Error(err)
		}
	}))
	defer api.Close()
	workspace := catalogs.NewEmpty()
	if err := workspace.SetAuthor(catalogs.Author{ID: "acme", Name: "Acme"}); err != nil {
		t.Fatal(err)
	}
	if err := workspace.SetAuthorModel("acme", catalogs.Model{ID: "known", Name: "Known", Authors: []catalogs.Author{{ID: "acme", Name: "Acme"}}}); err != nil {
		t.Fatal(err)
	}
	credentials := testcatalog.APIKeyCredentials("ACME_API_KEY", "Authorization", catalogs.ProviderCredentialSchemeBearer)
	provider := catalogs.Provider{ID: "acme", Name: "Acme", Credentials: credentials, Catalog: &catalogs.ProviderCatalog{Endpoint: catalogs.ProviderEndpoint{Type: catalogs.EndpointTypeOpenAI, URL: api.URL + "/models", ProtocolOptions: testcatalog.OpenAIProtocolOptions(), FieldMappings: []catalogs.FieldMapping{{From: "context_window", To: "limits.context_window"}}}}, Models: map[string]*catalogs.Model{"known": {ID: "known", ModelRef: "acme/known", Name: "Reviewed offering"}}}
	if err := workspace.SetProvider(provider); err != nil {
		t.Fatal(err)
	}
	path := filepath.Join(t.TempDir(), "workspace")
	if err := workspace.SaveTo(path); err != nil {
		t.Fatal(err)
	}
	open := func() *App {
		application, err := New("test", "test", "test", "test", WithConfig(&Config{Quiet: true, CatalogPath: path, CatalogValues: map[string]string{catalogconfig.Source: "embedded", catalogconfig.AcquisitionEnabled: "false", catalogconfig.SourcePollInterval: "0s"}}))
		if err != nil {
			t.Fatal(err)
		}
		application.credentialResolver = sources.ProviderCredentialResolverFunc(func(_ context.Context, p *catalogs.Provider) (sources.ProviderCredentialMaterial, error) {
			return testcatalog.APIKeyMaterial(p.Credentials, "fixture-key"), nil
		})
		t.Cleanup(func() {
			if err := application.Shutdown(context.Background()); err != nil {
				t.Error(err)
			}
		})
		return application
	}
	application := open()
	run := func(source string) {
		command := application.NewUpdateCommand()
		command.SetOut(io.Discard)
		command.SetErr(io.Discard)
		command.SetArgs([]string{"acme", "--source", source, "--yes", "--catalog-path", path})
		if err := command.ExecuteContext(t.Context()); err != nil {
			t.Fatal(err)
		}
	}
	assertModel := func(want int64, description string) {
		t.Helper()
		connected, err := application.Runtime(t.Context())
		if err != nil {
			t.Fatal(err)
		}
		provider, err := connected.State().Catalog.Provider("acme")
		if err != nil {
			t.Fatal(err)
		}
		model := provider.Models["known"]
		if model == nil || model.Limits == nil || model.Limits.ContextWindow != want || model.Description != description {
			t.Fatalf("catalog model=%+v; want context %d and description %q", model, want, description)
		}
	}
	run("provider-api")
	assertModel(131072, "")
	authored, err := catalogs.New(catalogs.WithPath(path))
	if err != nil {
		t.Fatal(err)
	}
	edited, err := authored.Provider("acme")
	if err != nil {
		t.Fatal(err)
	}
	edited.Models["known"].Description = "Operator fixture"
	if err := authored.SetProvider(edited); err != nil {
		t.Fatal(err)
	}
	if err := authored.SaveTo(path); err != nil {
		t.Fatal(err)
	}
	before := calls.Load()
	run("local")
	if calls.Load() != before {
		t.Fatal("local refresh contacted the provider")
	}
	assertModel(131072, "Operator fixture")
	limit.Store(262144)
	partial.Store(true)
	run("provider-api")
	assertModel(262144, "Operator fixture")
	if err := application.Shutdown(context.Background()); err != nil {
		t.Fatal(err)
	}
	application = open()
	assertModel(262144, "Operator fixture")
}
