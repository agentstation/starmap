package reconciler
import (
 "testing"
 "time"
 "github.com/agentstation/starmap/pkg/catalogs"
 "github.com/agentstation/starmap/pkg/sources"
)
func TestLegacyProjectionDoesNotInventLocalEvidence(t *testing.T) {
 input := sourceIdentityCatalog(t, "", catalogs.Model{ID: "shared", Name:"Shared", Metadata: &catalogs.ModelMetadata{Tags: []catalogs.ModelTag{"chat"}}, Extensions: catalogs.SourceExtensions{"source": {Fields: map[string]any{"fact":true}}}})
 original := sourceIdentityObservation(t, sources.ProvidersID, input, time.Date(2026,9,8,0,0,0,0,time.UTC))
 generated := sourceIdentityReconcile(t, sources.ProvidersID, original)
 localCatalog := aggregateOnlyCompositeCatalog(t, snapshotForTest(t,generated.Catalog))
 local := sourceIdentityObservation(t,sources.LocalCatalogID,localCatalog,original.ObservedAt.Add(time.Minute))
 result := sourceIdentityReconcile(t,sources.LocalCatalogID,local)
 for _,field := range []string{`metadata.tags["chat"]`, `extensions["source"].fields["fact"]`} {
  for _,entry := range result.Catalog.Provenance().FindModelField("provider-a","shared",field) {
   if entry.ObservationID==local.ID { t.Errorf("%s acquired a new local identity without a semantic edit",field) }
  }
 }
}
