package reconciler
import (
 "testing"
 "time"
 "github.com/agentstation/starmap/pkg/catalogs"
 "github.com/agentstation/starmap/pkg/catalogs/authority"
 "github.com/agentstation/starmap/pkg/sources"
)
func TestExcludedOriginCannotBecomeALocalClaim(t *testing.T) {
 metadata:=&catalogs.ModelMetadata{};metadata.SetOpenWeights(true)
 input:=sourceIdentityCatalog(t,"",catalogs.Model{ID:"shared",Name:"Shared",Metadata:metadata})
 original:=sourceIdentityObservation(t,sources.ProvidersID,input,time.Date(2026,9,8,0,0,0,0,time.UTC))
 generated:=sourceIdentityReconcile(t,sources.ProvidersID,original)
 localCatalog:=snapshotForTest(t,generated.Catalog)
 local:=sourceIdentityObservation(t,sources.LocalCatalogID,localCatalog,original.ObservedAt.Add(time.Minute))
 policies:=authority.New()
 merger:=newMerger(policies,NewAuthorityStrategy(policies),localCatalog)
 merger.setObservations([]sources.Observation{local})
 provider,err:=localCatalog.Provider("provider-a");if err!=nil {t.Fatal(err)}
 selected:=merger.modelSourcesForValue("provider-a","shared",authority.Policy{Path:"Metadata",EvidencePath:"metadata.open_weights",SourceOrder:[]sources.ID{sources.LocalCatalogID}},map[sources.ID]*catalogs.Model{sources.LocalCatalogID:provider.Models["shared"]},func(model *catalogs.Model) any { value,_:=model.Metadata.OpenWeightsValue();return value })
 if selected[sources.LocalCatalogID]!=nil {t.Fatal("unchanged excluded provider evidence remains eligible as a local claim")}
}
