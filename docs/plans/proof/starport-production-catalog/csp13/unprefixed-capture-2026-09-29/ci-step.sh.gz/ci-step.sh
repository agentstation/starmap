"$RUNNER_TEMP/recovery-objectstore-bin/minio" server "$RUNNER_TEMP/recovery-objectstore-data" \
  --address 127.0.0.1:9000 > recovery-objectstore.log 2>&1 &
objectstore_pid=$!
trap 'kill "$objectstore_pid" 2>/dev/null || true; wait "$objectstore_pid" 2>/dev/null || true' EXIT
curl --fail --silent --show-error --retry 15 --retry-connrefused \
  --retry-delay 1 --max-time 3 "$TEST_BLOB_S3_ENDPOINT/minio/health/live"
go test -json -race -count=1 -timeout 5m ./internal/limits/reservation ./internal/jobs > fleet-reservation-jobs.jsonl
# Separate the full runtime from transfer adapters to bound peak memory.
go test -json -race -count=1 -p 1 -timeout 10m \
  ./internal/storage ./internal/sqlstore ./internal/blob ./internal/recovery > backup-storage.jsonl
go test -json -race -count=1 -timeout 7m ./internal/catalog \
  -run '^TestCapturedFleetCatalogNativeReferences$' > backup-catalog.jsonl
go test -json -race -count=1 -timeout 5m ./internal/app \
  -run '^(TestRestoreApplicationSharedRecipe|TestRestorePublishFilesSharedRecipe|TestUnprefixedBackup.*)$' > backup-application.jsonl
