import json,os,subprocess,sys
info=json.loads(subprocess.check_output(['docker','inspect','csp13-unprefixed-valkey-20260929']))[0]
port=info['NetworkSettings']['Ports']['6379/tcp'][0]['HostPort']
env=os.environ.copy();env['GOWORK']='off';env['CGO_ENABLED']='0';env['TEST_VALKEY_URL']='redis://127.0.0.1:'+port
with open(sys.argv[1],'w') as out:
 result=subprocess.run(['go','test','-json','-count=1','-timeout=5m','./internal/account','./internal/apikey','./internal/credentials','-run',sys.argv[2]],env=env,stdout=out,stderr=subprocess.STDOUT)
print('exit',result.returncode)
raise SystemExit(result.returncode)
