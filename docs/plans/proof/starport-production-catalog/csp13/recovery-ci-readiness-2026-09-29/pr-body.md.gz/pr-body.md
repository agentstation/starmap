## Task: CSP13 Verified backup and restricted restore preparation

### Summary

Starport can capture a stopped deployment across KV, SQL, file bytes, and selected configuration. Verification checks artifact digests, encryption-key access, and references between retained records before creating restore targets.

Restore preparation keeps startup barriers closed. Exact retries preserve ownership, expiration, accounting, and publication evidence. Only validated files can enter their configured destinations. Incomplete migration records and uncertain publication stages cannot become active state.

### Changes

- Add portable snapshots and guarded imports for Badger, Valkey, SQLite, PostgreSQL, MySQL, local files, and object storage.
- Validate identity, credentials, files, jobs, budget reservations, corrections, and catalog references through their owning packages.
- Add backup and restore CLI commands, explicit file dispositions, local administrator recovery, and an operator procedure.
- Add real-storage recovery checks to required CI. Align aggregate test timeouts with the native application limit. Remove the duplicate full-suite run from the architecture gate.

### Implementation checklist

- [x] Captured stores and selected files share a digest-bound manifest.
- [x] Verification refuses invalid references before target creation.
- [x] Restricted imports and file publication preserve barriers and exact retries.
- [ ] Complete CSP13 independent later-history reconciliation and controlled activation.
- [ ] Qualify the published consumer head on all required native platforms.

### Testing

- Full Go suite: 5,974 test results passed, 369 skipped. Shared fixtures and optional qualification checks account for skips. This is not full production qualification.
- Real-storage race suite: 734 results passed, including all nine SQL transfer pairs. Two backend-replacement tests skipped there and passed with a separate two-Valkey fixture.
- Fleet catalog capture: 16 results passed. Shared application restore: four results passed.
- Eleven focused architecture contracts passed. The full Go suite runs separately.
- Console: 464 tests passed. Build, overhead, first-run, SDK smoke, vet, and lint checks passed.
- The first full Go attempt hit the default ten-minute package limit. The final run passed with the existing CI limit of 30 minutes. Individual contract deadlines remain unchanged.

### Dependencies

Starmap #197 merged as `27fee03e33fd430c70f8235a08d665d24804c4b9`. The published module pin uses tested head `9ab700ad930f`, whose tree equals that merge. There are no local module replacements.

### Notes

CSP13 remains in progress. These commands prepare inactive recovery state. Independent later history, external writer fencing, and controlled activation remain required before a production recovery claim.
