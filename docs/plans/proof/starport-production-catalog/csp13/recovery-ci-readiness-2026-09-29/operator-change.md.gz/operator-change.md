The command keeps the gateway stopped. With Badger, it leaves SQL closed.
With Valkey, it requires access to the existing PostgreSQL recovery witness.
