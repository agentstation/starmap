## Task: CSP13 Verified backup and restricted restore preparation

### Summary

Starport can capture a stopped deployment across KV, SQL, file bytes, and selected configuration. Verification checks artifact digests, encryption-key access, and references between retained records before creating restore targets.

Restore preparation keeps startup barriers closed. Exact retries preserve ownership, expiration, accounting, and publication evidence. Only validated files can enter their configured destinations. Incomplete migration records and uncertain publication stages cannot become active state.

### Changes

- Add portable snapshots and guarded imports for Badger, Valkey, SQLite, PostgreSQL, MySQL, local files, and object storage.
- Validate identity, credentials, files, jobs, budget reservations, corrections, and catalog references through their owning packages.
- Add backup and restore CLI commands, explicit file dispositions, local administrator recovery, and an operator procedure.
- Add real-storage recovery checks to required CI. Align aggregate test timeouts with the native application limit. Remove the duplicate full-suite run from the architecture gate.

### Implementation checklist

- [x] Captured stores and selected files share a digest-bound manifest.
- [x] Verification refuses invalid references before target creation.
- [x] Restricted imports and file publication preserve barriers and exact retries.
- [ ] Complete CSP13 independent later-history reconciliation and controlled activation.
- [ ] Qualify the published consumer head on all required native platforms.

### Testing

Published head `90ad16c2d` pins both retained-journal fixtures to LF. A checkout with `core.autocrlf=true` now preserves their exact Git bytes. All seven focused application restore results pass locally.

The unchanged substantive source at `d9b502da2` passed 1,462 real-storage and durable-work results and 117 fleet recovery results, without failures or skips. Windows ARM passed 1,134 results, skipped 101 fixture-dependent cases, and failed six results because Git changed the two journal fixtures to CRLF. Fresh native qualification remains required for the corrected checkout.

The full local checks ran before the native repairs at `3f5aa9b4c`:

- Full Go suite: 5,974 results passed and 369 skipped. Shared fixtures and optional qualification checks account for skips.
- Console: 464 tests passed. Build, overhead, first-run, SDK smoke, vet, and lint passed.
- Eleven focused architecture contracts passed. The full Go suite runs separately.

Windows directory publication closes staging handles before rename. Local storage checks cover this repair with 333 results in each race and pure-Go mode, plus 48 service-dependent skips per mode. The parent-protection contract passes 33 local race results without skips and compiles for Windows ARM.

Required review reports no findings across four parts at the configured P0-only threshold. The latest gate reused its attestation because the substantive diff and review contract remain unchanged. Secret scanning passes. These checks do not establish complete production recovery.

### Dependencies

Starmap #197 merged as `27fee03e33fd430c70f8235a08d665d24804c4b9`. The published module pin uses tested head `9ab700ad930f`, whose tree equals that merge. There are no local module replacements.

### Notes

CSP13 remains in progress. These commands prepare inactive recovery state. Independent later history, external writer fencing, and controlled activation remain required before a production recovery claim.

