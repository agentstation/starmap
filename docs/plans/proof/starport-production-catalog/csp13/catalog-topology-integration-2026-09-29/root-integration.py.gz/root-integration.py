import json, os, subprocess, sys, urllib.parse
info = json.loads(subprocess.check_output(['docker', 'inspect', 'starport-csp13-postgres']))[0]
cfg = dict(x.split('=', 1) for x in info['Config']['Env'] if '=' in x)
port = info['NetworkSettings']['Ports']['5432/tcp'][0]['HostPort']
valkey = json.loads(subprocess.check_output(['docker', 'inspect', 'csp13-unprefixed-valkey-20260929']))[0]
kvport = valkey['NetworkSettings']['Ports']['6379/tcp'][0]['HostPort']
q = lambda x: urllib.parse.quote(x, safe='')
env = os.environ.copy()
env['GOWORK'] = 'off'
env['TEST_VALKEY_URL'] = 'redis://127.0.0.1:' + kvport + '/0'
env['TEST_POSTGRES_URL'] = 'postgres://' + q(cfg.get('POSTGRES_USER','postgres')) + ':' + q(cfg.get('POSTGRES_PASSWORD','')) + '@127.0.0.1:' + port + '/' + q(cfg.get('POSTGRES_DB','postgres')) + '?sslmode=disable'
mysql = json.loads(subprocess.check_output(['docker','inspect','starport-csp13-mysql']))[0]
mcfg = dict(x.split('=',1) for x in mysql['Config']['Env'] if '=' in x)
mport = mysql['NetworkSettings']['Ports']['3306/tcp'][0]['HostPort']
env['TEST_MYSQL_DSN'] = mcfg.get('MYSQL_USER','root') + ':' + mcfg.get('MYSQL_PASSWORD',mcfg.get('MYSQL_ROOT_PASSWORD','')) + '@tcp(127.0.0.1:' + mport + ')/' + mcfg.get('MYSQL_DATABASE','starport') + '?parseTime=true&multiStatements=true'
objects = json.loads(subprocess.check_output(['docker','inspect','starport-csp122-retirement-objectstore']))[0]
port = objects['NetworkSettings']['Ports']['9000/tcp'][0]['HostPort']
env['TEST_BLOB_S3_ENDPOINT'] = 'http://127.0.0.1:' + port
with open(sys.argv[1], 'w') as out:
    args=['go','test','-json','-count=1','-timeout=6m','./internal/catalog','-run','^TestTopology(Compiler|Inventory|Fleet|Native|Archive|Replay)']
    if sys.argv[2]=='race':args.insert(2,'-race')
    else:env['CGO_ENABLED']='0'
    result=subprocess.run(args,env=env,stdout=out,stderr=subprocess.STDOUT)
print('activation test exit:',result.returncode)
raise SystemExit(result.returncode)
