# Recovery startup preflight

Source worktree: `/private/tmp/starport-recovery-startup-preflight-20260929`.
Branch: `codex/recovery-startup-preflight`.
Base: `49d791c7521b517e916c9f8c89e75e1a5f5410df`.
The branch also includes the strict native receipt owner change from `49b2e0c5`.

## Behavior

SQL preflight reads the selected existing database before setup or KV open.
SQLite uses a read-only connection. The inspection creates no directory, database, schema, token, policy, or catalog permission.

The opened KV owner and a second SQL inspection must agree on native activation presence and decision.
The second SQL inspection must match the first native receipt.
Badger maintenance starts after that joined check.
Fresh standalone startup keeps its existing behavior.

Native checks reject import barriers, corrupt records, orphan history, expired KV controls, and inconsistent current or historical receipts.
Version 2 receipts retain the original final replay position. The checks compare that position with the actual native cursor and history.
Version 1 receipts remain historical evidence without a position.
Native activation records have a 512-byte read limit. Other recovery metadata has a 4096-byte limit.

## Boundary

These checks refuse inconsistent recovery. They do not implement complete recovery activation.
The coordinator must still check the retained sealed decision, selected targets, canonical files, catalog selection, and current permission.
Digest agreement does not establish those requirements.
The native checks grant no permission and run no approval callback and release no barrier.
External writer fencing must cover the complete operation.

Ordinary startup gains no custom UTC qualification requirement.
The checks do not fetch provider data.
Low-level `OpenBadger` keeps its native constructor behavior. Application startup uses `OpenForStartup` to defer maintenance.

## Review

Each native owner checks its own receipt format and history.
SQL errors and corrupt databases cannot establish first boot.
Missing native current records cannot hide retained recovery history.
The application tests use native imports and a released KV owner with closed or invalid SQL controls.
They check refusal before KV open, migrations, setup locks, policy creation, token creation, and blob construction.
Native tests cover both unpositioned and positioned receipts, including inconsistent retained final positions.

## Evidence

The verification record lists the final commands, results, and test counts.

The directory retains failed fixture attempts and complexity-check failures.
Those failures caused fixture repairs or source decomposition. The assertions retain the required behavior.
Native checks used the available Mac host, isolated SQL schemas, and distinct Valkey deployment prefixes.
Linux and Windows qualification remains with the parent integration and CI.
The parent owns the required structured review and publication.
