# Passive operator input inspection

Active operator verification can create its journal or recover publications. Completed recovery needs a passive constructor after a restart.

Add `InspectRecoveryOperatorInputs`. Read the original bounded decision and recheck the selected settings, native targets, journal identity, files, and publication continuity. Missing or changed original evidence must refuse without publication, repair, token rotation, or inference-policy initialization. The capability remains restricted and grants no permission.

Keep the active verifier for initial preparation. Require passive `Check` calls to reject pending journal publications. Test exact reopen, missing/corrupt decision, changed settings/token/operation/directory, and unchanged target bytes after refusal. Shared native target coverage belongs to the integrated check.
