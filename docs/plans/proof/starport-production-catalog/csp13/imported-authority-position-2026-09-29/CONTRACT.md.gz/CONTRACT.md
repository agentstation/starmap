# Final imported authority approval

Current approval uses the unpositioned SQL activation path. The complete coordinator needs approval bound to the final SQL replay position.

Add `Witness.ApproveImportedAuthorityAt`. Require a context deadline, check the exact closed SQL boundary on the transaction connection, and install native authority. Commit SQL approval with the position-bound activation receipt. Keep existing approval behavior unchanged.

A lost native reply leaves SQL closed. An exact retry checks the existing native authority bytes and completes SQL without repeating the native mutation. A later withdrawal stays closed. Historical completion uses passive native inspection. This approval method must still refuse withdrawn current permission.

Test SQLite, PostgreSQL, and MySQL with real Valkey. Cover nonzero positions, wrong positions, missing deadlines, changed boundaries, lost replies, exact retry, changed decision/evidence, and later withdrawal. These checks do not establish complete coordinator fencing or application admission.
