Restored stores must stay closed while operators reconcile later permission, accounting, and execution records. This adds typed owner replay with exact preimages and ordered native receipts, plus guarded inspection of the resulting KV, SQL, and blob graph.

`starport backup inspect-import` checks explicitly selected import identities and replay positions, preserves every import barrier, and writes a private inspection receipt. Native activation operations bind their receipts to a recovery decision. Complete history acceptance, catalog topology transfer, and coordinated operator activation remain separate CSP13 work; this PR does not mark recovery complete.

Validation on Go 1.27.1:

- Full Go suite: 6,527 passing test results, zero failures; 497 optional or platform-dependent results skipped.
- Changed recovery owners have separate native race and pure-Go evidence with Badger, Valkey, SQLite, PostgreSQL, MySQL, filesystem storage, and MinIO.
- Operator inspection: 48 passing results in each mode, no skips. Final graph inspection: 21 final focused results in each mode, no skips.
- All 26 repository verification scripts, vet, lint, build, first-run smoke, SDK smoke, and the existing overhead benchmark pass. Console checks pass all 464 tests.

The original import-cycle and architecture failures, the eight-minute application timeout, and their later passing qualification remain in the production plan evidence. The full application suite completed in 509 seconds with a twenty-minute bound.
