import assert from 'node:assert/strict';
import { cn, clsx, twMerge } from 'cn';
let comparisons = 0;
for (let round = 0; round < 3; round++) {
  for (let n = 0; n < 4096; n++) {
    const dynamic = `translate-x-[${n}px]`;
    for (const args of [
      ['p-2 translate-x-0', `p-4 ${dynamic}`],
      ['p-2 translate-x-0', false, ['p-4', dynamic]],
      ['p-2', { 'p-4': n % 2 === 0, 'p-6': n % 2 === 1 }, dynamic],
      ['p-2', dynamic, n % 2 ? 'p-4' : 'p-6'],
    ]) {
      assert.equal(cn(...args), twMerge(clsx(...args)));
      comparisons++;
    }
    assert.equal(cn('p-2', 'p-4'), 'p-4');
    comparisons++;
  }
}
console.log(JSON.stringify({package:'cn',version:'0.4.0',comparisons,fail:0,contract:'Cached variadic calls equal direct merge across churn, reuse, nested arguments, and conditions.'}));
