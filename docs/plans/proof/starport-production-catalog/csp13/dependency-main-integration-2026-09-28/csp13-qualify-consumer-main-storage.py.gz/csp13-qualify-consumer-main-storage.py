import subprocess,socket,tempfile,time,urllib.request,os,json,secrets,re
from pathlib import Path
repo='/private/tmp/starport-clock-review-20260926'
project='csp13-main-'+secrets.token_hex(4)
env=os.environ.copy();env.update(STARPORT_VALKEY_PORT='0',STARPORT_POSTGRES_PORT='0')
compose=['docker','compose','-p',project,'-f',repo+'/docker-compose.integration.yml']
server=None;log=None
record={'project':project,'base_head':subprocess.check_output(['git','rev-parse','HEAD'],cwd=repo,text=True).strip(),'source':'Working tree with recorded publication changes'}
try:
 subprocess.run(compose+['up','-d','--wait','--wait-timeout','60'],env=env,check=True,timeout=90)
 ports={name:subprocess.check_output(compose+['port',name,str(port)],env=env,text=True).strip() for name,port in [('valkey',6379),('postgres',5432)]}
 binary='/tmp/csp122-minio-source-bin/minio'
 metadata=subprocess.check_output(['go','version','-m',binary],text=True);assert 'go1.27.1' in metadata and 'v0.0.0-20250907161309-07c3a429bfed' in metadata
 Path('/tmp/csp13-consumer-main-storage-object-build.txt').write_text(metadata)
 with socket.socket() as s:s.bind(('127.0.0.1',0));port=s.getsockname()[1]
 endpoint=f'http://127.0.0.1:{port}'
 env.update(MINIO_ROOT_USER='starport-test',MINIO_ROOT_PASSWORD='starport-local-test-only',MINIO_BROWSER='off')
 data=tempfile.mkdtemp(prefix='csp13-main-objectstore-');log=open('/tmp/csp13-consumer-main-storage-object.log','w')
 server=subprocess.Popen([binary,'server',data,'--address',f'127.0.0.1:{port}'],env=env,stdout=log,stderr=subprocess.STDOUT)
 for _ in range(30):
  assert server.poll() is None,'fixture exited before readiness'
  try:
   with urllib.request.urlopen(endpoint+'/minio/health/live',timeout=1) as response:assert response.status==200
   break
  except OSError:time.sleep(.2)
 else:raise RuntimeError('fixture did not become ready')
 roots={'TestRestoreApplicationSharedRecipe','TestRestorePublishFilesSharedRecipe'}
 pattern='^('+'|'.join(re.escape(n) for n in sorted(roots))+')$'
 env.update(GOWORK='off',GOTOOLCHAIN='go1.27.1',TEST_VALKEY_URL='redis://'+ports['valkey'],TEST_POSTGRES_URL='postgres://postgres@'+ports['postgres']+'/starport_test?sslmode=disable',TEST_BLOB_S3_ENDPOINT=endpoint)
 command=['go','test','-race','-json','-count=1','-timeout=10m','./internal/app','-run',pattern]
 record.update(command=command,selected_roots=sorted(roots),ports=ports,object_endpoint=endpoint,object_data=data)
 Path('/tmp/csp13-consumer-main-storage-fixture.json').write_text(json.dumps(record,indent=2)+'\n')
 with open('/tmp/csp13-consumer-main-published-storage-race.jsonl','w') as output:
  result=subprocess.run(command,cwd=repo,env=env,stdout=output,stderr=subprocess.STDOUT,timeout=660)
 record['test_exit_code']=result.returncode
 print('Shared recovery cases exit:',result.returncode,flush=True)
 assert result.returncode==0
finally:
 if server is not None:
  server.terminate()
  try:server.wait(timeout=10)
  except subprocess.TimeoutExpired:server.kill();server.wait(timeout=10)
  record['objectstore_stopped']=server.poll() is not None
 if log is not None:log.close()
 cleanup=subprocess.run(compose+['down','--volumes'],env=env,timeout=60)
 record['compose_cleanup_exit']=cleanup.returncode
 Path('/tmp/csp13-consumer-main-storage-fixture.json').write_text(json.dumps(record,indent=2)+'\n')
