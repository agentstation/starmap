TLSCertificate selects HTTPS with the certificate that application composition validated.
A nil certificate selects HTTP, including deployments with external TLS termination.
