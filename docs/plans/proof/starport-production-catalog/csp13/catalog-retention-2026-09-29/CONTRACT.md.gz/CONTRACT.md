# Offline retained catalog recovery

This producer extension stages a complete historical inventory in bounded batches. Staging does not change active catalog inputs, select a baseline, contact a source or provider, acquire a lease, or establish serving permission. The host must fence writers and verify the native import claim and closed storage boundary before each producer operation.

## Identities and bytes

Each transfer has one explicit `TransferID` and one ordered full `Manifest`. Every batch uses that same transfer and manifest, a distinct `OperationID`, a `BatchStart`, and contiguous `Inputs`. The manifest binds each full catalog manifest SHA-256, exported reconstruction input SHA-256, explicit descriptor origin, and original descriptor SHA-256 where present.

`InputsSHA256` is `CatalogRecovery.Inputs.Checksum`: the SHA-256 of the original exported compressed input bytes, including their original historical baseline. It is not the local descriptor checksum. `SourceDescriptorSHA256` binds the exact original source descriptor bytes. Both identities and both byte representations remain retained. A local descriptor must be present and must match the exported reconstruction record after its separately referenced original baseline is accounted for. A fleet descriptor must be present; its publication inventory relationship is host-owned. The `no-descriptor` origin requires explicitly absent bytes and digest.

Historical staging uses structural validation. It preserves the capsule's original compatibility binding and makes no claim that a historical generation reproduces under current settings. Selection performs semantic replay for the selected generation under the actual target settings. A failed replay leaves selection unchanged. Serving authority, withdrawal checkpoints, and uncertainty have separate owners.

## Operations

- `RetainCatalogRecovery` retains one bounded batch. Its immutable `CatalogRetentionReceipt` records `Validation=structural`, native directory identity, operation, transfer, full manifest digest, exact request and plan digests, batch range, and retained envelope identities.
- `MaterializeRetainedCatalogRecovery` requires the exact completion receipt digests for every batch in ordered, complete, nonoverlapping manifest coverage. It verifies all referenced immutable envelopes, including unselected history, then loads only the selected capsule for semantic replay and materialization. The host sends references and the selected index, not the complete inventory again. The producer selects one canonical input set; the consumer separately preserves accepted and candidate heads.
- `ReadRetainedCatalogRecovery` passively exports a selected historical entry from its exact completed batch. It validates native owner, transfer, manifest, entry, and envelope. Returned bytes are private copies. Missing data is an error; the reader never repairs or continues a journal.
- `InspectRetainedCatalogMaterialization` passively proves the current pre-activation selection. It requires the exact existing COMPLETE materialization receipt, the current pointer to that operation, no pending recovery journals, complete original transfer coverage, native owner and seed continuity, exact active baseline/layers/files, and target semantic replay. A later selection, including one with identical catalog inputs, refuses the old current-selection proof.

Exact completed retry is a historical acknowledgment. It returns the original receipt without reapplying selection, recreating missing envelopes, or reverting later state. It is different from current-selection inspection. A changed directory identity, operation request, transfer manifest, native owner, seed, or target settings refuses reuse. A new explicit operation can retain copied evidence in a restored owner-verified directory while old receipts remain unchanged as history.

## Durable state and recovery

Retention and materialization share the existing operation journal at `catalog-runtime/materializations/<sha256(operation)>/plan.json.gz` and `complete.json`. Pending retention blocks runtime startup and selection. The digest-only transfer manifest can be published before the operation plan. A crash in that initial window has retained no capsules and changed no active catalog inputs; the host closed import boundary still owns migration progress. Once the plan exists, interrupted retention blocks startup and selection. The journal captures active inputs and owner, seed, permission, and origin continuity before staging. Resume checks those preimages and continuity. Completion is immutable.

Retained envelopes live at `catalog-runtime/retained-catalog/<sha256(transfer)>/<sha256(envelope)>.json.gz`. The immutable full transfer manifest is `manifest.json`. File inspection recognizes these exact artifacts and their native publication journals; unknown artifacts remain refused. Original immutable capsules and baselines remain retained through ordinary later catalog updates.

## Bounds

The full manifest is digest-only and bounded at the existing producer limit of 4,096 entries. Each staging call uses the existing 256 MiB aggregate raw input bound and aggregate exported reconstruction decoded bound. Raw accounting includes the bounded serialized generation manifests, payloads, exported inputs, and original descriptors. Each local descriptor also has its existing 256 MiB compressed and decoded bounds. Subtraction checks range and byte limits before arithmetic and allocation. Deterministic JSON encoding stops at a fixed 512 MiB envelope/request bound to account for base64 expansion; compressed and decoded envelope reads have the same fixed limit. Generation manifest serialization has the existing 64 MiB filesystem manifest bound.

There is no 256 MiB cap on the entire transfer. Multiple bounded calls preserve the consumer's declared 96-entry/2 GiB inventory contract. The producer tests prove all 96 entry references and eight ordered batches with small real fixtures. They do not claim a physical 2 GiB stress run; full consumer capacity and native storage qualification remain consumer integration evidence.

## Required evidence

Tests cover structural-only history with original settings, original local descriptor/exported input roundtrip, returned-data mutation isolation, exact full 96-entry batch coverage, gaps/overlap/reorder/changed manifest, process exit and retry, changed active state and permission continuity, pending startup and inspection, exact receipt refusal, missing selected and unselected immutable evidence, native directory restore and new explicit operation, refusal after replacing an otherwise valid seed in the same directory, bounded encoding, passive source/provider/lease/clock roles, one complete embedded catalog contract, and historical retry after later selection.

Native evidence in this producer worktree is macOS Apple silicon on Go 1.27.1. Race, pure-Go, and repository check summaries are recorded in `verification.json`. Linux and Windows native evidence, real consumer KV/SQL topology transfers, accepted-versus-candidate preservation, the native closed import boundary, and final authorization rotations remain root-owned integration and CI work. This producer change grants none of those permissions.
