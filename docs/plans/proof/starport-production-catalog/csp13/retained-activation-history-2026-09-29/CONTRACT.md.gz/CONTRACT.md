# Retained activation history verification

The recovery package owns passive historical verification after native import barriers disappear.
The API accepts no native target, SQL witness, lease, mutation array, or provider credential.

## API

The request binds the original history package and acceptance directory.
It also binds the closed-final decision digest, scratch directory, and attestation.

`OpenRetainedActivationHistory` returns a private historical capability after every retained check succeeds.

`Check` rereads the same evidence and refuses changed request scope or changed decision bytes.
It also checks that private identities and positions match the retained decision bytes.

`Report` remains restricted and preserves all separate current activation requirements.
Its copied value fields expose no private mutable claim bytes.

The caller supplies the independently retained SHA256 of the exact closed-final decision bytes.
That digest binds the original source, prepared import, acceptance, run, completed journal, final graph, and original times.

## Reads and checks

Verify the original backup and its domain reference graph through private temporary copies.
Verify the complete history package, payloads, assets, original operator attestation, and exact retained acceptance.
Derive the original prepared import identity without preparing a target.
Read the original canonical run record without creating it or replacing its time.
Check the complete prepared and applied journal chain, component positions, and both final revision rotations.

Read each original pre-step image and verify its native snapshot receipt and full image bytes.
Validate typed owner inputs through pure owner decoders or preparation functions without applying their returned mutations.

Read the original closed-final preparation and reconstruct its expected identity with its retained capture time.
Require the exact closed-final record and matching retained graph attempt receipt.
Verify the fixed final KV, SQL, and blob copies and their domain reference graph at the original capture time.

The independent accepted decision binds native receipt digests in the applied history records.
Native activation receipts and current owner state require separate phase checks.
The verifier does not reproduce private native receipt codecs or replace native phase checks.

## Effects and refusal

The verifier creates and removes only private temporary verification copies in the selected scratch directory.
It preserves original backup, package, journals, graph files, target data, and original validation times.
It does not accept, prepare, replay, continue file publication, capture current targets, issue permission, or activate imports.
Missing, corrupt, noncanonical, nonprivate, incomplete, or changed retained evidence refuses verification.

The initial private `retainedCatalogJournal` hook refuses unsupported catalog preparation journals.
The root integration will add the typed catalog mode and its owning passive lane verifier.
This initial commit does not claim catalog-lane support or complete product activation.

## Qualification boundary

Local cases use real Badger, SQLite, and filesystem blob stores.
Tests remove all three native import barriers before checking retained history and later target data.
Reports still require current permission and current settings after historical completion.
Linux and macOS permission cases reject group-readable historical evidence without changing its permissions.
Windows ACL qualification, shared storage, cross-topology integration, and complete recovery activation remain root-owned checks.
