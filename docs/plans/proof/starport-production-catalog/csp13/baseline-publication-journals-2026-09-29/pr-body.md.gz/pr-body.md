Restore can encounter valid catalog exports and accepted credential policy beside interrupted publication files. This change validates the captured journals and matching stages through their owners, so Starport can preserve them as inactive evidence while it restores completed records. Unknown, malformed, or changed evidence causes refusal. Historical native identities never authorize cleanup, staged bytes never become accepted policy, and publication never opens admission.

Starmap acquisition-policy writes now use native journaled publication with bounded writer-lock retries. Runtime and credential-policy restore share the native publication inspector. The baseline inspector also handles complete journal updates and interrupted collection. Starport consumes these checks in its separate recovery branch.

Validation:

- Full Starmap checks gate passes on Go 1.27.1.
- Credential and private-file owner suites pass 319 race results. Retained runtime tests pass 117 results.
- Baseline package passes 152 race results, including real process-interruption recovery. Focused baseline pure-Go tests pass 38 results.
- Starport development suites pass 59 race and 59 pure-Go results, each with two shared-fixture skips. Its published-module qualification remains pending.
- Required pre-PR review runs at the configured P0-only threshold. This PR still requires native CI qualification.
