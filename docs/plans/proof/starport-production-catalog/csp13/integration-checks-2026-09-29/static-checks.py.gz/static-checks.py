from pathlib import Path
import json,os,re,subprocess,time
root=Path.cwd(); out=Path('/tmp/csp13-recovery-qualification-20260929')
s=(root/'AGENTS.md').read_text(); block=s.split('Before a pull request, run:',1)[1].split('```bash',1)[1].split('```',1)[0]
commands=[line.strip() for line in block.splitlines() if line.startswith('bash scripts/verify-') or line.startswith('bash scripts/test-')]
env=os.environ.copy();env['GOWORK']='off'
for key in ['CATALOG_DRIVEN_STARMAP_ROOT','STARMAP_OWNERSHIP_STARMAP_ROOT']:env[key]='/private/tmp/starmap-fleet-review-20260926'
results=[]
for cmd in commands:
 started=time.monotonic(); log=out/(Path(cmd.split()[1]).stem+'.log')
 with log.open('w') as file:
  try: run=subprocess.run(cmd.split(),env=env,stdout=file,stderr=subprocess.STDOUT,timeout=240);code=run.returncode
  except subprocess.TimeoutExpired:code=124
 results.append({'command':cmd,'exit_code':code,'seconds':round(time.monotonic()-started,3),'log':log.name})
 (out/'static-checks.json').write_text(json.dumps(results,indent=2)+'\n')
 print(cmd,code,flush=True)
raise SystemExit(int(any(r['exit_code'] for r in results)))
