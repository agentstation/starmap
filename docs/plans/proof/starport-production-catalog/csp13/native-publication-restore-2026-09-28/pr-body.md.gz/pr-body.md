A restored catalog runtime needs its owner identity, acquisition inputs, replay evidence, and historical migration records checked before publication. This change adds read-only inspection for those records. It does not approve admission or reuse of a replica identity.

Completed migration receipts remain inactive after validation against the configured owner, captured path, scheduler identity, and retained seed. Native file-publication journals also remain inactive with matching staging bytes. Their former host identities cannot authorize cleanup on the restore host. Destination records still require owner validation, and staging bytes never replace them. Torn journals, unknown records, changed staging bytes, and incomplete migration history cause refusal.

The GitHub discovery-state reader now refuses unsupported schema versions instead of silently discarding the retained replay floor.

The full Starmap checks gate passes on Go `1.27.1`.
The focused suites pass 102 race results and 102 pure-Go results without failures or skips.
They cover native journals, process-exit recovery, all five runtime publication scopes, and malformed or changed evidence.
The plan proof retains earlier runtime and migration tests.
Required Opus review reports no findings at its configured P0-only threshold.
Current-head native CI remains required.

CSP13 remains in progress. Accepted-catalog consistency, independent post-backup history, controlled activation, interrupted path recovery, and complete storage qualification remain separate requirements.
