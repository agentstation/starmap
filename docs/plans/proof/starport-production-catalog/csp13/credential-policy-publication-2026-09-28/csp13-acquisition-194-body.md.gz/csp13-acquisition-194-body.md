Starport recovery needs to copy native private files and inspect retained credential selection policies without writes. This change adds bounded `productfiles.Directory.CopyFile`, publication-journal inspection, and `acquisition.InspectCredentialPolicyState`.

The policy inspector preserves the retained legacy default and accepted provider decisions. It refuses missing defaults, wrong owners or policy families, invalid record names, extra files, and pending publications. It does not create state, resolve credentials, or start acquisition. Callers must fence writers and verify the complete inventory around inspection. These APIs do not approve recovery or gateway admission.

Windows holds the copied directory open and refuses replacement during the copy. Its test now proves that protection, complete output, handle release, and refusal after replacement. POSIX retains the test that replaces the directory during copying and requires refusal.

Validation on Go 1.27.1: the final affected-package race and pure-Go suites each pass 300 tests without failures or skips. Pinned lint, goago, vet, and technical-writing checks pass. Repository verification checks passed before the final platform-test correction. That correction changes tests only. 

Windows amd64 and arm64 test binaries compile. Native CI must pass at the new head before merge. Required pre-PR review uses the configured P0 threshold.

The branch includes the actual merge of dependency PR #192.
